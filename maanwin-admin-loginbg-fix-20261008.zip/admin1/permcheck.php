<?php
/**
 * permcheck.php — Super Admin permission self-check
 * ==================================================
 * Browser me kholo:  https://maanwin.club9.eu.cc/admin1/permcheck.php
 *
 * Ye batata hai ki abhi login hua admin super admin hai ya nahi, aur use
 * kaun-kaun se modules mil rahe hain.
 */
declare(strict_types=1);
require_once __DIR__ . '/lib.php';
dw_admin_session_start();
header('Content-Type: text/html; charset=utf-8');

$conn = db();
if (!$conn) { echo '<!doctype html><meta charset="utf-8"><body style="font:15px system-ui;padding:30px"><h2 style="color:#b62324">DB connect FAIL</h2><p>api/_core/config.php check karo.</p></body>'; exit; }

$admin = dw_admin_user($conn);
echo '<!doctype html><meta charset="utf-8"><title>Admin permission check</title>';
echo '<body style="font:15px/1.6 system-ui;background:#0e1116;color:#e6e6e6;margin:0;padding:28px">';
echo '<h2 style="margin:0 0 6px">Admin permission check</h2>';
echo '<div style="opacity:.7;margin-bottom:20px">' . htmlspecialchars($_SERVER['HTTP_HOST'] ?? '') . '</div>';

if (!$admin) {
    echo '<div style="border-left:4px solid #b62324;background:#161b22;padding:12px 16px;border-radius:4px">'
       . '<b style="color:#b62324">Login nahi hai.</b> Pehle <a style="color:#58a6ff" href="index.php">admin login</a> karo, phir ye page kholo.</div>';
    echo '</body>'; exit;
}

$permissions = dw_admin_permissions($conn, $admin);
$isSuper     = dw_is_super_admin($conn, $admin);

$row = null;
$stmt = @$conn->prepare('SELECT permissions,status FROM admin_permissions WHERE admin_user=? LIMIT 1');
if ($stmt) { $u=(string)$admin['username']; $stmt->bind_param('s',$u); $stmt->execute(); $row = $stmt->get_result()->fetch_assoc(); $stmt->close(); }

function pc_row(string $label, string $value, string $color): void {
    echo '<div style="display:flex;gap:14px;padding:9px 0;border-bottom:1px solid #21262d">'
       . '<div style="width:230px;opacity:.75">' . htmlspecialchars($label) . '</div>'
       . '<div style="font-family:ui-monospace,monospace;color:' . $color . '">' . htmlspecialchars($value) . '</div></div>';
}

echo '<div style="background:#161b22;border:1px solid #30363d;border-radius:8px;padding:16px 18px;max-width:820px">';
pc_row('Admin id', (string)$admin['id'], '#e6e6e6');
pc_row('Username', (string)$admin['username'], '#e6e6e6');
pc_row('Nickname', (string)($admin['nickname'] ?: '-'), '#e6e6e6');
pc_row('Role (users table)', (string)$admin['role'], '#e6e6e6');
pc_row('admin_permissions row', $row ? 'HAI (status=' . (string)$row['status'] . ')' : 'NAHI HAI', $row ? '#e3b341' : '#3fb950');
pc_row('Super admin', $isSuper ? 'YES' : 'NO', $isSuper ? '#3fb950' : '#f85149');
pc_row('Effective permissions', implode(', ', $permissions), in_array('*', $permissions, true) ? '#3fb950' : '#e3b341');
echo '</div>';

if (in_array('*', $permissions, true)) {
    echo '<h3 style="color:#3fb950;margin-top:22px">✔ Sab theek hai — aap SUPER ADMIN hain, poora panel khula hai.</h3>';
} else {
    echo '<h3 style="color:#f85149;margin-top:22px">✘ Abhi bhi locked hai.</h3>';
    echo '<p style="opacity:.8">admin1/lib.php ke upar <code>DW_SUPER_ADMIN_IDS</code> / <code>DW_SUPER_ADMIN_USERNAMES</code> me apna id / username daal do, '
       . 'ya <code>DW_AUTO_SUPER_ADMIN</code> ko <code>true</code> rehne do (default true hai).</p>';
}
echo '</body>';
