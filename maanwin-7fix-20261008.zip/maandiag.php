<?php
/**
 * maandiag.php — maanwin DIAGNOSTIC (plain text)
 * ==============================================
 * Browser me kholo:  https://maanwin.club9.eu.cc/maandiag.php
 *
 * Ye page kuch BHI change nahi karta — sirf live server ki asli information
 * print karta hai (period numbers, result, functions ka source).
 * Diagnostic complete hone ke baad is file ko DELETE kar dena.
 */
header('Content-Type: text/plain; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');

try {
    require_once __DIR__ . '/api/_core/bootstrap.php';
} catch (Throwable $e) {
    echo "BOOTSTRAP LOAD FAIL: " . $e->getMessage() . "\n";
    exit;
}

$game = 'WinGo_30S';
$line = str_repeat('=', 78);

echo $line . "\n";
echo "MAANWIN DIAGNOSTIC   " . date('Y-m-d H:i:s T') . "   host=" . ($_SERVER['HTTP_HOST'] ?? '') . "\n";
echo $line . "\n\n";

// ------------------------------------------------------------------ 1
echo "[1] PATCH APPLIED?  (4-fix + fix#5)\n";
foreach (['LE_INSTANT_SETTLEMENT', 'LE_TIMER_LEAD_MS', 'LE_REVEAL_AT_COUNTDOWN',
          'LE_TAX_PERCENT', 'LE_ORDER_NO', 'AR_PERIOD_SHIFT'] as $c) {
    echo '    ' . str_pad($c, 26) . ' : ' . (defined($c) ? var_export(constant($c), true) : '<< NOT DEFINED >>') . "\n";
}
echo '    ' . str_pad('le_issue_prev()', 26) . ' : ' . (function_exists('le_issue_prev') ? 'present' : 'MISSING') . "\n";
echo '    ' . str_pad('le_issue_sequence()', 26) . ' : ' . (function_exists('le_issue_sequence') ? 'present' : 'MISSING') . "\n";
echo '    ' . str_pad('le_history_start_offset()', 26) . ' : ' . (function_exists('le_history_start_offset') ? 'present' : 'MISSING') . "\n";
echo "\n";

// ------------------------------------------------------------------ 2
echo "[2] CURRENT ISSUE (lottery_issue)  — WinGo_30S AUR WinGo_1M dono\n";
echo "    (do alag host ek hi DB share karte hain; in dono game ke period\n";
echo "     number compare kar ke pata chalta hai ki kaunsa build chal raha hai)\n";
foreach (['WinGo_30S', 'WinGo_1M'] as $g) {
    echo "  --- $g ---\n";
    $iss = function_exists('lottery_issue') ? lottery_issue($g) : null;
    if (!$iss) { echo "      (lottery_issue nahi mila)\n"; continue; }
    foreach (['startTime', 'endTime', 'issueNumber', 'intervalMinute', 'intervalSecond', 'countdown', 'currentTime'] as $k) {
        echo '      ' . str_pad($k, 16) . ' : ' . (isset($iss[$k]) ? $iss[$k] : '-') . "\n";
    }
    $interval = function_exists('le_game_interval') ? le_game_interval($g) : 0;
    $span = (int)round((((int)$iss['endTime']) - ((int)$iss['startTime'])) / 1000);
    $okTimer = ($interval > 0 && $span === $interval - 1);
    echo '      ' . str_pad('end-start(sec)', 16) . ' : ' . $span . ' / interval ' . $interval
         . ($okTimer ? '   (=> TIMER FIX ACTIVE, 1 sec kam)' : '   (=> TIMER FIX NOT ACTIVE)') . "\n";
}
echo '    ' . str_pad('reveal now?', 22) . ' : ' . (function_exists('le_should_reveal_current') ? (le_should_reveal_current($game) ? 'YES' : 'no') : 'n/a') . '   (game=' . $game . ")\n";
echo '    ' . str_pad('start offset', 22) . ' : ' . (function_exists('le_history_start_offset') ? le_history_start_offset($game) : 'n/a') . "\n";
echo "\n";

// ------------------------------------------------------------------ 3
echo "[3] le_issue_by_offset()  RAW  (offset 0..12)\n";
$raw = [];
for ($k = 0; $k <= 12; $k++) {
    $raw[$k] = (string)le_issue_by_offset($game, $k);
    echo '    offset ' . str_pad((string)$k, 3) . ' : ' . $raw[$k] . "\n";
}
$mono = true;
for ($k = 1; $k <= 12; $k++) {
    if (substr($raw[$k], -5) !== str_pad((string)(((int)substr($raw[$k - 1], -5)) - 1), 5, '0', STR_PAD_LEFT)) {
        $mono = false;
        echo "    ^^ BREAK at offset $k (expected " . (((int)substr($raw[$k - 1], -5)) - 1) . ", got " . substr($raw[$k], -5) . ")\n";
    }
}
echo '    CONSECUTIVE? : ' . ($mono ? 'YES' : 'NO  <<< YAHI "period/result dusra-dusra" KI WAJAH HAI') . "\n";
echo "\n";

// ------------------------------------------------------------------ 4
echo "[4] FIXED SEQUENCE (le_issue_sequence)\n";
if (function_exists('le_issue_sequence')) {
    foreach ([1, 0] as $so) {
        echo "    startOffset=$so :\n";
        $seq = le_issue_sequence($game, $so, 10);
        foreach ($seq as $i => $s) {
            echo '        row ' . str_pad((string)$i, 2) . ' : ' . $s
                 . '   result=' . (function_exists('le_result_for_issue') ? (string)(le_result_for_issue($game, (string)$s, true)['number'] ?? '-') : '-') . "\n";
        }
    }
} else {
    echo "    le_issue_sequence() MISSING\n";
}
echo "\n";

// ------------------------------------------------------------------ 5
echo "[5] LIVE SOURCE — le_issue_by_offset / lottery_issue\n";
foreach (['le_issue_by_offset', 'lottery_issue', 'le_issue_prev', 'le_issue_sequence'] as $fn) {
    echo "  --- function $fn() ---\n";
    if (!function_exists($fn)) { echo "      (not defined)\n"; continue; }
    try {
        $rf = new ReflectionFunction($fn);
        $file = $rf->getFileName();
        $s = $rf->getStartLine();
        $e = $rf->getEndLine();
        echo '      file: ' . $file . '  lines ' . $s . '-' . $e . "\n";
        if ($file && is_readable($file)) {
            $lines = file($file);
            for ($i = $s - 1; $i < $e && $i < count($lines); $i++) {
                echo '      ' . str_pad((string)($i + 1), 4) . ' | ' . rtrim($lines[$i], "\r\n") . "\n";
            }
        }
    } catch (Throwable $ex) {
        echo '      reflection fail: ' . $ex->getMessage() . "\n";
    }
}
echo "\n";

// ------------------------------------------------------------------ 6
echo "[6] LAST 10 BETS\n";
try {
    $conn = db();
    if (!$conn) {
        echo "    DB connect fail\n";
    } else {
        $rs = @$conn->query('SELECT id,user_id,order_no,game_code,issue_number,amount,bet_multiple,real_amount,fee,premium,state,win_lose_amount,created_at FROM lottery_bets ORDER BY id DESC LIMIT 10');
        if (!$rs) {
            echo '    query fail: ' . $conn->error . "\n";
        } else {
            while ($r = $rs->fetch_assoc()) {
                printf("    id=%-6s uid=%-8s order=%s(len %d)  %s  issue=%s  amt=%s real=%s fee=%s  state=%s  wl=%s  prem=%s  %s\n",
                    $r['id'], $r['user_id'], $r['order_no'], strlen((string)$r['order_no']),
                    $r['game_code'], $r['issue_number'], $r['amount'], $r['real_amount'],
                    $r['fee'], $r['state'], $r['win_lose_amount'], $r['premium'], $r['created_at']);
            }
        }
        $rs2 = @$conn->query("SHOW COLUMNS FROM lottery_bets LIKE 'fee'");
        echo '    fee column: ' . ($rs2 && $rs2->num_rows ? 'yes' : 'NO') . "\n";
    }
} catch (Throwable $e) {
    echo '    ' . $e->getMessage() . "\n";
}
echo "\n";

// ------------------------------------------------------------------ 7
echo "[7] lottery_results — last 8 rows\n";
try {
    $conn = db();
    if ($conn) {
        $rs = @$conn->query('SELECT game_code,issue_number,premium,number,created_at FROM lottery_results ORDER BY id DESC LIMIT 8');
        if ($rs) {
            while ($r = $rs->fetch_assoc()) {
                printf("    %s  %s  premium=%s  number=%s  %s\n", $r['game_code'], $r['issue_number'], $r['premium'], $r['number'], $r['created_at']);
            }
        } else {
            echo '    ' . $conn->error . "\n";
        }
    }
} catch (Throwable $e) {
    echo '    ' . $e->getMessage() . "\n";
}

// ------------------------------------------------------------------ 8
echo "[8] TAX MODEL / SETTLEMENT CHECK  (FIX #6)\n";
try {
    $conn = db();
    if ($conn) {
        $rs = @$conn->query('SELECT id,order_no,game_code,issue_number,amount,bet_multiple,real_amount,fee,state,win_lose_amount FROM lottery_bets ORDER BY id DESC LIMIT 12');
        if ($rs) {
            while ($r = $rs->fetch_assoc()) {
                $o = (string)$r['order_no'];
                $s = (float)$r['real_amount'];
                $f = (float)$r['fee'];
                $disp = function_exists('le_is_display_only_tax') ? le_is_display_only_tax($o, $s, $f) : true;
                $db   = function_exists('le_settle_debit') ? le_settle_debit($o, $s, $f) : round($s + $f, 2);
                $real = $disp ? round(max(0, $s - $f), 2) : round($s, 2);
                printf("    id=%-6s %-32s model=%-14s stake=%-10s fee=%-8s debit=%-10s showAfterTax=%-10s state=%s wl=%s\n",
                    $r['id'], $o . ' (len ' . strlen($o) . ')',
                    $disp ? 'NEW(display)' : 'OLD(real fee)',
                    number_format($s, 2, '.', ''), number_format($f, 2, '.', ''),
                    number_format($db, 2, '.', ''), number_format($real, 2, '.', ''),
                    $r['state'], $r['win_lose_amount']);
            }
        } else {
            echo '    ' . $conn->error . "\n";
        }
    }
} catch (Throwable $e) {
    echo '    ' . $e->getMessage() . "\n";
}

echo "\n" . $line . "\n";
echo "END. Is file ko ab delete kar dena.\n";
