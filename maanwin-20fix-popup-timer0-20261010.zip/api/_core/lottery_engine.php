<?php
// Lottery engine for demo/virtual-wallet backend.
// Handles WinGo, TrxWinGo, K3, 5D/D5 and MotoRace bet settlement.

// =======================================================================
// FIX #4 — TAX + ORDER NUMBER helpers
// =======================================================================
function le_tax_percent(): float
{
    if (!defined('LE_TAX_PERCENT')) return 2.0;
    return (float)LE_TAX_PERCENT;
}

/** Bet amount par 2% tax — sirf record me dikhane ke liye. */
function le_stake_tax(float $stake): float
{
    return round(max(0.0, $stake) * le_tax_percent() / 100.0, 2);
}

// =======================================================================
// FIX #6 — DO TARAH KE BETS KA HISAAB  (paisa wala fix)
//
//   Ek hi database par do build chal rahe hain:
//
//     A) NAYA build (30-char order no, jaise WG2026100810195403193280000098)
//        fee / TAX sirf record me DIKHAYA jata hai — wallet se alag se
//        nahi kata jata.
//            real_amount = POORA bet amount
//            debit       = stake
//
//     B) PURANA build (18-char order no, jaise LT2610081038103803)
//        fee wallet se ALAG se KATA jata tha (asli katoti).
//            real_amount = debit - fee
//            debit       = stake + fee
//
//   Agar naya code purane build ke PENDING bet ko `debit = stake` se
//   settle kare to player ko 2% ZYADA mil jayenge. Yahi fix rokta hai.
// =======================================================================
function le_is_display_only_tax(string $orderNo, float $stake, float $fee): bool
{
    $orderNo = trim((string)$orderNo);
    if ($fee <= 0.0) return true;                 // koi fee nahi => dono model barabar
    if (strlen($orderNo) >= 28) return true;      // naya 30-char order no
    $pct = le_tax_percent();
    if ($pct <= 0.0) return true;
    // Purane model me fee = DEBIT ka 2% hota tha (debit = stake + fee).
    if (abs($fee - round(($stake + $fee) * $pct / 100.0, 2)) < 0.011) return false;
    // Naye model me fee = STAKE ka 2% hota hai.
    if (abs($fee - round($stake * $pct / 100.0, 2)) < 0.011) return true;
    return false;
}

/** Settlement me wallet se kitna kat / joda gaya — dono model ke liye sahi. */
function le_settle_debit(string $orderNo, float $stake, float $fee): float
{
    if (le_is_display_only_tax($orderNo, $stake, $fee)) return round($stake, 2);
    return round($stake + $fee, 2);
}

function le_order_prefix(string $gameCode): string
{
    $family = strtolower(trim((string)explode('_', (string)$gameCode)[0]));
    $map = [
        'wingo' => 'WG', 'trxwingo' => 'TW', 'k3' => 'K3',
        'd5' => '5D', '5d' => '5D', 'motorace' => 'MR', 'moto' => 'MR',
        'videowingo' => 'VW',
    ];
    return $map[$family] ?? 'LT';
}

/** 30 char order number: WG + Ymd + His + 7-digit user + 7-digit bet id. */
function le_order_number(string $gameCode, int $userId, int $betId, int $ts = 0): string
{
    if (defined('LE_ORDER_NO') && !LE_ORDER_NO) return '';
    if ($ts <= 0) $ts = time();
    return le_order_prefix($gameCode)
        . date('Ymd', $ts)
        . date('His', $ts)
        . str_pad((string)max(0, $userId), 7, '0', STR_PAD_LEFT)
        . str_pad((string)max(0, $betId), 7, '0', STR_PAD_LEFT);
}

// =======================================================================
// FIX #3 — WIN / LOSS POPUP
//   Popup tabhi dikhta hai jab bet wala period "Game history" ki PEHLI row
//   me aa jaye (frontend ko popup dikhane ke liye wahi row chahiye hoti hai).
//   Isliye screen wala countdown <= LE_REVEAL_AT_COUNTDOWN hone par current
//   period ko history list me (row 0 par) dikhana shuru kar deta hain.
//   Betting us waqt tak band ho chuki hoti hai (countdown <= 5), isliye
//   koi result dekh kar bet nahi lagaya ja sakta.
// =======================================================================
function le_should_reveal_current(string $gameCode): bool
{
    if (!defined('LE_REVEAL_AT_COUNTDOWN')) return false;
    $threshold = (int)LE_REVEAL_AT_COUNTDOWN;
    if ($threshold < 0) return false;
    $iss = function_exists('lottery_issue') ? lottery_issue($gameCode) : null;
    if (!is_array($iss)) return false;
    return (int)($iss['countdown'] ?? 99) <= $threshold;
}

/** History/period list ka pehla offset: 0 = current period bhi dikhao. */
function le_history_start_offset(string $gameCode): int
{
    return le_should_reveal_current($gameCode) ? 0 : 1;
}

function le_game_interval(string $gameCode): int
{
    if (stripos($gameCode, '30S') !== false) return 30;
    if (stripos($gameCode, '3Min') !== false || stripos($gameCode, '_3M') !== false) return 180;
    if (stripos($gameCode, '5Min') !== false || stripos($gameCode, '_5M') !== false) return 300;
    if (stripos($gameCode, '10Min') !== false || stripos($gameCode, '_10M') !== false) return 600;
    return 60;
}

function le_is_k3(string $gameCode): bool { return stripos($gameCode, 'K3') === 0; }
function le_is_d5(string $gameCode): bool { return stripos($gameCode, '5D') === 0 || stripos($gameCode, 'D5') === 0; }
function le_is_moto(string $gameCode): bool { return stripos($gameCode, 'MotoRace') === 0 || stripos($gameCode, 'Moto') === 0; }
function le_is_wingo(string $gameCode): bool { return !le_is_k3($gameCode) && !le_is_d5($gameCode) && !le_is_moto($gameCode); }

function le_default_settings(): array
{
    return [
        'win_rate' => 45.0,
        'force_mode' => 'auto', // auto / win / lose
        'force_result' => '',
        'fee_percent' => 0.0,
        'payout_number' => 9.0,
        'payout_color' => 2.0,
        'payout_violet' => 4.5,
        'payout_bigsmall' => 2.0,
        'payout_k3' => 2.0,
        'payout_5d' => 9.5,
        'payout_moto' => 9.5,
        'immediate_settle' => 0,
    ];
}

function le_get_settings(string $gameCode): array
{
    $s = le_default_settings();
    $conn = db();
    if (!$conn) return $s;
    $stmt = @$conn->prepare('SELECT * FROM lottery_game_settings WHERE game_code=? OR game_code="*" ORDER BY game_code="*" ASC LIMIT 1');
    if (!$stmt) return $s;
    $stmt->bind_param('s', $gameCode);
    if (!$stmt->execute()) return $s;
    $row = $stmt->get_result()->fetch_assoc();
    if (!$row) return $s;
    foreach ($s as $k => $v) {
        if (array_key_exists($k, $row) && $row[$k] !== null && $row[$k] !== '') {
            $s[$k] = is_numeric($v) ? (float)$row[$k] : $row[$k];
        }
    }
    $s['immediate_settle'] = (int)($row['immediate_settle'] ?? 1);
    return $s;
}

// =======================================================================
// FIX #8 — EK HI PERIOD NUMBER, HAR JAGAH  (2026-10-08)
//   ASLI PROBLEM (live me naapi gayi):
//       /api/Lottery/GetGameIssue      (game screen / timer) : 20261008100051036
//       /api/Lottery/GetHistoryIssuePage (drawer / history)  : 20261008100014952
//     Dono alag-alag function period number bana rahe the
//     (lottery_issue() bootstrap me, le_issue_by_offset() engine me), isliye
//     "game ka period/result" aur "drawer ka period/result" ALAG dikhta tha.
//   FIX:
//     Ab EK hi function (le_issue_for_time) se period number banta hai —
//     game screen, drawer, trend, bet aur settlement sabhi ke liye.
// =======================================================================
// =======================================================================
// FIX #10 — PERIOD NUMBER BILKUL UPSTREAM (draw.ar-lottery01.com) JAISA
//
//   NAAPA HUA FORMULA (08-Oct-2026 14:44 IST, teeno game ek hi second me):
//       issue = date('Ymd', slot*interval) + MID + pad((slot + C) % 100000)
//       slot  = floor(unix / interval)
//       MID   : WinGo 1000 | K3 1010 | D5 1020 | TrxWinGo 1030 | MotoRace 1050
//       C     : 30s 36080 | 1m 53040 | 3m 67680 | 5m 58608 | 10m 54304
//
//   Isse local period number == drawer (upstream) ka period number.
//   Upar se le_issue_drift() upstream ki nayi row se correction lagata hai,
//   taaki kabhi bhi farq na pade.
// =======================================================================
function le_issue_mid(string $gameCode): string
{
    $c = strtolower(trim($gameCode));
    if (strpos($c, 'trxwingo') === 0) return '1030';
    if (strpos($c, 'k3') === 0)       return '1010';
    if (strpos($c, '5d') === 0)       return '1020';
    if (strpos($c, 'd5') === 0)       return '1020';
    if (strpos($c, 'motorace') === 0) return '1050';
    if (strpos($c, 'moto') === 0)     return '1050';
    return '1000';
}

function le_issue_offset(string $gameCode): int
{
    $map = [
        30  => 36080,   // 30 second
        60  => 53040,   // 1 minute
        180 => 67680,   // 3 minute
        300 => 58608,   // 5 minute
        600 => 54304,   // 10 minute
    ];
    $iv = le_game_interval($gameCode);
    return isset($map[$iv]) ? (int)$map[$iv] : 0;
}

// =======================================================================
// FIX #18 — API KA COUNTER ROZ UTC MIDNIGHT PAR RESET HOTA HAI  <<< ASLI
//
//   PURANA FORMULA:  tail = (absolute_slot + C) % 100000
//     Ye 08-Oct ko coincidentally sahi number deta tha, par UTC midnight
//     ke baad tail "ek din ke period" (30S me 2880) AAGE nikal jata tha:
//         API : 20261009100050627      site : 20261009100053507
//     -> result ki tail-match miss -> RANDOM result -> DB me pakka ->
//        baad me repair -> "result apne aap badal gaya".
//
//   ASLI FORMULA (drawer ke 6 live points se naap kar nikalaa):
//         tail = floor((ts - UTC_midnight) / interval) + BASE
//         issue = gmdate('Ymd', ts) + MID + pad(tail, 5)
// =======================================================================
function le_issue_base(string $gameCode): int
{
    // interval ke hisaab se counter kahan se shuru hota hai (UTC 00:00)
    $map = [
        30  => 50000,   // 30 second
        60  => 10000,   // 1 minute
        180 => 20000,   // 3 minute
        300 => 30000,   // 5 minute
        600 => 40000,   // 10 minute
    ];
    $iv = le_game_interval($gameCode);
    return isset($map[$iv]) ? (int)$map[$iv] : 10000;
}

/** UTC midnight ka unix time (unix din ki shuruat hi UTC midnight hai) */
function le_issue_day_start(int $ts): int
{
    return intdiv($ts, 86400) * 86400;
}

/** API wala 5-digit counter (bina drift/shift ke) */
function le_issue_tail(string $gameCode, int $ts): int
{
    $interval = le_game_interval($gameCode);
    $ssm = $ts - le_issue_day_start($ts);
    if ($ssm < 0) $ssm = 0;
    return intdiv($ssm, $interval) + le_issue_base($gameCode);
}

/**
 * Upstream (draw.ar-lottery01.com) ki sabse NAYI row se correction.
 * 2 minute cache. Network/403/slow => 0 (tab formula hi kaafi hai).
 */
function le_issue_drift(string $gameCode): int
{
    static $mem = [];
    if (array_key_exists($gameCode, $mem)) return $mem[$gameCode];
    $mem[$gameCode] = 0;
    if (!function_exists('le_upstream_enabled') || !le_upstream_enabled()) return 0;
    if (!function_exists('le_upstream_newest') || !function_exists('le_upstream_cache_file')) return 0;

    $file = le_upstream_cache_file('drift_' . md5($gameCode));
    if (is_file($file)) {
        $c = json_decode((string)@file_get_contents($file), true);
        if (is_array($c) && isset($c['t'], $c['d']) && (time() - (int)$c['t']) <= 120) {
            $mem[$gameCode] = (int)$c['d'];
            return $mem[$gameCode];
        }
    }
    // FIX #17 — DRIFT KE LIYE HAMESHA TAZA (bina cache) DATA.
    //   Cache purana hone par "sabse nayi row" PICHLE period ki mil jati
    //   thi -> drift = -1 -> site ka period number apne aap EK PICHE
    //   chala jata tha aur DRIFT CACHE 120 SECOND tak wahin atka rehta
    //   tha. YAHI "period apne aap badal jata hai" KI WAJAH THI.
    //   Har 2 minute me ek HTTP call — isse zyada nahi.
    $interval   = le_game_interval($gameCode);
    $slotBefore = intdiv(time(), $interval);
    $fresh = function_exists('le_upstream_page1_fresh') ? le_upstream_page1_fresh($gameCode) : [];
    $row = isset($fresh[0]) && is_array($fresh[0]) ? $fresh[0] : le_upstream_newest($gameCode);
    if (!is_array($row)) return 0;
    $up = trim((string)($row['issueNumber'] ?? $row['issueNo'] ?? $row['period'] ?? ''));
    if ($up === '') return 0;

    $tailOf = function (int $slot) use ($gameCode): int {
        return le_issue_tail($gameCode, $slot * le_game_interval($gameCode));
    };
    $upTail = (int)substr($up, -5);
    $d1 = $upTail - $tailOf($slotBefore);                 // fetch se PAHLE ka slot
    $d2 = $upTail - $tailOf(intdiv(time(), $interval));   // fetch ke BAAD ka slot
    if ($d1 > 50000) $d1 -= 100000;
    if ($d1 < -50000) $d1 += 100000;
    if ($d2 > 50000) $d2 -= 100000;
    if ($d2 < -50000) $d2 += 100000;
    // fetch aur hisaab ke beech period badal gaya ho to 0 hi sahi hai
    $d = ($d1 === 0 || $d2 === 0) ? 0 : $d2;
    if ($d > 5 || $d < -5) $d = 0;          // pagal value => formula hi theek hai

    @file_put_contents($file, json_encode(['t' => time(), 'd' => $d]), LOCK_EX);
    $mem[$gameCode] = $d;
    return $d;
}

// =======================================================================
// FIX #13 — PERIOD NUMBER KI DATE  (API = UTC, site = apni timezone)
//
//   draw.ar-lottery01.com apna period number UTC date se banata hai.
//   Site IST date se banati thi. Subah 00:00-05:30 IST ke beech dono me
//   EK DIN ka farq pad jata tha:
//        API : 20261008100011251      site : 20261009100011251
//   Natija: period number alag + API me result ki lookup miss (result random).
//   Ab date bhi API jaisi (gmdate) banegi, to number AUR result DONO same.
// =======================================================================
function le_issue_date_tz(): string
{
    if (!defined('LE_ISSUE_DATE_TZ')) return 'utc';
    $v = strtolower(trim((string)LE_ISSUE_DATE_TZ));
    return ($v === 'local' || $v === 'site') ? 'local' : 'utc';
}

/** period number ki 8-digit date — 'utc' ho to API jaisi (gmdate) */
function le_issue_date(int $ts): string
{
    return le_issue_date_tz() === 'local' ? date('Ymd', $ts) : gmdate('Ymd', $ts);
}

/** date me $delta din jodo/ghatao — server ki timezone se bilkul azaad */
function le_issue_shift_day(string $date, int $delta): string
{
    if (!preg_match('/^(\d{4})(\d{2})(\d{2})$/', $date, $m)) return $date;
    $ts = gmmktime(0, 0, 0, (int)$m[2], (int)$m[3], (int)$m[1]) + ($delta * 86400);
    return gmdate('Ymd', $ts);
}

/** bina drift ke (drift function ke andar use hota hai — recursion se bachne ke liye) */
function le_issue_slot_number(string $gameCode, int $slot): string
{
    $interval = le_game_interval($gameCode);
    $n = le_issue_tail($gameCode, $slot * $interval);
    return le_issue_date($slot * $interval) . le_issue_mid($gameCode) . str_pad((string)$n, 5, '0', STR_PAD_LEFT);
}

function le_issue_for_time(int $ts, string $gameCode = ''): string
{
    $interval = le_game_interval($gameCode);
    $slot     = intdiv($ts, $interval);
    $start    = $slot * $interval;
    $per      = intdiv(86400, $interval);          // ek din me kitne period
    $base     = le_issue_base($gameCode);
    // FIX #12: PERIOD + RESULT DONO EK SATH piche -> LE_PERIOD_SHIFT yahan.
    $idx = intdiv($start - le_issue_day_start($start), $interval)
         + le_issue_drift($gameCode) + le_period_shift();
    $day = le_issue_day_start($start);
    // din ki had paar kare to date bhi saath badlo (30S: 50000-1 = pichle
    // din ka 52879)
    if ($per > 0) {
        while ($idx < 0)    { $idx += $per; $day -= 86400; }
        while ($idx >= $per){ $idx -= $per; $day += 86400; }
    }
    if ($idx < 0) $idx = 0;
    return le_issue_date($day) . le_issue_mid($gameCode) . str_pad((string)($base + $idx), 5, '0', STR_PAD_LEFT);
}

/**
 * FIX #18 — ek period PICHLE, lekin DIN KI HAD ka dhyan rakhte hue.
 *   API ka counter roz UTC 00:00 par BASE se shuru hota hai, isliye
 *   30S ka 50000-1 = PICHLE DIN ka 52879 hota hai (49999 nahi).
 */
function le_issue_prev_game(string $issue, string $gameCode): string
{
    $issue = trim((string)$issue);
    if (!preg_match('/^(\d{8})(\d{4})(\d{5})$/', $issue, $m)) return '';
    $date = $m[1];
    $mid  = $m[2];
    $tail = (int)$m[3] - 1;
    $base = le_issue_base($gameCode);
    if ($tail < $base) {
        $per = intdiv(86400, le_game_interval($gameCode));
        if ($per > 0) {
            $tail = $base + $per - 1;
            $date = le_issue_shift_day($date, -1);
        }
    }
    return $date . $mid . str_pad((string)$tail, 5, '0', STR_PAD_LEFT);
}

function le_issue_by_offset(string $gameCode, int $offset = 0): string
{
    $interval = le_game_interval($gameCode);
    return le_issue_for_time(time() - ($offset * $interval), $gameCode);
}

// =======================================================================
// FIX #5 — Period history me PERIOD NUMBER aur RESULT ka MILAN
//
//   PURANI PROBLEM:
//     History/period list me har row ka issue number alag-alag
//     le_issue_by_offset($code, $offset) se nikalta tha. Bade offset par
//     (jaise offset 10) wo GALAT number de deta hai — offset 10 par
//     CURRENT period ka number aa jata tha. Natija:
//        ...584, 583, 582, 581, 580, 579, 578, 577, 576, 585   <-- galti
//     Isse list me period number aur uska result aapas me match nahi
//     karte the ("period aur result dusra-dusra").
//
//   FIX:
//     Sirf PEHLA number le_issue_by_offset() se lo, uske baad har agli
//     row ko EK period piche le jao (le_issue_prev). Isse list hamesha
//     lagataar (consecutive) rahegi.
// =======================================================================
function le_issue_prev(string $issue): string
{
    $issue = trim((string)$issue);
    // Format: YYYYMMDD + '1000' + 5-digit counter   (17 digits)
    if (!preg_match('/^(\d{8})(\d{4})(\d{5})$/', $issue, $m)) return '';
    $date = $m[1];
    $mid  = $m[2];
    $tail = (int)$m[3] - 1;
    if ($tail < 0) {
        $tail = 99999;
        $date = le_issue_shift_day($date, -1);
    }
    return $date . $mid . str_pad((string)$tail, 5, '0', STR_PAD_LEFT);
}

/**
 * $startOffset se shuru kar ke $count LAGATAAR period numbers.
 * Pehla number le_issue_by_offset() se, baaki usse ek-ek piche.
 */
function le_issue_sequence(string $gameCode, int $startOffset, int $count): array
{
    $out = [];
    if ($count <= 0) return $out;
    if ($startOffset < 0) $startOffset = 0;
    $cur = le_issue_by_offset($gameCode, $startOffset);
    if ($cur === '' || $cur === null) return $out;
    $cur = (string)$cur;
    $out[] = $cur;
    for ($i = 1; $i < $count; $i++) {
        $prev = function_exists('le_issue_prev_game') ? le_issue_prev_game($cur, $gameCode) : '';
        if ($prev === '') $prev = le_issue_prev($cur);
        if ($prev === '') $prev = (string)le_issue_by_offset($gameCode, $startOffset + $i);
        $cur = $prev;
        $out[] = $cur;
    }
    return $out;
}

/**
 * Period-history ka EK HI hisaab.
 *   /api/Lottery/GetHistoryIssuePage        (api/_router.php)
 *   /WinGo/<game>/GetHistoryIssuePage.json  (api/_draw_router.php)
 * DONO isi function se list banate hain, isliye drawer aur game me kabhi bhi
 * alag period / alag result nahi aa sakta.  (FIX #8)
 */
function le_history_page(string $gameCode, int $pageNo, int $pageSize): array
{
    $pageNo   = max(1, (int)$pageNo);
    $pageSize = max(1, min(10, (int)$pageSize));
    $interval = le_game_interval($gameCode);

    $shift = function_exists('le_history_start_offset') ? le_history_start_offset($gameCode) : 1;
    $startOffset = (($pageNo - 1) * $pageSize) + $shift;
    if ($startOffset < 0) $startOffset = 0;

    $issues = le_issue_sequence($gameCode, $startOffset, $pageSize);
    $list = [];
    for ($i = 0; $i < $pageSize; $i++) {
        $offset = $startOffset + $i;
        $issue  = isset($issues[$i]) ? (string)$issues[$i] : (string)le_issue_by_offset($gameCode, $offset);
        $r = le_result_for_issue($gameCode, $issue, true);
        $list[] = lottery_public_result($gameCode, $issue, $r, now_ms() - ($offset * $interval * 1000));
    }
    return ['list' => $list, 'pageNo' => $pageNo, 'pageSize' => $pageSize];
}

// =======================================================================
// FIX #9 — DRAWER (draw.ar-lottery01.com) AUR GAME — EK HI PERIOD / RESULT
//
//   Frontend me axios interceptor .json wali requests ko
//   https://draw.ar-lottery01.com par bhejta hai (DRAWER = wahi data),
//   lekin /webapi/kv/issue LOCAL server se aata hai (GAME = local period).
//   Do alag source => period number aur result DONO ALAG.
//
//   Ab local backend bhi upstream ka data use karega:
//     * lottery_issue()       -> upstream ka issueNumber / startTime / endTime
//     * le_result_for_issue() -> upstream ka result (DB me bhi save)
//   Cache: file based (2-3 sec) — har user ke liye alag HTTP call nahi jati.
//   Upstream na mile / 403 de / time-out ho => PURANA local hisaab (safe).
// =======================================================================
function le_upstream_enabled(): bool
{
    return defined('LE_UPSTREAM_RESULTS') && LE_UPSTREAM_RESULTS
        && defined('LE_UPSTREAM_BASE') && trim((string)LE_UPSTREAM_BASE) !== '';
}

function le_upstream_base(): string
{
    return rtrim((string)(defined('LE_UPSTREAM_BASE') ? LE_UPSTREAM_BASE : ''), '/');
}

/** WinGo_1M -> WinGo, K3_1M -> K3, D5_1M -> D5 ... (upstream URL ka pehla hissa) */
function le_upstream_family(string $gameCode): string
{
    $c = strtolower(trim($gameCode));
    if (strpos($c, 'trxwingo') === 0) return 'TrxWinGo';
    if (strpos($c, 'wingo') === 0)    return 'WinGo';
    if (strpos($c, 'k3') === 0)       return 'K3';
    if (strpos($c, '5d') === 0)       return 'D5';
    if (strpos($c, 'd5') === 0)       return 'D5';
    if (strpos($c, 'motorace') === 0) return 'MotoRace';
    if (strpos($c, 'moto') === 0)     return 'MotoRace';
    return 'WinGo';
}

function le_upstream_cache_file(string $key): string
{
    $dir = '';
    if (function_exists('sys_get_temp_dir')) { $d = @sys_get_temp_dir(); if (is_string($d) && $d !== '') $dir = $d; }
    if ($dir === '') $dir = __DIR__;
    return rtrim($dir, '/') . '/maanup_' . $key . '.json';
}

/**
 * Upstream se JSON lao. Cache file me rakho (LE_UPSTREAM_CACHE_SEC second).
 * Fail hone par thodi der (30 sec) tak dobara call nahi karega.
 * @param bool $raw  true = cached body use mat karo (diagnostic ke liye)
 * @return array|null
 */
function le_upstream_get(string $path, int $ttl = 0, bool $raw = false, bool $force = false): ?array
{
    static $mem = [];
    if (!le_upstream_enabled()) return null;
    $path = '/' . ltrim($path, '/');
    $url  = le_upstream_base() . $path;
    if ($ttl <= 0) $ttl = (int)(defined('LE_UPSTREAM_CACHE_SEC') ? LE_UPSTREAM_CACHE_SEC : 3);
    if ($ttl < 1) $ttl = 1;
    $failTtl = 30;

    $file  = le_upstream_cache_file(md5($url));
    $ffile = $file . '.fail';
    // FIX #16 — purana (stale) data yaad rakho. Cache expire ho jaye ya
    // upstream slow/403 ho, tab bhi PURANA data hi de dete hain: result
    // galat nahi hota (period ka result badalta nahi) aur LATENCY nahi
    // badhti — popup 5 second late hone ki wajah yahi thi.
    $stale = null;
    if (!$raw && !$force && isset($mem[$url])) {
        $m = $mem[$url];
        if (is_array($m) && (time() - (int)$m[0]) <= $ttl) return $m[1];
    }
    if (!$raw && !$force && is_file($file)) {
        $age = time() - (int)@filemtime($file);
        $txt = @file_get_contents($file);
        if (is_string($txt) && $txt !== '') {
            $c = json_decode($txt, true);
            if (is_array($c) && isset($c['t'], $c['data']) && is_array($c['data'])) {
                $stale = $c['data'];
                if ($age <= $ttl) {
                    $mem[$url] = [time(), $stale];
                    return $stale;
                }
            }
        }
    }
    // pichli call fail hui thi to thodi der tak dobara mat karo —
    // purana data hi de do (site rukti nahi).
    if (!$raw && !$force && is_file($ffile)) {
        $age = time() - (int)@filemtime($ffile);
        if ($age <= $failTtl) {
            $mem[$url] = [time(), $stale];
            return $stale;
        }
    }

    $timeout = (int)(defined('LE_UPSTREAM_TIMEOUT') ? LE_UPSTREAM_TIMEOUT : 3);
    if ($timeout < 1) $timeout = 1;
    if ($timeout > 10) $timeout = 10;
    $base = le_upstream_base();
    $hdr  = [
        'Accept: application/json, text/plain, */*',
        'Origin: ' . $base,
        'Referer: ' . $base . '/',
        'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36',
    ];
    $body = null;
    if (function_exists('curl_init')) {
        $ch = @curl_init($url);
        if ($ch) {
            @curl_setopt_array($ch, [
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_FOLLOWLOCATION => true,
                CURLOPT_CONNECTTIMEOUT => $timeout,
                CURLOPT_TIMEOUT        => $timeout + 2,
                CURLOPT_SSL_VERIFYPEER => false,
                CURLOPT_SSL_VERIFYHOST => false,
                CURLOPT_HTTPHEADER     => $hdr,
            ]);
            $b = @curl_exec($ch);
            @curl_close($ch);
            if (is_string($b)) $body = $b;
        }
    }
    if (($body === null || $body === '') && (int)ini_get('allow_url_fopen') === 1) {
        $ctx = @stream_context_create([
            'http' => ['method' => 'GET', 'timeout' => $timeout, 'header' => implode("\r\n", $hdr)],
            'ssl'  => ['verify_peer' => false, 'verify_peer_name' => false],
        ]);
        $b = @file_get_contents($url, false, $ctx);
        if (is_string($b)) $body = $b;
    }

    if (!is_string($body) || trim($body) === '') {
        // FIX #16 — fail marker ALAG file me, taaki purana data bacha rahe
        if (!$raw) @file_put_contents($ffile, json_encode(['t' => time()]), LOCK_EX);
        $mem[$url] = [time(), $stale];
        return $stale;
    }
    $json = json_decode($body, true);
    if (!is_array($json)) {
        if (!$raw) @file_put_contents($ffile, json_encode(['t' => time()]), LOCK_EX);
        $mem[$url] = [time(), $stale];
        return $stale;
    }
    if (!$raw) {
        @file_put_contents($file, json_encode(['t' => time(), 'fail' => 0, 'data' => $json]), LOCK_EX);
        if (is_file($ffile)) @unlink($ffile);
    }
    $mem[$url] = [time(), $json];
    return $json;
}

/** upstream ki CURRENT issue: /webapi/kv/issue/<game> */
function le_upstream_issue(string $gameCode): ?array
{
    if (!le_upstream_enabled()) return null;
    $j = le_upstream_get('/webapi/kv/issue/' . rawurlencode($gameCode), 2);
    if (!is_array($j)) return null;
    $d = $j['data'] ?? null;
    if (!is_array($d)) return null;
    $issue = trim((string)($d['issueNumber'] ?? $d['issueNo'] ?? $d['issue'] ?? $d['period'] ?? ''));
    if ($issue === '') return null;
    return $d;
}

/** upstream ki history — ORDERED list (nayi row sabse pehle). 2 page = 20 period */
function le_upstream_rows(string $gameCode): array
{
    static $mem = [];
    if (!le_upstream_enabled()) return [];
    if (isset($mem[$gameCode])) return $mem[$gameCode];
    $rows = [];
    $fam = le_upstream_family($gameCode);
    $pages = (int)(defined('LE_UPSTREAM_PAGES') ? LE_UPSTREAM_PAGES : 3);
    if ($pages < 1) $pages = 1;
    if ($pages > 5) $pages = 5;
    for ($p = 1; $p <= $pages; $p++) {
        $j = le_upstream_get('/' . $fam . '/' . rawurlencode($gameCode) . '/GetHistoryIssuePage.json?pageNo=' . $p . '&pageSize=10');
        $list = (is_array($j) && isset($j['data']['list']) && is_array($j['data']['list'])) ? $j['data']['list'] : [];
        foreach ($list as $row) {
            if (is_array($row)) $rows[] = $row;
        }
    }
    $mem[$gameCode] = $rows;
    return $rows;
}

/** upstream ki SABSE NAYI row (= current period, upstream row0 current hota hai) */
function le_upstream_newest(string $gameCode): ?array
{
    $rows = le_upstream_rows($gameCode);
    return (isset($rows[0]) && is_array($rows[0])) ? $rows[0] : null;
}

/** upstream ki history: issueNumber => row */
function le_upstream_results(string $gameCode): array
{
    static $mem = [];
    if (isset($mem[$gameCode])) return $mem[$gameCode];
    $out = [];
    foreach (le_upstream_rows($gameCode) as $row) {
        $num = trim((string)($row['issueNumber'] ?? $row['issueNo'] ?? $row['period'] ?? ''));
        if ($num !== '') $out[$num] = $row;
    }
    $mem[$gameCode] = $out;
    return $out;
}

/**
 * FIX #13 — API (drawer) se EK period ka result dhoondo.
 *
 *   Sirf PURE issue number se matlab rakha to date ka ek din ka farq
 *   (ya koi bhi chhota farq) poora match gira deta hai — tab result
 *   RANDOM ban jata tha. Ab LAST 5 DIGIT (tail) se bhi match hota hai,
 *   isliye 20261009100011250 aur 20261008100011250 EK HI period hain.
 *
 * @return string  premium ('' = API me ye period hai hi nahi)
 */
/**
 * page 1 BINA CACHE PADHE lao (naya period turant mil jaye).
 * Disk cache bhi refresh ho jata hai, isliye BAAKI sab requests ko bhi
 * taza data milta hai. Ek request me ek game ke liye SIRF EK BAAR.
 */
function le_upstream_page1_fresh(string $gameCode): array
{
    static $cache = [];
    if (!le_upstream_enabled()) return [];
    if (array_key_exists($gameCode, $cache)) return $cache[$gameCode];
    $cache[$gameCode] = [];
    $fam = le_upstream_family($gameCode);
    $j = le_upstream_get('/' . $fam . '/' . rawurlencode($gameCode) . '/GetHistoryIssuePage.json?pageNo=1&pageSize=10', 0, false, true);
    $list = (is_array($j) && isset($j['data']['list']) && is_array($j['data']['list'])) ? $j['data']['list'] : [];
    $cache[$gameCode] = $list;
    return $list;
}

// =======================================================================
// FIX #20 — WIN / LOSS POPUP THEEK TIMER 0 PAR
//
//   draw.ar-lottery01.com apni pehli row me ABHI CHAL RAHE period ka
//   result PEHLE SE publish kar deta hai (maandiag [13] me dikh raha hai:
//   "API row0 (abhi chal raha) : ... result=6").  Matlab period band hone
//   se kayi second pehle hi ASLI result hamare paas hota hai.
//
//   Phir bhi bet tabhi settle hota tha jab period BAND ho jata tha, isliye
//   /Lottery/GetWinLossResult timer 0 ke 3-5 second baad tak `status:null`
//   bhejta raha -> popup late dikhta tha.
//
//   Ye function bas yahi poochhta hai:
//       "is period ka ASLI API result abhi available hai?"
//   Haan  -> bet wahin settle kar sakte hain -> popup TIMER 0 par.
//   Nahi  -> purana tarika (period band hone par settle).
//
//   SURAKSHA: DB me pada hua ya RANDOM result kabhi 'ready' nahi mana jata.
// =======================================================================
function le_upstream_result_ready(string $gameCode, string $issueNumber): bool
{
    $gameCode = trim((string)$gameCode);
    $issueNumber = trim((string)$issueNumber);
    if ($gameCode === '' || $issueNumber === '') return false;
    if (!function_exists('le_upstream_enabled') || !le_upstream_enabled()) return false;
    if (!function_exists('le_upstream_result_for')) return false;
    $premium = le_upstream_result_for($gameCode, $issueNumber);
    return is_string($premium) && $premium !== '';
}

function le_upstream_result_for(string $gameCode, string $issueNumber): string
{
    if (!le_upstream_enabled()) return '';
    $issueNumber = trim((string)$issueNumber);
    if ($issueNumber === '' || strlen($issueNumber) < 5) return '';
    $tail = substr($issueNumber, -5);

    $find = function (array $rows) use ($issueNumber, $tail) {
        foreach ($rows as $row) {
            if (!is_array($row)) continue;
            $num = trim((string)($row['issueNumber'] ?? $row['issueNo'] ?? $row['period'] ?? ''));
            if ($num === '') continue;
            if ($num === $issueNumber || substr($num, -5) === $tail) {
                $p = (string)($row['premium'] ?? $row['number'] ?? $row['result'] ?? '');
                if ($p !== '') return $p;
            }
        }
        return null;
    };

    $rows = le_upstream_rows($gameCode);
    $p = $find($rows);
    if ($p !== null) return $p;

    // FIX #17 — CACHE PURANA HONE PAR NAYA PERIOD NAHI MILTA THA.
    //   Tab RANDOM result ban kar DB me pakka ho jata tha, aur baad me
    //   asli result aane par DB badal jata tha ("result apne aap badal
    //   gaya"). Ab page 1 EK BAAR FRESH mangwate hain -> naya period
    //   turant mil jata hai -> random kabhi nahi banta.
    //   (bahut purane period ke liye bekar ka HTTP call nahi karte)
    $newest = isset($rows[0]) && is_array($rows[0]) ? trim((string)($rows[0]['issueNumber'] ?? '')) : '';
    if ($newest !== '') {
        $dist = ((int)substr($newest, -5)) - ((int)$tail);
        if ($dist > 50000) $dist -= 100000;
        if ($dist < -50000) $dist += 100000;
        if ($dist < -2 || $dist > 40) return '';   // purana period: DB se hi milega
    }
    if (function_exists('le_upstream_page1_fresh')) {
        $fresh = le_upstream_page1_fresh($gameCode);
        if ($fresh) {
            $p = $find($fresh);
            if ($p !== null) return $p;
        }
    }
    return '';
}

// =======================================================================
// FIX #11 — RESULT KO EK PERIOD PICHE KARNA
//   Period N chal raha ho to result (N-1) ka dikhana hai, taaki current
//   period ka result timer khatam hone se pehle na dikhe.
//   Shift EK HI jagah (le_result_for_issue) me lagaya gaya hai, isliye
//   game screen, period history, trend aur settlement SABHI ko ek hi
//   result milega — kahin mismatch nahi ho sakta.
// =======================================================================
function le_result_shift(): int
{
    if (!defined('LE_RESULT_SHIFT')) return -1;
    $n = (int)LE_RESULT_SHIFT;
    if ($n > 5)  $n = 5;
    if ($n < -5) $n = -5;
    return $n;
}

/**
 * FIX #12 — site API se kitne period PICHE chale (-1 = ek period piche).
 * Ye sirf period ke NUMBER (label) par lagta hai; start/end time (timer)
 * wahi rahta hai, isliye countdown kabhi galat nahi hota.
 */
function le_period_shift(): int
{
    if (!defined('LE_PERIOD_SHIFT')) return -1;
    $n = (int)LE_PERIOD_SHIFT;
    if ($n > 5)  $n = 5;
    if ($n < -5) $n = -5;
    return $n;
}

function le_issue_next(string $issue): string
{
    $issue = trim((string)$issue);
    if (!preg_match('/^(\d{8})(\d{4})(\d{5})$/', $issue, $m)) return '';
    $date = $m[1];
    $mid  = $m[2];
    $tail = (int)$m[3] + 1;
    if ($tail > 99999) {
        $tail = 0;
        $date = le_issue_shift_day($date, 1);
    }
    return $date . $mid . str_pad((string)$tail, 5, '0', STR_PAD_LEFT);
}

/** issue number me $delta period jodo (negative = piche) */
function le_issue_add(string $issue, int $delta): string
{
    if ($delta === 0) return $issue;
    $cur  = $issue;
    $steps = abs($delta);
    if ($steps > 60) $steps = 60;
    for ($i = 0; $i < $steps; $i++) {
        $cur = ($delta > 0) ? le_issue_next($cur) : le_issue_prev($cur);
        if ($cur === '') return $issue;
    }
    return $cur;
}

/** result kis period ka dikhana hai (shift lagane ke baad) */
function le_result_issue_for(string $gameCode, string $issueNumber): string
{
    $shift = le_result_shift();
    if ($shift === 0) return $issueNumber;
    $out = le_issue_add($issueNumber, $shift);
    return $out !== '' ? $out : $issueNumber;
}

/** result row ko lottery_results me save (INSERT IGNORE) */
function le_result_save(string $gameCode, string $issueNumber, array $detail, bool $overwrite = false): void
{
    $conn = db();
    if (!$conn || $issueNumber === '') return;
    if (function_exists('le_ensure_lottery_results_table')) le_ensure_lottery_results_table($conn);
    $premium  = (string)$detail['premium'];
    $number   = (string)$detail['number'];
    $color    = (string)$detail['color'];
    $bigSmall = (string)$detail['bigSmall'];
    $sum      = (int)$detail['sum'];
    $stmt = @$conn->prepare('INSERT IGNORE INTO lottery_results(game_code, issue_number, premium, number, color, big_small, sum_value, open_time, created_at) VALUES(?,?,?,?,?,?,?,NOW(),NOW())');
    if (!$stmt) return;
    @$stmt->bind_param('ssssssi', $gameCode, $issueNumber, $premium, $number, $color, $bigSmall, $sum);
    @$stmt->execute();

    // FIX #13 — API ka result mil gaya to DB me bhi WAHII likho, chahe pehle
    // koi aur (random) result kyon na likha gaya ho. Isse history me hamesha
    // API wala hi result dikhega.
    if ($overwrite) {
        $u = @$conn->prepare('UPDATE lottery_results SET premium=?, number=?, color=?, big_small=?, sum_value=? WHERE game_code=? AND issue_number=? AND premium<>?');
        if ($u) {
            @$u->bind_param('ssssisss', $premium, $number, $color, $bigSmall, $sum, $gameCode, $issueNumber, $premium);
            @$u->execute();
        }
    }
}

function le_color_from_number(int $n): string
{
    if ($n === 0) return 'red,violet';
    if ($n === 5) return 'green,violet';
    return ($n % 2 === 0) ? 'red' : 'green';
}

function le_result_detail(string $gameCode, string $premium, string $issueNumber = ''): array
{
    if (le_is_moto($gameCode)) {
        $parts = array_values(array_filter(array_map('trim', explode(',', $premium)), 'strlen'));
        $first = (int)($parts[0] ?? 1);
        return [
            'issueNumber' => $issueNumber,
            'premium' => $premium,
            'number' => $premium,
            'firstNumber' => $first,
            'color' => $first % 2 ? 'green' : 'red',
            'bigSmall' => $first > 5 ? 'big' : 'small',
            'sum' => array_sum(array_map('intval', $parts)),
        ];
    }
    if (le_is_k3($gameCode)) {
        $normalised = str_replace(['|','-',' '], ',', trim($premium));
        $parts = array_values(array_filter(array_map('trim', explode(',', $normalised)), 'strlen'));
        if (count($parts) === 1 && preg_match('/^[1-6]{3}$/', (string)$parts[0])) $parts = str_split((string)$parts[0]);
        $valid = count($parts) === 3 && count(array_filter($parts, fn($n)=>(int)$n >= 1 && (int)$n <= 6)) === 3;
        if (!$valid) $parts = [random_int(1,6), random_int(1,6), random_int(1,6)];
        $sum = array_sum(array_map('intval', $parts));
        return [
            'issueNumber' => $issueNumber,
            'premium' => implode(',', $parts),
            'number' => implode('', $parts),
            'dice' => $parts,
            'color' => $sum % 2 ? 'green' : 'red',
            'bigSmall' => $sum >= 11 ? 'big' : 'small',
            'sum' => $sum,
        ];
    }
    if (le_is_d5($gameCode)) {
        $digits = preg_replace('/\D+/', '', $premium);
        if (strlen($digits) < 5) $digits = str_pad($digits, 5, (string)random_int(0,9));
        $digits = substr($digits, 0, 5);
        $arr = array_map('intval', str_split($digits));
        $sum = array_sum($arr);
        return [
            'issueNumber' => $issueNumber,
            'premium' => $digits,
            'number' => $digits,
            'color' => $sum % 2 ? 'green' : 'red',
            'bigSmall' => $sum >= 23 ? 'big' : 'small',
            'sum' => $sum,
        ];
    }
    $n = (int)preg_replace('/\D+/', '', $premium);
    $n = max(0, min(9, $n));
    return [
        'issueNumber' => $issueNumber,
        'premium' => (string)$n,
        'number' => (string)$n,
        'color' => le_color_from_number($n),
        'bigSmall' => $n > 4 ? 'big' : 'small',
        'sum' => $n,
    ];
}

function le_random_premium(string $gameCode): string
{
    if (le_is_moto($gameCode)) { $nums = range(1, 10); shuffle($nums); return implode(',', $nums); }
    if (le_is_k3($gameCode)) return implode(',', [random_int(1,6), random_int(1,6), random_int(1,6)]);
    if (le_is_d5($gameCode)) return implode('', [random_int(0,9), random_int(0,9), random_int(0,9), random_int(0,9), random_int(0,9)]);
    return (string)random_int(0, 9);
}

function le_ensure_lottery_results_table($conn) {
    static $ensured = false;
    if ($ensured) return;
    $ensured = true;
    $conn->query("CREATE TABLE IF NOT EXISTS lottery_results (
      id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
      game_code VARCHAR(50) NOT NULL,
      issue_number VARCHAR(50) NOT NULL,
      premium VARCHAR(20) NOT NULL,
      number VARCHAR(20) NOT NULL,
      color VARCHAR(20) NOT NULL,
      big_small VARCHAR(20) NOT NULL,
      sum_value INT NOT NULL,
      open_time DATETIME NULL,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      UNIQUE KEY uq_game_issue (game_code, issue_number)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
}

function le_result_for_issue(string $gameCode, string $issueNumber, bool $save = true): array
{
    // FIX #11 — result ek period PICHE. Shift yahin lagaya gaya hai, isliye
    // game screen / history / trend / settlement sabko EK HI result milega.
    $issueNumber = le_result_issue_for($gameCode, $issueNumber);

    $conn = db();
    if ($conn) le_ensure_lottery_results_table($conn);

    // FIX #13 — DRAWER (API) KA RESULT SABSE UPAR.
    //   PURANA ORDER (galat): DB pehle, upstream baad me. Ek bar period ka
    //   result nahi mila to RANDOM ban kar DB me pakka ho gaya, aur phir
    //   hamesha wahi galat number dikha — chahe API kuch aur kahe.
    //   NAYA ORDER: API -> DB -> naya random. API ka result mile to DB me
    //   bhi theek (repair) kar diya jata hai.
    if (le_upstream_enabled() && function_exists('le_upstream_result_for')) {
        $upPremium = le_upstream_result_for($gameCode, $issueNumber);
        if ($upPremium !== '') {
            $upDetail = le_result_detail($gameCode, $upPremium, $issueNumber);
            le_result_save($gameCode, $issueNumber, $upDetail, true);
            return $upDetail;
        }
    }

    if ($conn) {
        $stmt = @$conn->prepare('SELECT id, game_code, issue_number, premium, number, color, big_small, sum_value, open_time, created_at FROM lottery_results WHERE game_code=? AND issue_number=? ORDER BY id ASC LIMIT 1');
        if (!$stmt) error_log('lottery_results read unavailable: ' . $conn->error);
        if ($stmt) {
            $stmt->bind_param('ss', $gameCode, $issueNumber);
            $stmt->execute();
            $row = $stmt->get_result()->fetch_assoc();
            if ($row) return le_result_detail($gameCode, (string)$row['premium'], $issueNumber);
        }
    }
    // (FIX #9 ka purana block: upar FIX #13 me aa gaya — ab API SABSE UPAR)

    $settings = le_get_settings($gameCode);
    $forceResult = trim((string)($settings['force_result'] ?? ''));
    if ($forceResult !== '') {
        $premium = $forceResult;
    } else {
        $premium = le_random_premium($gameCode);
        if ($conn && $issueNumber !== '') {
            $gEsc = $conn->real_escape_string($gameCode);
            $iEsc = $conn->real_escape_string($issueNumber);
            $q = $conn->query("SELECT bet_content FROM lottery_bets WHERE game_code='$gEsc' AND issue_number='$iEsc' AND state=2 ORDER BY id ASC LIMIT 1");
            $bet = $q ? $q->fetch_assoc() : null;
            if ($bet) {
                $choice = le_extract_choice($gameCode, (string)$bet['bet_content']);
                $force = (string)($settings['force_mode'] ?? 'auto');
                if ($force === 'win') {
                    $premium = le_premium_for_choice($gameCode, $choice, true);
                } elseif ($force === 'lose') {
                    $premium = le_premium_for_choice($gameCode, $choice, false);
                } else {
                    $shouldWin = (random_int(1,10000) <= (int)round(((float)$settings['win_rate'])*100));
                    $premium = le_premium_for_choice($gameCode, $choice, $shouldWin);
                }
            }
        }
    }
    $detail = le_result_detail($gameCode, $premium, $issueNumber);
    if ($conn && $save) {
        $premium = (string)$detail['premium'];
        $number = (string)$detail['number'];
        $color = (string)$detail['color'];
        $bigSmall = (string)$detail['bigSmall'];
        $sum = (int)$detail['sum'];
        $stmt = @$conn->prepare('INSERT IGNORE INTO lottery_results(game_code, issue_number, premium, number, color, big_small, sum_value, open_time, created_at) VALUES(?,?,?,?,?,?,?,NOW(),NOW())');
        if (!$stmt) error_log('lottery_results write unavailable: ' . $conn->error);
        if ($stmt) { 
            $stmt->bind_param('ssssssi', $gameCode, $issueNumber, $premium, $number, $color, $bigSmall, $sum); 
            $stmt->execute();
        }
        $stmt2 = @$conn->prepare('SELECT * FROM lottery_results WHERE game_code=? AND issue_number=? ORDER BY id ASC LIMIT 1');
        if ($stmt2) {
            $stmt2->bind_param('ss', $gameCode, $issueNumber);
            $stmt2->execute();
            $row2 = $stmt2->get_result()->fetch_assoc();
            if ($row2) {
                return le_result_detail($gameCode, (string)$row2['premium'], $issueNumber);
            }
        }
    }
    return $detail;
}

function le_bet_content_from_request(array $d): string
{
    @file_put_contents(__DIR__ . '/bet_debug.log', date('Y-m-d H:i:s') . ' PAYLOAD: ' . json_encode($d) . "\n", FILE_APPEND);
    if (isset($d['betContent'])) return (string)$d['betContent'];
    
    // Find type and value dynamically from all possible keys
    $type = '';
    $val = '';
    
    $typeKeys = ['selectType', 'playType', 'betType', 'type', 'gameType'];
    foreach ($typeKeys as $k) {
        if (isset($d[$k]) && is_string($d[$k]) && $d[$k] !== '') {
            $type = strtolower(trim($d[$k]));
            break;
        }
    }
    
    $valKeys = ['playBet', 'bettingContent', 'pick', 'content', 'value', 'select', 'choice', 'option', 'number', 'color', 'bigSmall'];
    foreach ($valKeys as $k) {
        if (isset($d[$k]) && is_string($d[$k]) && $d[$k] !== '') {
            $val = trim($d[$k]);
            break;
        }
    }
    
    if ($type !== '' && $val !== '') {
        if ($type === 'bigsmalleven' || $type === 'bsoe' || $type === 'size') {
            // "1" is Small and "0" is Big based on the user's inverted win reports
            if ($val === '1' || $val === 's' || $val === 'small') return 'small';
            if ($val === '0' || $val === 'b' || $val === 'big') return 'big';
            if ($val === '2') return 'even';
            if ($val === '3') return 'odd';
            return 'bigsmall_' . $val;
        }
        if ($type === 'color' || $type === 'colour') {
            if ($val === '10' || $val === 'g' || $val === 'green' || $val === '1') return 'green';
            if ($val === '20' || $val === 'v' || $val === 'violet' || $val === '2') return 'violet';
            if ($val === '30' || $val === 'r' || $val === 'red' || $val === '3') return 'red';
            return 'color_' . $val;
        }
        if ($type === 'num' || $type === 'number') {
            return (string)$val;
        }
        return $type . '_' . $val;
    }

    // Fallback if we couldn't find type/val clearly
    $keys = ['bettingContent','playType','betType','pick','content','selectType','number','color','bigSmall','betInfo','betDetail','name','title','value','betName','bet_name','select','choice','option'];
    foreach ($keys as $k) {
        if (isset($d[$k]) && $d[$k] !== '' && !is_array($d[$k])) {
            $val = (string)$d[$k];
            $lower = strtolower(trim($val));
            if (!in_array($lower, ['bigsmalleven', 'bsoe', 'num', 'number', 'color', 'sum', 'playbet'], true)) {
                return $val;
            }
        }
    }
    return json_encode($d, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
}

function le_total_amount_from_request(array $d): array
{
    $amount = (float)first_value($d, ['amount','betAmount','bettingAmount','singleAmount','money','baseAmount','selectAmount','contractMoney'], 0);
    $multiple = (int)first_value($d, ['betMultiple','multiple','quantity','bettingQuantity','betCount','count','contractCount'], 1);
    if ($amount <= 0 && isset($d['totalAmount'])) { $amount = (float)$d['totalAmount']; $multiple = 1; }
    if ($multiple <= 0) $multiple = 1;
    return [$amount, $multiple, round($amount * $multiple, 2)];
}

function le_extract_choice(string $gameCode, string $content): array
{
    $c = trim(strtolower($content));
    
    $result = ['kind'=>'number','value'=>'0'];
    
    // Direct matches for common combined strings like 'BigSmall_Small'
    if ($c === 'bigsmall_small' || $c === 'small') {
        $result = ['kind'=>'bigsmall','value'=>'small'];
    } elseif ($c === 'bigsmall_big' || $c === 'big') {
        $result = ['kind'=>'bigsmall','value'=>'big'];
    } elseif (strpos($c, 'color_red') !== false || $c === 'red') {
        $result = ['kind'=>'color','value'=>'red'];
    } elseif (strpos($c, 'color_green') !== false || $c === 'green') {
        $result = ['kind'=>'color','value'=>'green'];
    } elseif (strpos($c, 'color_violet') !== false || strpos($c, 'color_purple') !== false || $c === 'violet' || $c === 'purple') {
        $result = ['kind'=>'color','value'=>'violet'];
    } else {
        // Strip frontend meta-strings from the payload so 'bigsmalleven' doesn't falsely trigger 'small'
        $c = str_replace(['bigsmalleven', 'bsoe', 'playbet', 'selecttype', '"', "'", 'bigsmall_'], ' ', $c);
        
        if ($c === 'b' || $c === 'bada' || $c === '40') $result = ['kind'=>'bigsmall','value'=>'big'];
        elseif ($c === 's' || $c === 'chota' || $c === '50') $result = ['kind'=>'bigsmall','value'=>'small'];
        elseif ($c === 'g' || $c === '10') $result = ['kind'=>'color','value'=>'green'];
        elseif ($c === 'v' || $c === '20') $result = ['kind'=>'color','value'=>'violet'];
        elseif ($c === 'r' || $c === '30') $result = ['kind'=>'color','value'=>'red'];
        elseif (strpos($c, 'violet') !== false || strpos($c, 'purple') !== false) $result = ['kind'=>'color','value'=>'violet'];
        elseif (strpos($c, 'green') !== false) $result = ['kind'=>'color','value'=>'green'];
        elseif (strpos($c, 'red') !== false) $result = ['kind'=>'color','value'=>'red'];
        else {
            $hasSmall = (strpos($c, 'small') !== false || strpos($c, 'chota') !== false);
            $hasBig = (strpos($c, 'big') !== false || strpos($c, 'bada') !== false);
            if ($hasSmall && !$hasBig) $result = ['kind'=>'bigsmall','value'=>'small'];
            elseif ($hasBig && !$hasSmall) $result = ['kind'=>'bigsmall','value'=>'big'];
            else {
                $clean = preg_replace('/(wingo|trxwingo|k3|5d|d5|motorace|motogame|1min|3min|5min|30s|issue|gamecode|amount|multiple|betcontent|playtype|playbet|bigsmall|size)/i', ' ', $content);
                if (le_is_moto($gameCode) && preg_match('/\b(10|[1-9])\b/', $clean, $m)) $result = ['kind'=>'number','value'=>(string)(int)$m[1]];
                elseif (le_is_k3($gameCode) && preg_match('/\b([3-9]|1[0-8])\b/', $clean, $m)) $result = ['kind'=>'sum','value'=>(string)(int)$m[1]];
                elseif (preg_match('/\b([0-9])\b/', $clean, $m)) $result = ['kind'=>'number','value'=>(string)(int)$m[1]];
                elseif (preg_match('/(?:num|number|digit|select)[^0-9]*([0-9])/', $c, $m)) $result = ['kind'=>'number','value'=>(string)(int)$m[1]];
            }
        }
    }
    
    @file_put_contents(__DIR__ . '/bet_debug.log', date('Y-m-d H:i:s') . ' EXTRACT_CHOICE IN: ' . $content . ' OUT: ' . json_encode($result) . "\n", FILE_APPEND);
    return $result;
}

function le_result_matches(array $choice, array $result, string $gameCode): bool
{
    $kind = $choice['kind'] ?? 'number';
    $value = trim(strtolower((string)($choice['value'] ?? '')));
    $bigSmall = trim(strtolower((string)($result['bigSmall'] ?? '')));
    $colorStr = trim(strtolower((string)($result['color'] ?? '')));
    
    if ($kind === 'color') return in_array($value, array_map('trim', explode(',', $colorStr)), true);
    if ($kind === 'bigsmall') return $bigSmall === $value;
    if ($kind === 'sum') return (string)((int)$result['sum']) === (string)((int)$value);
    if (le_is_moto($gameCode)) return (string)((int)($result['firstNumber'] ?? 0)) === (string)((int)$value);
    if (le_is_k3($gameCode)) return strpos((string)$result['number'], (string)((int)$value)) !== false;
    if (le_is_d5($gameCode)) return strpos((string)$result['number'], (string)((int)$value)) !== false;
    
    return (string)((int)$result['number']) === (string)((int)$value);
}

function le_premium_for_choice(string $gameCode, array $choice, bool $shouldWin): string
{
    for ($i=0; $i<60; $i++) {
        if ($shouldWin) {
            if (le_is_wingo($gameCode)) {
                if ($choice['kind'] === 'number') $premium = (string)((int)$choice['value']);
                elseif ($choice['kind'] === 'color') {
                    $map = ['red'=>[2,4,6,8], 'green'=>[1,3,7,9], 'violet'=>[0,5]];
                    $arr = $map[strtolower($choice['value'])] ?? [0];
                    $premium = (string)$arr[array_rand($arr)];
                } else {
                    $premium = strtolower($choice['value']) === 'big' ? (string)random_int(5,9) : (string)random_int(0,4);
                }
            } elseif (le_is_k3($gameCode)) {
                if (($choice['kind'] ?? '') === 'sum') {
                    $target = max(3, min(18, (int)$choice['value']));
                    $a = random_int(1,6); $b = random_int(1,6); $c = max(1, min(6, $target-$a-$b));
                    while ($a+$b+$c !== $target) { $a=random_int(1,6); $b=random_int(1,6); $c=random_int(1,6); }
                    $premium = "$a,$b,$c";
                } else $premium = le_random_premium($gameCode);
            } elseif (le_is_d5($gameCode)) {
                $digit = preg_match('/^[0-9]$/', (string)$choice['value']) ? (string)$choice['value'] : (string)random_int(0,9);
                $arr = [random_int(0,9),random_int(0,9),random_int(0,9),random_int(0,9),random_int(0,9)];
                $arr[random_int(0,4)] = (int)$digit;
                $premium = implode('', $arr);
            } elseif (le_is_moto($gameCode)) {
                $first = max(1, min(10, (int)$choice['value']));
                $nums = range(1,10); shuffle($nums); $nums = array_values(array_diff($nums, [$first])); array_unshift($nums, $first);
                $premium = implode(',', $nums);
            } else $premium = le_random_premium($gameCode);
        } else {
            $premium = le_random_premium($gameCode);
        }
        $detail = le_result_detail($gameCode, $premium);
        if (le_result_matches($choice, $detail, $gameCode) === $shouldWin) return $premium;
    }
    return le_random_premium($gameCode);
}

function le_payout_rate(string $gameCode, array $choice, array $settings): float
{
    if (le_is_k3($gameCode)) return (float)$settings['payout_k3'];
    if (le_is_d5($gameCode)) return (float)$settings['payout_5d'];
    if (le_is_moto($gameCode)) return (float)$settings['payout_moto'];
    // Hardcode rates to prevent 10x payouts from DB misconfigurations
    if (($choice['kind'] ?? '') === 'color') return strtolower((string)$choice['value']) === 'violet' ? 4.5 : 2.0;
    if (($choice['kind'] ?? '') === 'bigsmall') return 2.0;
    return (float)($settings['payout_number'] ?? 9.0);
}

// =======================================================================
// FIX #15 — BET KA TIME EK SECOND PICHE  (My History ki "Time" wali line)
//
//   Sirf DIKHANE ke liye. DB me asli created_at hi rehta hai — settlement,
//   period, result, tax, order id kuch bhi nahi badalta.
//   LE_BET_TIME_LEAD_SEC = 1  ->  04:14:30 ki jagah 04:14:29 dikhega
//   LE_BET_TIME_LEAD_SEC = 60 ->  ek minute piche
// =======================================================================
function le_bet_time_lead(): int
{
    if (!defined('LE_BET_TIME_LEAD_SEC')) return 1;
    $n = (int)LE_BET_TIME_LEAD_SEC;
    if ($n < 0) $n = 0;
    if ($n > 3600) $n = 3600;
    return $n;
}

/** bet row me dikhane layak time (ek second piche) — unix seconds */
function le_bet_row_time(array $r): int
{
    $ts = strtotime((string)($r['created_at'] ?? ''));
    if ($ts === false || $ts <= 0) $ts = time();
    return $ts - le_bet_time_lead();
}

function le_response_row(array $r): array
{
    $premium = trim((string)($r['premium'] ?? ''));
    if ($premium === '') {
        $result = ['number'=>'','color'=>'','bigSmall'=>'','sum'=>0,'premium'=>''];
    } else {
        $result = le_result_detail((string)$r['game_code'], $premium, (string)$r['issue_number']);
    }
    // FIX #4 — My History ki "Tax" row yahi se bharti hai.
    //   real_amount = poora bet amount, fee = us par 2% tax (sirf display).
    //   "After tax amount" = real_amount - fee  (dmfirst/shreewin jaisa).
    $rowAmount = (float)($r['amount'] ?? 0);
    $rowStake  = (float)($r['real_amount'] ?? 0);
    $rowFee    = (float)($r['fee'] ?? 0);
    $rowOrder  = (string)($r['order_no'] ?? '');
    // Naye (30-char order no) bets me fee hamesha 2% hota hai.
    // Purane bets me jo fee store hai wahi dikhao (do-baar mat ghatao).
    if ($rowFee <= 0.0 && $rowStake > 0.0 && strlen(trim($rowOrder)) >= 28) {
        $rowFee = le_stake_tax($rowStake);
    }
    // FIX #6 — purane model me real_amount me tax pehle hi ghata hota hai.
    $rowReal  = le_is_display_only_tax($rowOrder, $rowStake, $rowFee)
        ? round(max(0.0, $rowStake - $rowFee), 2)
        : round(max(0.0, $rowStake), 2);
    return [
        'orderNo' => (string)$r['order_no'],
        'orderNumber' => (string)$r['order_no'],
        'issueNumber' => (string)$r['issue_number'],
        'gameCode' => (string)$r['game_code'],
        'betContent' => (string)$r['bet_content'],
        'amount' => $rowAmount,
        'betMultiple' => (int)$r['bet_multiple'],
        'realAmount' => $rowReal,
        'fee' => $rowFee,
        'tax' => $rowFee,
        'taxAmount' => $rowFee,
        'taxRate' => le_tax_percent(),
        'serviceCharge' => $rowFee,
        'premium' => $premium,
        'number' => (string)$result['number'],
        'color' => (string)$result['color'],
        'bigSmall' => (string)$result['bigSmall'],
        'sum' => (int)$result['sum'],
        'playType' => explode('_', (string)$r['bet_content'])[0] ?? '',
        'state' => (int)$r['state'],
        'isWin' => (int)$r['state'] === 1,
        'isPending' => (int)$r['state'] === 2,
        'winLoseAmount' => (float)$r['win_lose_amount'],
        // FIX #15 — 1 second PICHE (My History me "Time" isi se banta hai)
        'betTime' => le_bet_row_time($r) * 1000,
        'createTime' => le_bet_row_time($r) * 1000,
    ];
}

function le_issue_is_closed(string $gameCode, string $issueNumber): bool
{
    $issueNumber = trim($issueNumber);
    if ($issueNumber === '') return false;
    $current = function_exists('lottery_issue') ? lottery_issue($gameCode)['issueNumber'] : le_issue_by_offset($gameCode, 0);
    return strcmp($issueNumber, (string)$current) < 0;
}

// =======================================================================
// FIX #7 — settlement ko PERIOD NUMBER se AZAAD banana
//
//   Do alag build ek hi `lottery_bets` table use kar rahe hain aur dono
//   ka period number ALAG hai (jaise WinGo_1M: 10352 vs 57312).
//   le_issue_is_closed() sirf issue NUMBER compare karta hai, isliye
//   doosre build ke bet ko "abhi chal raha hai" samajh sakta hai aur wo
//   bet kabhi settle na ho (player ka paisa atka rahe).
//
//   YE FUNCTION period number ko dekhta hi nahi:
//   bet ka created_at agar CURRENT PERIOD KI SHURUAAT se pehle ka hai to
//   uska period PAKKA band ho chuka hai.
// =======================================================================
function le_bet_period_is_closed(string $gameCode, string $createdAt): bool
{
    $createdAt = trim((string)$createdAt);
    if ($createdAt === '' || $createdAt === '0000-00-00 00:00:00') return false;
    $ts = strtotime($createdAt);
    if ($ts === false || $ts <= 0) return false;
    $interval = le_game_interval($gameCode);
    if ($interval <= 0) return false;
    $currentStart = intdiv(time(), $interval) * $interval;  // current period ki shuruaat
    return $ts < $currentStart;
}

function le_settle_pending_bets(string $gameCode = '', string $issueNumber = '', int $userId = 0, string $orderNo = '', bool $includeOpenIssue = false): int
{
    $conn = db();
    if (!$conn) return 0;
    $where = ['state=2'];
    if ($gameCode !== '') $where[] = "game_code='" . $conn->real_escape_string($gameCode) . "'";
    if ($issueNumber !== '') $where[] = "issue_number='" . $conn->real_escape_string($issueNumber) . "'";
    if ($userId > 0) $where[] = 'user_id=' . (int)$userId;
    if ($orderNo !== '') $where[] = "order_no='" . $conn->real_escape_string($orderNo) . "'";
    $sql = 'SELECT * FROM lottery_bets WHERE ' . implode(' AND ', $where) . ' ORDER BY id ASC LIMIT 500';
    $rs = $conn->query($sql);
    if (!$rs) return 0;
    $settled = 0;
    while ($r = $rs->fetch_assoc()) {
        $g = (string)$r['game_code'];
        $issue = (string)$r['issue_number'];
        // FIX #1 — $includeOpenIssue = true hone par ABHI CHAL RAHE period ke
        // bets bhi settle ho jate hain (bet lagte hi Win / Loss).
        // false (default) par purana behaviour: period band hone ke baad hi.
        // FIX #7 — period number ka koi bhi scheme ho (do alag build ek hi DB
        // share karte hain), created_at current period se pehle ka hai to band.
        if (!$includeOpenIssue
            && !le_issue_is_closed($g, $issue)
            && !le_bet_period_is_closed($g, (string)($r['created_at'] ?? ''))) continue;

        $result = le_result_for_issue($g, $issue, true);
        $choice = le_extract_choice($g, (string)$r['bet_content']);
        $settings = le_get_settings($g);
        $isWin = le_result_matches($choice, $result, $g);
        $rate = le_payout_rate($g, $choice, $settings);
        $stake = (float)$r['real_amount'];
        $fee = (float)$r['fee'];
        // FIX #6 — naye bets me fee (TAX) sirf display hai (debit = stake),
        // purane build ke bets me fee alag se kata gaya tha (debit = stake+fee).
        $debit = le_settle_debit((string)($r['order_no'] ?? ''), $stake, $fee);
        // Apply 2% tax to the gross winning payout: ₹100 at 2x credits ₹196.
        $grossPayout = $isWin ? round($stake * $rate, 2) : 0.0;
        $payout = $isWin ? round($grossPayout * 0.98, 2) : 0.0;
        $net = round($payout - $debit, 2);
        $state = $isWin ? 1 : 0;
        $premium = (string)$result['premium'];
        $betId = (int)$r['id'];
        $uid = (int)$r['user_id'];
        $order = (string)$r['order_no'];
        $vendor = 'ARLottery';
        $remark = $g . ' ' . (string)$r['bet_content'] . ' result ' . $premium;

        @$conn->begin_transaction();
        $check = $conn->query('SELECT state FROM lottery_bets WHERE id=' . $betId . ' FOR UPDATE');
        $fresh = $check ? $check->fetch_assoc() : null;
        if (!$fresh || (int)$fresh['state'] !== 2) { @$conn->rollback(); continue; }

        $stmt = $conn->prepare('UPDATE lottery_bets SET premium=?, state=?, win_lose_amount=? WHERE id=?');
        if (!$stmt) { @$conn->rollback(); continue; }
        $stmt->bind_param('sidi', $premium, $state, $net, $betId);
        if (!$stmt->execute()) { @$conn->rollback(); continue; }

        $settlement = wallet_apply_delta($conn, $uid, $payout, 'GameEnd', $order, $remark, $isWin ? 'Win' : 'Loss', $vendor, ['gameCode'=>$g,'issueNumber'=>$issue,'premium'=>$premium,'isWin'=>$isWin,'net'=>$net]);
        if (!$settlement) { @$conn->rollback(); continue; }
        @$conn->commit();
        $settled++;
    }
    return $settled;
}
