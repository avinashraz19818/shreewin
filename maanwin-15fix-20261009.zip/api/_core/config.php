<?php
// ===============================
// Dhani Win Backend Config
// cPanel MySQL details yaha set hain.
// AUTO_INSTALL_TABLES=true hone par pehli API request par tables automatic create/seed ho jayengi.
// ===============================

define('DB_HOST', getenv('DW_DB_HOST') ?: 'localhost');
define('DB_NAME', getenv('DW_DB_NAME') ?: 'club532583_maanwin');
define('DB_USER', getenv('DW_DB_USER') ?: 'club532583_maanwin');
define('DB_PASS', getenv('DW_DB_PASS') ?: 'club532583_maanwin');

define('AUTO_INSTALL_TABLES', true);
define('AUTO_INSTALL_VERSION', '2026_07_22_v34_support_team_wheel');

define('APP_TENANT_ID', 6007);
define('APP_CURRENCY', 'INR');
define('APP_CURRENCY_SIGN', '₹');
define('APP_SECRET', getenv('DW_APP_SECRET') ?: 'b887fd8e108ea8bdd2587747c6cc1eec91806544edb76abe99d9ec703d8a23ad');
define('APP_TIMEZONE', 'Asia/Kolkata');

// true = project/demo virtual wallet only. Real-money payment gateway/live settlement connected nahi hai.
define('DEMO_MODE', true);

// =========================================================================
// LOTTERY ENGINE — 4 FIXES  (2026-10-08)
// -------------------------------------------------------------------------
// 1) Bet lagte hi My History me Win / Loss aa jaye
//      true  = bet lagte hi result settle ho jata hai (My History me turant
//              "Success / Fail" + amount dikhega)
//      false = purana behaviour (period band hone par settle)
//    (Sirf My History / Win-Loss popup jaldi dikhta hai. Game screen, Trend
//     aur Period history me result period band hone ke BAAD hi dikhega.)
if (!defined('LE_INSTANT_SETTLEMENT'))  define('LE_INSTANT_SETTLEMENT', true);
//
// 2) Bet wale timer me 1 second KAM dikhaye
//      Asli bacha hua time 11:55  ->  screen par 11:54
//      1000 = 1 second kam   |   2000 = 2 second kam   |   0 = asli time
//    (Issue number, settlement aur DB par KOI asar nahi — sirf dikhne wala
//     time badalta hai.)
if (!defined('LE_TIMER_LEAD_MS'))       define('LE_TIMER_LEAD_MS', 1000);
//
//   BET KA TIME (My History me "Time" wali line) kitna PICHE DIKHE  (FIX #15)
//       1 = 1 second piche   (DEFAULT)   jaise 04:14:30  ->  04:14:29
//      60 = 1 minute piche               jaise 04:14:30  ->  04:13:30
//       0 = asli time (koi badlav nahi)
//     Ye SIRF DIKHANE KE LIYE hai — DB me asli created_at hi rehta hai,
//     settlement / hisaab par koi asar nahi.
if (!defined('LE_BET_TIME_LEAD_SEC'))   define('LE_BET_TIME_LEAD_SEC', 1);
//
// 3) Timer khatam hone par WIN / LOSS POPUP aaye
//      Screen wala countdown is value ke barabar ya chhota hone par current
//      period ka result "Game history / Period history" ki pehli row me aa
//      jata hai — popup ko wahi row chahiye hoti hai, isliye popup tabhi
//      dikhta hai.  Betting 5 second pehle hi band ho jati hai, isliye
//      isse koi result jaldi "dekh kar" bet nahi laga sakta.
//      FIX #10 (2026-10-08): ab default 999 = HAMESHA ON.
//      Kyun: drawer/upstream ki pehli row me CURRENT period hota hai (uska
//      result bhi usi waqt published hota hai). Game ki list bhi ab wahin se
//      shuru hogi, tabhi drawer aur game BILKUL ek dikhenge.
//      Popup bhi theek waqt par (timer khatam hone par) dikhta hai.
//      999 = default (recommended)  |  -1 = current period list me nahi aayega
//   RESULT KAB DIKHEGA  (FIX #14 — yahi "1 result piche" ka asli switch)
//     999 = current period HAMESHA history/trend ki pehli row me
//           (matlab chal rahe period ka result betting ke dauran hi dikhega)
//      0  = current period ki row tabhi aayegi jab timer khatam ho.
//      1  = row tab aayegi jab countdown <= 1 ho (DEFAULT, FIX #15) —
//           matlab screen par timer "0" dikhne tak row PEHLE SE MAUJOOD
//           hoti hai, isliye WIN / LOSS POPUP bina kisi delay ke 0 par
//           aa jata hai. Poore period bhar pehli row phir bhi PICHLA
//           period + USI ka API wala result hi hoti hai (jodi sahi).
//           (Result 1 second pehle dikhne ka koi nuksan nahi — API/drawer
//            to result period shuru hote hi publish kar deta hai.)
if (!defined('LE_REVEAL_AT_COUNTDOWN')) define('LE_REVEAL_AT_COUNTDOWN', 1);
//
// 4) TAX + ORDER NUMBER (My History detail panel)
//      Tax  = bet amount ka 2%  (1000 par 20 rs) — har bet par.
//             Ye sirf record me DIKHAYA jata hai; wallet se alag se nahi
//             kata jata (payout par ka 2% tax alag se lagta hai).
//      Order no = 30 char:  WG + Ymd + His + 7-digit user + 7-digit bet id
//             jaise  WG202610080443175103202703489
//             Prefix: WinGo=WG  TrxWinGo=TW  K3=K3  5D/D5=5D  MotoRace=MR
// 6) SITE, API (draw.ar-lottery01.com) SE KITNE PERIOD PICHE CHALE
//      NAYA DEFAULT 0 (FIX #14) — site ka CURRENT period == API ki row0,
//      yani API ka ASLI current period. Aapne bola tha "1 piche karna tha,
//      tumne 2 kar diya" — to period ko EK AAGE laya gaya hai.
//      Result ko piche rakhne ka kaam ab LE_REVEAL_AT_COUNTDOWN karta hai
//      (niche dekho), isliye "jis period ka result usi ka" BANA RAHTA hai.
//
//        0 = site API ke BARABAR  (DEFAULT — asli current period)
//       -1 = site API se 1 period piche
//       -2 = 2 period piche (zarurat pade to)
if (!defined('LE_PERIOD_SHIFT'))       define('LE_PERIOD_SHIFT', 0);
//
//    RESULT ka apna alag shift — ZARURAT NA HO TO 0 RAKHO:
//        0 = period N par N ka result  (DEFAULT — hamesha API wala result)
//       -1 = period N par N-1 ka result (jodi TODTA hai — FIX #11 ki galti)
if (!defined('LE_RESULT_SHIFT'))       define('LE_RESULT_SHIFT', 0);
//
//    PERIOD NUMBER ki DATE kis hisaab se banegi  (FIX #13 — ASLI WAJAH)
//      'utc'   = draw.ar-lottery01.com jaisa  (DEFAULT)
//                API apna period number UTC date se banati hai. Site apni
//                timezone (Asia/Kolkata) se banati thi, isliye subah
//                00:00 se 05:30 IST ke beech period number EK DIN aage ho
//                jata tha  (20261009....  vs  API 20261008....) — period
//                bhi alag dikha AUR result ki lookup bhi miss ho gayi.
//      'local' = site ki apni timezone (purana behaviour)
if (!defined('LE_ISSUE_DATE_TZ'))      define('LE_ISSUE_DATE_TZ', 'utc');
//
//    Upstream se kitne page (har page = 10 period) laye jayen.
//    3 page = 30 period: history ke 3 page tak API wala hi result milega.
if (!defined('LE_UPSTREAM_PAGES'))     define('LE_UPSTREAM_PAGES', 3);
//
// 5) DRAWER (draw.ar-lottery01.com) AUR GAME — EK HI PERIOD / RESULT
//      Frontend .json requests (GetHistoryIssuePage.json) sidhe
//      https://draw.ar-lottery01.com par jati hain (DRAWER), jabki game ka
//      period local server se aata tha — isliye dono ALAG dikhte the.
//      true  = local backend bhi wahi upstream period + result use kare
//              (2-3 second cache; upstream na mile to purana local hisaab)
//      false = purana behaviour (sab kuch local engine se)
if (!defined('LE_UPSTREAM_RESULTS'))    define('LE_UPSTREAM_RESULTS', true);
if (!defined('LE_UPSTREAM_BASE'))       define('LE_UPSTREAM_BASE', 'https://draw.ar-lottery01.com');
if (!defined('LE_UPSTREAM_TIMEOUT'))    define('LE_UPSTREAM_TIMEOUT', 3);
if (!defined('LE_UPSTREAM_CACHE_SEC'))  define('LE_UPSTREAM_CACHE_SEC', 3);
//
if (!defined('LE_TAX_PERCENT'))         define('LE_TAX_PERCENT', 2.0);
if (!defined('LE_ORDER_NO'))            define('LE_ORDER_NO', true);
// =========================================================================

@date_default_timezone_set(APP_TIMEZONE);
