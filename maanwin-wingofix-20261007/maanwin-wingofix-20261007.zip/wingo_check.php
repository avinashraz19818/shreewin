<?php
error_reporting(E_ALL & ~E_NOTICE & ~E_WARNING & ~E_DEPRECATED);
/**
 * WINGO CHECK PAGE — /wingo_check.php
 * Upstream + local dono dikhata hai. Verified karne ke baad is file ko
 * public_html se delete kar dena.
 */
header('Content-Type: text/html; charset=utf-8');
$UPSTREAM = 'https://draw.ar-lottery01.com';
$ORIGIN   = 'https://maanwin16.com';
function fetchUp($url, $origin) {
    if (!function_exists('curl_init')) return [null, 'curl missing'];
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true, CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_TIMEOUT => 8, CURLOPT_CONNECTTIMEOUT => 4,
        CURLOPT_SSL_VERIFYPEER => true, CURLOPT_SSL_VERIFYHOST => 2,
        CURLOPT_ENCODING => '',
        CURLOPT_HTTPHEADER => ['Origin: '.$origin, 'Referer: '.$origin.'/', 'Accept: application/json'],
    ]);
    $raw = curl_exec($ch);
    $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $err = curl_error($ch);
    curl_close($ch);
    if ($raw === false) return [null, 'curl: '.$err];
    return [['code'=>$code, 'body'=>substr((string)$raw,0,900)], null];
}
$results = [];
foreach (['WinGo_1M','WinGo_30S','K3_1M','D5_1M','TrxWinGo_1M','MotoRace_1M'] as $gc) {
    $folder = 'WinGo';
    foreach (['TrxWinGo','MotoRace','WinGo','K3','D5'] as $f) if (stripos($gc,$f)===0) { $folder=$f; break; }
    $results[$gc] = [];
    foreach (ar_paths($folder, $gc) as $label => $u) {
        [$r, $e] = fetchUp($u, $ORIGIN);
        $results[$gc][$label] = $e ? ['err'=>$e] : ['http'=>$r['code'], 'sample'=>$r['body']];
    }
}
function ar_paths($folder, $gc) {
    return [
        'kv/issue' => "https://draw.ar-lottery01.com/webapi/kv/issue/{$gc}",
        'current'  => "https://draw.ar-lottery01.com/{$folder}/{$gc}.json",
        'history'  => "https://draw.ar-lottery01.com/{$folder}/{$gc}/GetHistoryIssuePage.json?pageNo=1&pageSize=3",
    ];
}
?>
<!doctype html><html><head><meta charset="utf-8"><title>WinGo Check</title>
<style>body{font:14px/1.5 monospace;background:#111;color:#eee;padding:16px}
h2{color:#7fd}a{color:#9cf}table{border-collapse:collapse;width:100%;margin-bottom:18px}
td,th{border:1px solid #444;padding:6px;vertical-align:top}
.ok{color:#6f6}.bad{color:#f66}.warn{color:#fd0}
pre{white-space:pre-wrap;word-break:break-all;margin:0;max-height:150px;overflow:auto}</style></head><body>
<h2>WinGo Upstream Check — <?=htmlspecialchars($_SERVER['HTTP_HOST'] ?? '')?></h2>
<p>Upstream: <code><?=$UPSTREAM?></code> &nbsp;|&nbsp; Origin header: <code><?=$ORIGIN?></code></p>
<?php foreach ($results as $gc => $paths): ?>
<h3><?=htmlspecialchars($gc)?></h3>
<table><tr><th style="width:120px">call</th><th>result</th></tr>
<?php foreach ($paths as $label => $r): ?>
<tr><td><?=htmlspecialchars($label)?></td><td>
<?php if (isset($r['err'])): ?><span class="bad"><?=htmlspecialchars($r['err'])?></span>
<?php else: ?>
<span class="<?=($r['http']>=200 && $r['http']<300)?'ok':'bad'?>">HTTP <?= (int)$r['http'] ?></span>
<pre><?=htmlspecialchars((string)$r['sample'])?></pre>
<?php endif; ?></td></tr>
<?php endforeach; ?></table>
<?php endforeach; ?>
<h3>Apni site (shift ke saath)</h3>
<table>
<?php foreach (array_keys($results) as $gc): ?>
<tr><td style="width:120px"><?=htmlspecialchars($gc)?></td><td><pre><?php
$host = $_SERVER['HTTP_HOST'] ?? '';
$folder = 'WinGo';
foreach (['TrxWinGo','MotoRace','WinGo','K3','D5'] as $f) if (stripos($gc,$f)===0) { $folder=$f; break; }
$j = @file_get_contents('https://' . $host . '/webapi/kv/issue/' . rawurlencode($gc));
echo "CURRENT: " . htmlspecialchars($j === false ? 'fetch failed' : substr((string)$j, 0, 420)) . "\n\n";
$h = @file_get_contents('https://' . $host . '/' . $folder . '/' . rawurlencode($gc) . '/GetHistoryIssuePage.json?pageNo=1&pageSize=3');
if ($h !== false) {
    $d = json_decode((string)$h, true);
    $list = $d['data']['list'] ?? [];
    foreach (array_slice($list, 0, 3) as $r) {
        echo "  " . htmlspecialchars((string)($r['issueNumber'] ?? '?'))
           . "  number=" . htmlspecialchars((string)($r['number'] ?? '?'))
           . "  color="  . htmlspecialchars((string)($r['color'] ?? '?')) . "\n";
    }
} else { echo "HISTORY: fetch failed"; }
?></pre></td></tr>
<?php endforeach; ?>
</table>
<p class="warn">Kaam ho jaye to is file ko delete kar dena: <code>public_html/wingo_check.php</code></p>
</body></html>
