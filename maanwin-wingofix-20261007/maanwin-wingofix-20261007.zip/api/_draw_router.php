<?php
require_once __DIR__ . '/_core/bootstrap.php';

// ============================================================
//  PERIOD / RESULT SHIFT  --  yahan se setting badlo
// ------------------------------------------------------------
//  -1  = period AUR RESULT dono 1 piche   (jo aapne manga)
//   0  = shift OFF (server clock jaisa)
//  -2  = 2 period piche
// ============================================================
if (!defined('AR_PERIOD_SHIFT')) define('AR_PERIOD_SHIFT', -1);
// kitne issue piche jana hai (positive number)
$__arShift = max(0, abs((int)AR_PERIOD_SHIFT));
// ============================================================


$gameCode = $_GET['gameCode'] ?? '';
$path = $_GET['path'] ?? '';

if (!$gameCode && $path) {
    $parts = explode('/', trim($path, '/'));
    // /WinGo/WinGo_30S.json OR /WinGo/WinGo_30S/GetHistoryIssuePage.json
    $gameCode = $parts[1] ?? ($parts[0] ?? 'WinGo_30S');
}
$gameCode = preg_replace('/\.json$/i', '', $gameCode ?: 'WinGo_30S');
$gameCode = preg_replace('/[^A-Za-z0-9_]/', '', $gameCode ?: 'WinGo_30S');

if (str_contains($path, 'GetHistoryIssuePage')) {
    le_settle_pending_bets($gameCode);
    $list = [];
    $pageNo = max(1, (int)($_GET['pageNo'] ?? $_GET['page'] ?? 1));
    $set = site_settings();
    $pageSize = max(1, min(10, (int)($set['game_history_page_size'] ?? 10)));
    for ($i = 1; $i <= $pageSize; $i++) {
        $offset = (($pageNo - 1) * $pageSize) + $i;
        // PERIOD SHIFT: result bhi isi issue number se niklega, isliye dono saath chalte hain
        $issueNum = le_issue_by_offset($gameCode, $offset + $__arShift);
        $r = le_result_for_issue($gameCode, $issueNum, true);
        $list[] = lottery_public_result($gameCode, (string)$issueNum, $r, now_ms() - $offset * le_game_interval($gameCode) * 1000);
    }
    api_success(['list'=>$list,'pageNo'=>$pageNo,'pageSize'=>$pageSize,'totalPage'=>999,'totalCount'=>9990], 'Succeed', ['serviceTime'=>now_ms()]);
}

// /webapi/kv/issue/WinGo_30S and /WinGo/WinGo_30S.json dono same response denge.
$__iss = lottery_issue($gameCode);
if ($__arShift > 0) {
    // Sirf issueNumber (period) piche -> startTime/endTime/countdown NAHI badalte
    $__iss['issueNumber'] = le_issue_by_offset($gameCode, $__arShift);
    $__iss['issueNo']     = $__iss['issueNumber'];
    $__iss['period']      = $__iss['issueNumber'];
}
api_success($__iss);
