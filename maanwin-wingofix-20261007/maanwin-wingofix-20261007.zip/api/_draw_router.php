<?php
/**
 * ============================================================================
 *  MAANWIN — DRAW ROUTER   (upstream-first + local fallback + period shift)
 * ============================================================================
 *  Period/result ab draw.ar-lottery01.com se aata hai (browser wahan se
 *  directly nahi maarsakta — 403; Origin/Referer header zaroori hai, isliye
 *  yahan server-side se headers ke saath fetch kiya jaata hai).
 *  Upstream fail ho to LOCAL engine use hota hai -> site kabhi nahi tootegi.
 *
 * ---------------------------------------------------------------------------
 *  SETTING — line 20
 *      AR_PERIOD_SHIFT = -1   period AUR RESULT dono 1 piche  (jo manga tha)
 *      AR_PERIOD_SHIFT =  0   shift OFF
 * ---------------------------------------------------------------------------
 */
require_once __DIR__ . '/_core/bootstrap.php';

// ============================ SETTING =====================================
if (!defined('AR_PERIOD_SHIFT')) define('AR_PERIOD_SHIFT', -1);
// ==========================================================================

define('AR_UPSTREAM', 'https://draw.ar-lottery01.com');
define('AR_ORIGIN',   'https://maanwin16.com');
define('AR_CACHE_SEC', 2);          // upstream ko thoda sa thanda rakho
define('AR_TIMEOUT',  6);

$__shiftBack = max(0, abs((int)AR_PERIOD_SHIFT));
$__cacheDir  = sys_get_temp_dir() . '/ar_draw_cache';

// ---------- helpers -------------------------------------------------------
function ar_folder(string $gc): string
{
    foreach (['TrxWinGo', 'MotoRace', 'WinGo', 'K3', 'D5'] as $f) {
        if (stripos($gc, $f) === 0) return $f;
    }
    return 'WinGo';
}
function ar_code_variants(string $gc): array
{
    $c = [$gc];
    if (preg_match('/_(\d+)M$/i', $gc))     $c[] = preg_replace('/_(\d+)M$/i',   '_${1}Min', $gc);
    if (preg_match('/_(\d+)Min$/i', $gc))   $c[] = preg_replace('/_(\d+)Min$/i', '_${1}M',   $gc);
    return array_values(array_unique($c));
}
function ar_get_json(string $url): ?array
{
    if (!function_exists('curl_init')) return null;
    global $__cacheDir;
    if (!is_dir($__cacheDir)) @mkdir($__cacheDir, 0775, true);
    $cf = $__cacheDir . '/' . md5($url) . '.json';
    if (is_file($cf) && (time() - filemtime($cf)) < AR_CACHE_SEC) {
        $d = json_decode((string)@file_get_contents($cf), true);
        if (is_array($d)) return $d;
    }
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_TIMEOUT        => AR_TIMEOUT,
        CURLOPT_CONNECTTIMEOUT => 4,
        CURLOPT_SSL_VERIFYPEER => true,
        CURLOPT_SSL_VERIFYHOST => 2,
        CURLOPT_ENCODING       => '',
        CURLOPT_HTTPHEADER     => [
            'Origin: ' . AR_ORIGIN,
            'Referer: ' . AR_ORIGIN . '/',
            'Accept: application/json, text/plain, */*',
        ],
    ]);
    $raw = curl_exec($ch);
    $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    if ($raw === false || $code < 200 || $code >= 300) return null;
    $d = json_decode((string)$raw, true);
    if (!is_array($d)) return null;
    if (is_dir($__cacheDir)) @file_put_contents($cf, (string)$raw);
    return $d;
}
/** issueNumber jaise fields ko N period piche karo (string, bade number safe) */
function ar_shift_issue(string $v, int $back): string
{
    if ($back <= 0 || !preg_match('/^\d{8,}$/', $v)) return $v;
    $slot = (int)substr($v, -5);
    $head = substr($v, 0, strlen($v) - 5);
    $slot -= $back;
    while ($slot < 0) {
        $slot += 100000;
        // head se 1 ghatao; agar head 8-digit date se shuru ho to CALENDAR date ghatao
        if (preg_match('/^(\d{8})(\d*)$/', $head, $m)) {
            $d = date_create_from_format('Ymd', $m[1]);
            if ($d instanceof DateTime) { $d->modify('-1 day'); $head = $d->format('Ymd') . $m[2]; }
            else { $head = (string)((int)$head - 1); }
        } else {
            $head = (string)((int)$head - 1);
        }
    }
    return $head . str_pad((string)$slot, 5, '0', STR_PAD_LEFT);
}
function ar_shift_node($node, int $back)
{
    if ($back <= 0) return $node;
    if (is_array($node)) {
        foreach ($node as $k => $v) {
            if (is_string($k) && preg_match('/^(issueNumber|issueNo|issueId|issue|period|periodNo)$/i', $k) && is_string($v)) {
                $node[$k] = ar_shift_issue($v, $back);
            } else {
                $node[$k] = ar_shift_node($v, $back);
            }
        }
    }
    return $node;
}

// ---------- request parse -------------------------------------------------
$gameCode = $_GET['gameCode'] ?? '';
$path     = (string)($_GET['path'] ?? '');
if (!$gameCode && $path) {
    $parts = explode('/', trim($path, '/'));
    $gameCode = $parts[1] ?? ($parts[0] ?? 'WinGo_30S');
}
$gameCode = preg_replace('/\.json$/i', '', $gameCode ?: 'WinGo_30S');
$gameCode = preg_replace('/[^A-Za-z0-9_]/', '', $gameCode ?: 'WinGo_30S');
$folder   = ar_folder($gameCode);
$isHistory = (stripos($path, 'GetHistoryIssuePage') !== false);

// ==========================================================================
//  BRANCH 1 — HISTORY  (period AUR result dono 1 piche)
// ==========================================================================
if ($isHistory) {
    le_settle_pending_bets($gameCode);

    $pageNo   = max(1, (int)($_GET['pageNo'] ?? $_GET['page'] ?? 1));
    $set      = site_settings();
    $pageSize = max(1, min(10, (int)($set['game_history_page_size'] ?? 10)));

    $list = null;

    // --- upstream: page 1 + page 2, phir head drop karke 1 piche ---
    if ($__shiftBack > 0) {
        foreach (ar_code_variants($gameCode) as $code) {
            $u1 = AR_UPSTREAM . "/{$folder}/{$code}/GetHistoryIssuePage.json?pageNo={$pageNo}&pageSize=" . ($pageSize + 1);
            $u2 = AR_UPSTREAM . "/{$folder}/{$code}/GetHistoryIssuePage.json?pageNo=" . ($pageNo + 1) . "&pageSize=" . ($pageSize + 1);
            $j1 = ar_get_json($u1);
            $j2 = ar_get_json($u2);
            if (!$j1) continue;
            $l1 = $j1['data']['list'] ?? [];
            $l2 = ($j2 && isset($j2['data']['list'])) ? $j2['data']['list'] : [];
            if (!is_array($l1) || count($l1) < 2) continue;
            // head (n-1) drop -> ab list (n-2) se shuru = 1 period piche
            $merged = array_merge(array_slice($l1, 1), $l2);
            $list   = array_slice($merged, 0, $pageSize);
            if (count($list) >= 1) break;
        }
    } else {
        foreach (ar_code_variants($gameCode) as $code) {
            $j = ar_get_json(AR_UPSTREAM . "/{$folder}/{$code}/GetHistoryIssuePage.json?pageNo={$pageNo}&pageSize={$pageSize}");
            if ($j && isset($j['data']['list']) && is_array($j['data']['list'])) { $list = $j['data']['list']; break; }
        }
    }

    // --- fallback: local engine (offset + shift => result bhi saath chalta hai) ---
    if ($list === null) {
        $list = [];
        for ($i = 1; $i <= $pageSize; $i++) {
            $offset   = (($pageNo - 1) * $pageSize) + $i;
            $issueNum = le_issue_by_offset($gameCode, $offset + $__shiftBack);
            $r        = le_result_for_issue($gameCode, $issueNum, true);
            $list[]   = lottery_public_result($gameCode, (string)$issueNum, $r,
                        now_ms() - $offset * le_game_interval($gameCode) * 1000);
        }
    } else {
        $list = ar_shift_node($list, 0); // numbers already shifted by window
    }

    api_success(['list'=>$list,'pageNo'=>$pageNo,'pageSize'=>$pageSize,'totalPage'=>999,'totalCount'=>9990], 'Succeed', ['serviceTime'=>now_ms()]);
}

// ==========================================================================
//  BRANCH 2 — CURRENT ISSUE
// ==========================================================================
$iss = null;
foreach (ar_code_variants($gameCode) as $code) {
    $j = ar_get_json(AR_UPSTREAM . "/webapi/kv/issue/{$code}");
    if (!$j) $j = ar_get_json(AR_UPSTREAM . "/{$folder}/{$code}.json");
    if ($j && isset($j['data']) && is_array($j['data'])) { $iss = $j['data']; break; }
}

if ($iss === null) {
    // fallback: local engine
    $iss = lottery_issue($gameCode);
    if ($__shiftBack > 0) $iss['issueNumber'] = le_issue_by_offset($gameCode, $__shiftBack);
} elseif ($__shiftBack > 0) {
    // sirf period number piche — timer (startTime/endTime/countdown) NAHI badalta
    $iss = ar_shift_node($iss, $__shiftBack);
}
$iss['issueNo'] = $iss['issueNumber'] ?? ($iss['issueNo'] ?? '');
$iss['period']  = $iss['issueNumber'] ?? ($iss['period'] ?? '');

api_success($iss);
