<?php
/**
 * ============================================================================
 *  MAANWIN — DRAW ROUTER   (upstream-first + local fallback + period shift)
 * ============================================================================
 *  DATA SOURCE: https://draw.ar-lottery01.com/{Folder}/{gameCode}/...
 *    /{Folder}/{code}.json                       -> previous / current / next
 *    /{Folder}/{code}/GetHistoryIssuePage.json   -> results list
 *  Browser direct nahi maar sakta (403) -> Origin/Referer header yahan se.
 *
 * ---------------------------------------------------------------------------
 *  SETTING — line 22
 *      AR_PERIOD_SHIFT =  0   upstream jaisa EXACT (DEFAULT - betting sahi)
 *      AR_PERIOD_SHIFT = -1   period AUR result dono 1 piche
 *                            DHYAN: -1 par displayed period CLOSED ho jata
 *                            hai, bet reject ho sakta hai
 * ---------------------------------------------------------------------------
 */
require_once __DIR__ . '/_core/bootstrap.php';

// ============================ SETTING =====================================
if (!defined('AR_PERIOD_SHIFT')) define('AR_PERIOD_SHIFT', -1);  // asli setting api/_core/lottery_engine.php line 172
// ==========================================================================

define('AR_UPSTREAM',  'https://draw.ar-lottery01.com');
define('AR_ORIGIN',    'https://maanwin16.com');
define('AR_CACHE_SEC', 2);
define('AR_TIMEOUT',   6);

$__shiftBack = max(0, abs((int)AR_PERIOD_SHIFT));
$__cacheDir  = sys_get_temp_dir() . '/ar_draw_cache';

// ---------- helpers -------------------------------------------------------
function ar_folder(string $gc): string
{
    foreach (['TrxWinGo', 'MotoRace', 'WinGo', 'K3', 'D5'] as $f) {
        if (stripos($gc, $f) === 0) return $f;
    }
    return 'WinGo';
}
function ar_code_variants(string $gc): array
{
    $c = [$gc];
    if (preg_match('/_(\d+)M$/i', $gc))   $c[] = preg_replace('/_(\d+)M$/i',   '_${1}Min', $gc);
    if (preg_match('/_(\d+)Min$/i', $gc)) $c[] = preg_replace('/_(\d+)Min$/i', '_${1}M',   $gc);
    return array_values(array_unique($c));
}
function ar_get_json(string $url)
{
    if (!function_exists('curl_init')) return null;
    global $__cacheDir;
    if (!is_dir($__cacheDir)) @mkdir($__cacheDir, 0775, true);
    $cf = $__cacheDir . '/' . md5($url) . '.json';
    if (is_file($cf) && (time() - filemtime($cf)) < AR_CACHE_SEC) {
        $d = json_decode((string)@file_get_contents($cf), true);
        if (is_array($d)) return $d;
    }
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true, CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_TIMEOUT => AR_TIMEOUT, CURLOPT_CONNECTTIMEOUT => 4,
        CURLOPT_SSL_VERIFYPEER => true, CURLOPT_SSL_VERIFYHOST => 2,
        CURLOPT_ENCODING => '',
        CURLOPT_HTTPHEADER => [
            'Origin: ' . AR_ORIGIN, 'Referer: ' . AR_ORIGIN . '/',
            'Accept: application/json, text/plain, */*',
        ],
    ]);
    $raw  = curl_exec($ch);
    $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    if ($raw === false || $code < 200 || $code >= 300) return null;
    $d = json_decode((string)$raw, true);
    if (!is_array($d)) return null;
    if (is_dir($__cacheDir)) @file_put_contents($cf, (string)$raw);
    return $d;
}
/** upstream se current issue (previous/current/next wala shape) */
function ar_upstream_current(string $gameCode): ?array
{
    $folder = ar_folder($gameCode);
    foreach (ar_code_variants($gameCode) as $code) {
        $j = ar_get_json(AR_UPSTREAM . "/{$folder}/{$code}.json");
        if (is_array($j) && isset($j['current']['issueNumber'])) return $j;
        // kuch builds {data:{...}} bhejte hain
        if (is_array($j) && isset($j['data']['current']['issueNumber'])) return $j['data'];
    }
    return null;
}
/** issueNumber ko N period piche (string, calendar-date borrow ke saath) */
function ar_shift_issue(string $v, int $back): string
{
    if ($back <= 0 || !preg_match('/^\d{8,}$/', $v)) return $v;
    $slot = (int)substr($v, -5);
    $head = substr($v, 0, strlen($v) - 5);
    $slot -= $back;
    while ($slot < 0) {
        $slot += 100000;
        if (preg_match('/^(\d{8})(\d*)$/', $head, $m)) {
            $d = date_create_from_format('Ymd', $m[1]);
            if ($d instanceof DateTime) { $d->modify('-1 day'); $head = $d->format('Ymd') . $m[2]; }
            else { $head = (string)((int)$head - 1); }
        } else { $head = (string)((int)$head - 1); }
    }
    return $head . str_pad((string)$slot, 5, '0', STR_PAD_LEFT);
}
/** upstream ki row ko site ke shape me (result WAHI rahega jo upstream ka) */
function ar_row_to_public(string $gameCode, array $row, int $openTimeMs): array
{
    $issue = (string)($row['issueNumber'] ?? '');
    $premium = (string)($row['premium'] ?? '');
    if ($premium === '' && isset($row['number']) && (string)$row['number'] !== '') $premium = (string)$row['number'];
    $r = le_result_detail($gameCode, $premium, $issue);
    return lottery_public_result($gameCode, $issue, $r, $openTimeMs);
}

// ---------- request -------------------------------------------------------
$gameCode  = (string)($_GET['gameCode'] ?? '');
$path      = (string)($_GET['path'] ?? '');
if ($gameCode === '' && $path !== '') {
    $parts = explode('/', trim($path, '/'));
    $gameCode = $parts[1] ?? ($parts[0] ?? 'WinGo_30S');
}
$gameCode = preg_replace('/\.json$/i', '', $gameCode ?: 'WinGo_30S');
$gameCode = preg_replace('/[^A-Za-z0-9_]/', '', $gameCode ?: 'WinGo_30S');
$folder   = ar_folder($gameCode);
$isHistory = (stripos($path, 'GetHistoryIssuePage') !== false);

// ==========================================================================
//  BRANCH 1 — HISTORY
// ==========================================================================
if ($isHistory) {
    le_settle_pending_bets($gameCode);
    $pageNo   = max(1, (int)($_GET['pageNo'] ?? $_GET['page'] ?? 1));
    $set      = site_settings();
    $pageSize = max(1, min(10, (int)($set['game_history_page_size'] ?? 10)));

    $out = null;
    foreach (ar_code_variants($gameCode) as $code) {
        $base = AR_UPSTREAM . "/{$folder}/{$code}/GetHistoryIssuePage.json";
        if ($__shiftBack > 0) {
            $j1 = ar_get_json($base . "?pageNo={$pageNo}&pageSize=" . ($pageSize + 1));
            $j2 = ar_get_json($base . "?pageNo=" . ($pageNo + 1) . "&pageSize=" . ($pageSize + 1));
            if (!$j1) continue;
            $l1 = $j1['data']['list'] ?? [];
            $l2 = ($j2 && isset($j2['data']['list'])) ? $j2['data']['list'] : [];
            if (!is_array($l1) || count($l1) < 2) continue;
            $merged = array_merge(array_slice($l1, 1), is_array($l2) ? $l2 : []);   // head drop = 1 piche
            $merged = array_slice($merged, 0, $pageSize);
        } else {
            $j = ar_get_json($base . "?pageNo={$pageNo}&pageSize={$pageSize}");
            if (!$j) continue;
            $merged = $j['data']['list'] ?? [];
            if (!is_array($merged) || !$merged) continue;
        }
        $out = [];
        $i = 0;
        foreach ($merged as $row) {
            if (!is_array($row)) continue;
            $openMs = (int)($row['openTime'] ?? $row['blockTimestamp'] ?? 0);
            if ($openMs <= 0) $openMs = now_ms() - ($i + 1) * le_game_interval($gameCode) * 1000;
            $out[] = ar_row_to_public($gameCode, $row, $openMs);
            $i++;
        }
        if ($out) break;
    }

    if ($out === null) {           // fallback: local engine
        $out = [];
        for ($i = 1; $i <= $pageSize; $i++) {
            $offset   = (($pageNo - 1) * $pageSize) + $i;
            $issueNum = le_issue_by_offset($gameCode, $offset + $__shiftBack);
            $r        = le_result_for_issue($gameCode, $issueNum, true);
            $out[]    = lottery_public_result($gameCode, (string)$issueNum, $r,
                        now_ms() - $offset * le_game_interval($gameCode) * 1000);
        }
    }
    api_success(['list'=>$out,'pageNo'=>$pageNo,'pageSize'=>$pageSize,'totalPage'=>999,'totalCount'=>9990], 'Succeed', ['serviceTime'=>now_ms()]);
}

// ==========================================================================
//  BRANCH 2 — CURRENT ISSUE
//  lottery_issue() ab khud upstream se laata hai AUR shift lagata hai
//  (bootstrap.php me patch). Isliye yahan double-shift NAHI karna.
//  le_issue_is_closed() bhi isi ko use karta hai -> bet validity sahi.
// ==========================================================================
$iss = lottery_issue($gameCode);
$iss['issueNo'] = $iss['issueNumber'];
$iss['period']  = $iss['issueNumber'];

api_success($iss);
