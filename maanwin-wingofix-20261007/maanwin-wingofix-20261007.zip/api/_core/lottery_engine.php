<?php
// Lottery engine for demo/virtual-wallet backend.
// Handles WinGo, TrxWinGo, K3, 5D/D5 and MotoRace bet settlement.

function le_game_interval(string $gameCode): int
{
    if (stripos($gameCode, '30S') !== false) return 30;
    if (stripos($gameCode, '3Min') !== false || stripos($gameCode, '_3M') !== false) return 180;
    if (stripos($gameCode, '5Min') !== false || stripos($gameCode, '_5M') !== false) return 300;
    if (stripos($gameCode, '10Min') !== false || stripos($gameCode, '_10M') !== false) return 600;
    return 60;
}

function le_is_k3(string $gameCode): bool { return stripos($gameCode, 'K3') === 0; }
function le_is_d5(string $gameCode): bool { return stripos($gameCode, '5D') === 0 || stripos($gameCode, 'D5') === 0; }
function le_is_moto(string $gameCode): bool { return stripos($gameCode, 'MotoRace') === 0 || stripos($gameCode, 'Moto') === 0; }
function le_is_wingo(string $gameCode): bool { return !le_is_k3($gameCode) && !le_is_d5($gameCode) && !le_is_moto($gameCode); }

function le_default_settings(): array
{
    return [
        'win_rate' => 45.0,
        'force_mode' => 'auto', // auto / win / lose
        'force_result' => '',
        'fee_percent' => 0.0,
        'payout_number' => 9.0,
        'payout_color' => 2.0,
        'payout_violet' => 4.5,
        'payout_bigsmall' => 2.0,
        'payout_k3' => 2.0,
        'payout_5d' => 9.5,
        'payout_moto' => 9.5,
        'immediate_settle' => 0,
    ];
}

function le_get_settings(string $gameCode): array
{
    $s = le_default_settings();
    $conn = db();
    if (!$conn) return $s;
    $stmt = @$conn->prepare('SELECT * FROM lottery_game_settings WHERE game_code=? OR game_code="*" ORDER BY game_code="*" ASC LIMIT 1');
    if (!$stmt) return $s;
    $stmt->bind_param('s', $gameCode);
    if (!$stmt->execute()) return $s;
    $row = $stmt->get_result()->fetch_assoc();
    if (!$row) return $s;
    foreach ($s as $k => $v) {
        if (array_key_exists($k, $row) && $row[$k] !== null && $row[$k] !== '') {
            $s[$k] = is_numeric($v) ? (float)$row[$k] : $row[$k];
        }
    }
    $s['immediate_settle'] = (int)($row['immediate_settle'] ?? 1);
    return $s;
}

function le_issue_by_offset(string $gameCode, int $offset = 0): string
{
    $interval = le_game_interval($gameCode);
    $now = time() - ($offset * $interval);
    $slot = intdiv($now, $interval);
    return date('Ymd', $slot * $interval) . '1000' . str_pad((string)($slot % 100000), 5, '0', STR_PAD_LEFT);
}

function le_color_from_number(int $n): string
{
    if ($n === 0) return 'red,violet';
    if ($n === 5) return 'green,violet';
    return ($n % 2 === 0) ? 'red' : 'green';
}

function le_result_detail(string $gameCode, string $premium, string $issueNumber = ''): array
{
    if (le_is_moto($gameCode)) {
        $parts = array_values(array_filter(array_map('trim', explode(',', $premium)), 'strlen'));
        $first = (int)($parts[0] ?? 1);
        return [
            'issueNumber' => $issueNumber,
            'premium' => $premium,
            'number' => $premium,
            'firstNumber' => $first,
            'color' => $first % 2 ? 'green' : 'red',
            'bigSmall' => $first > 5 ? 'big' : 'small',
            'sum' => array_sum(array_map('intval', $parts)),
        ];
    }
    if (le_is_k3($gameCode)) {
        $normalised = str_replace(['|','-',' '], ',', trim($premium));
        $parts = array_values(array_filter(array_map('trim', explode(',', $normalised)), 'strlen'));
        if (count($parts) === 1 && preg_match('/^[1-6]{3}$/', (string)$parts[0])) $parts = str_split((string)$parts[0]);
        $valid = count($parts) === 3 && count(array_filter($parts, fn($n)=>(int)$n >= 1 && (int)$n <= 6)) === 3;
        if (!$valid) $parts = [random_int(1,6), random_int(1,6), random_int(1,6)];
        $sum = array_sum(array_map('intval', $parts));
        return [
            'issueNumber' => $issueNumber,
            'premium' => implode(',', $parts),
            'number' => implode('', $parts),
            'dice' => $parts,
            'color' => $sum % 2 ? 'green' : 'red',
            'bigSmall' => $sum >= 11 ? 'big' : 'small',
            'sum' => $sum,
        ];
    }
    if (le_is_d5($gameCode)) {
        $digits = preg_replace('/\D+/', '', $premium);
        if (strlen($digits) < 5) $digits = str_pad($digits, 5, (string)random_int(0,9));
        $digits = substr($digits, 0, 5);
        $arr = array_map('intval', str_split($digits));
        $sum = array_sum($arr);
        return [
            'issueNumber' => $issueNumber,
            'premium' => $digits,
            'number' => $digits,
            'color' => $sum % 2 ? 'green' : 'red',
            'bigSmall' => $sum >= 23 ? 'big' : 'small',
            'sum' => $sum,
        ];
    }
    $n = (int)preg_replace('/\D+/', '', $premium);
    $n = max(0, min(9, $n));
    return [
        'issueNumber' => $issueNumber,
        'premium' => (string)$n,
        'number' => (string)$n,
        'color' => le_color_from_number($n),
        'bigSmall' => $n > 4 ? 'big' : 'small',
        'sum' => $n,
    ];
}

function le_random_premium(string $gameCode): string
{
    if (le_is_moto($gameCode)) { $nums = range(1, 10); shuffle($nums); return implode(',', $nums); }
    if (le_is_k3($gameCode)) return implode(',', [random_int(1,6), random_int(1,6), random_int(1,6)]);
    if (le_is_d5($gameCode)) return implode('', [random_int(0,9), random_int(0,9), random_int(0,9), random_int(0,9), random_int(0,9)]);
    return (string)random_int(0, 9);
}

function le_ensure_lottery_results_table($conn) {
    static $ensured = false;
    if ($ensured) return;
    $ensured = true;
    $conn->query("CREATE TABLE IF NOT EXISTS lottery_results (
      id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
      game_code VARCHAR(50) NOT NULL,
      issue_number VARCHAR(50) NOT NULL,
      premium VARCHAR(20) NOT NULL,
      number VARCHAR(20) NOT NULL,
      color VARCHAR(20) NOT NULL,
      big_small VARCHAR(20) NOT NULL,
      sum_value INT NOT NULL,
      open_time DATETIME NULL,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      UNIQUE KEY uq_game_issue (game_code, issue_number)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
}

// ==========================================================================
//  UPSTREAM RESULT SOURCE  (bet settlement ke liye)
//  Local DB me result na mile to pehle draw.ar-lottery01.com se lao.
//  Upstream bhi na mile to tabhi random generate karo (purana behaviour).
// ==========================================================================
if (!defined('LE_UPSTREAM'))      define('LE_UPSTREAM', 'https://draw.ar-lottery01.com');
if (!defined('LE_UPSTREAM_ORIGIN')) define('LE_UPSTREAM_ORIGIN', 'https://maanwin16.com');

// ==========================================================================
//  SETTING — PERIOD SHIFT  (yahi ek jagah badlo)
//    -1  = period AUR result dono 1 piche   (ABHI YAHI SET HAI)
//     0  = upstream jaisa exact
//    -2  = 2 period piche
// ==========================================================================
if (!defined('AR_PERIOD_SHIFT')) define('AR_PERIOD_SHIFT', -1);
// ==========================================================================

/** issueNumber ko N period piche (string math + calendar-date borrow) */
function le_shift_issue_str(string $v, int $back): string
{
    if ($back <= 0 || !preg_match('/^\d{8,}$/', $v)) return $v;
    $slot = (int)substr($v, -5);
    $head = substr($v, 0, strlen($v) - 5);
    $slot -= $back;
    while ($slot < 0) {
        $slot += 100000;
        if (preg_match('/^(\d{8})(\d*)$/', $head, $m)) {
            $d = date_create_from_format('Ymd', $m[1]);
            if ($d instanceof DateTime) { $d->modify('-1 day'); $head = $d->format('Ymd') . $m[2]; }
            else { $head = (string)((int)$head - 1); }
        } else { $head = (string)((int)$head - 1); }
    }
    return $head . str_pad((string)$slot, 5, '0', STR_PAD_LEFT);
}

/** upstream se current window lao: startTime/endTime/issueNumber/intervalSecond */
function le_upstream_window(string $gameCode)
{
    $folder = le_upstream_folder($gameCode);
    $codes  = [$gameCode];
    if (preg_match('/_(\d+)M$/i', $gameCode))   $codes[] = preg_replace('/_(\d+)M$/i',   '_${1}Min', $gameCode);
    if (preg_match('/_(\d+)Min$/i', $gameCode)) $codes[] = preg_replace('/_(\d+)Min$/i', '_${1}M',   $gameCode);
    $codes = array_values(array_unique($codes));

    foreach ($codes as $code) {
        $j = le_upstream_fetch(LE_UPSTREAM . "/{$folder}/{$code}.json", 2);
        if (!is_array($j)) continue;
        $cur = $j['current'] ?? ($j['data']['current'] ?? null);
        if (!is_array($cur) || !isset($cur['issueNumber'])) continue;
        $ivMin = (float)($j['intervalMinute'] ?? 0);
        $ivSec = $ivMin > 0 ? (int)round($ivMin * 60) : le_game_interval($gameCode);
        return [
            'issueNumber'    => (string)$cur['issueNumber'],
            'startTime'      => (int)($cur['startTime'] ?? 0),
            'endTime'        => (int)($cur['endTime'] ?? 0),
            'intervalSecond' => $ivSec,
        ];
    }
    return null;
}

/** site ka CURRENT issue number (upstream - shift). Har jagah yahi use hoga. */
function le_site_current_issue(string $gameCode): string
{
    $back = max(0, abs((int)AR_PERIOD_SHIFT));
    $up   = le_upstream_window($gameCode);
    if ($up !== null) return le_shift_issue_str((string)$up['issueNumber'], $back);
    return le_issue_by_offset($gameCode, $back);
}

function le_upstream_folder(string $gc): string
{
    foreach (['TrxWinGo', 'MotoRace', 'WinGo', 'K3', 'D5'] as $f) {
        if (stripos($gc, $f) === 0) return $f;
    }
    return 'WinGo';
}
function le_upstream_fetch(string $url, int $ttl = 3)
{
    if (!function_exists('curl_init')) return null;
    $dir = sys_get_temp_dir() . '/le_up_cache';
    if (!is_dir($dir)) @mkdir($dir, 0775, true);
    $cf = $dir . '/' . md5($url) . '.json';
    if (is_file($cf) && (time() - filemtime($cf)) < $ttl) {
        $d = json_decode((string)@file_get_contents($cf), true);
        if (is_array($d)) return $d;
    }
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true, CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_TIMEOUT => 6, CURLOPT_CONNECTTIMEOUT => 4,
        CURLOPT_SSL_VERIFYPEER => true, CURLOPT_SSL_VERIFYHOST => 2,
        CURLOPT_ENCODING => '',
        CURLOPT_HTTPHEADER => [
            'Origin: ' . LE_UPSTREAM_ORIGIN,
            'Referer: ' . LE_UPSTREAM_ORIGIN . '/',
            'Accept: application/json, text/plain, */*',
        ],
    ]);
    $raw = curl_exec($ch);
    $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    if ($raw === false || $code < 200 || $code >= 300) return null;
    $d = json_decode((string)$raw, true);
    if (!is_array($d)) return null;
    if (is_dir($dir)) @file_put_contents($cf, (string)$raw);
    return $d;
}
/** upstream se is issue ka premium string lao; nahi mila to null */
function le_upstream_premium(string $gameCode, string $issueNumber)
{
    if ($issueNumber === '' || !preg_match('/^\d{6,}$/', $issueNumber)) return null;
    $folder = le_upstream_folder($gameCode);
    $codes  = [$gameCode];
    if (preg_match('/_(\d+)M$/i', $gameCode))   $codes[] = preg_replace('/_(\d+)M$/i',   '_${1}Min', $gameCode);
    if (preg_match('/_(\d+)Min$/i', $gameCode)) $codes[] = preg_replace('/_(\d+)Min$/i', '_${1}M',   $gameCode);
    $codes = array_values(array_unique($codes));

    foreach ($codes as $code) {
        for ($page = 1; $page <= 3; $page++) {
            $j = le_upstream_fetch(LE_UPSTREAM . "/{$folder}/{$code}/GetHistoryIssuePage.json?pageNo={$page}&pageSize=20");
            if (!is_array($j)) continue;
            $list = $j['data']['list'] ?? ($j['list'] ?? null);
            if (!is_array($list) || !$list) continue;
            foreach ($list as $row) {
                if (!is_array($row)) continue;
                if ((string)($row['issueNumber'] ?? '') !== $issueNumber) continue;
                $premium = (string)($row['premium'] ?? '');
                if ($premium === '' && isset($row['number']) && (string)$row['number'] !== '') {
                    $premium = (string)$row['number'];
                }
                return $premium !== '' ? $premium : null;
            }
        }
    }
    return null;
}
// ==========================================================================

function le_result_for_issue(string $gameCode, string $issueNumber, bool $save = true): array
{
    $conn = db();
    if ($conn) le_ensure_lottery_results_table($conn);
    if ($conn) {
        $stmt = @$conn->prepare('SELECT id, game_code, issue_number, premium, number, color, big_small, sum_value, open_time, created_at FROM lottery_results WHERE game_code=? AND issue_number=? ORDER BY id ASC LIMIT 1');
        if (!$stmt) error_log('lottery_results read unavailable: ' . $conn->error);
        if ($stmt) {
            $stmt->bind_param('ss', $gameCode, $issueNumber);
            $stmt->execute();
            $row = $stmt->get_result()->fetch_assoc();
            if ($row) return le_result_detail($gameCode, (string)$row['premium'], $issueNumber);
        }
    }
    $settings = le_get_settings($gameCode);
    $forceResult = trim((string)($settings['force_result'] ?? ''));

    // ---- UPSTREAM: asli result wahin se aana chahiye (bet settlement) ----
    $upstreamPremium = null;
    if ($forceResult === '' && $issueNumber !== '') {
        $upstreamPremium = le_upstream_premium($gameCode, $issueNumber);
    }

    if ($forceResult !== '') {
        $premium = $forceResult;
    } elseif ($upstreamPremium !== null) {
        $premium = $upstreamPremium;
    } else {
        $premium = le_random_premium($gameCode);
        if ($conn && $issueNumber !== '') {
            $gEsc = $conn->real_escape_string($gameCode);
            $iEsc = $conn->real_escape_string($issueNumber);
            $q = $conn->query("SELECT bet_content FROM lottery_bets WHERE game_code='$gEsc' AND issue_number='$iEsc' AND state=2 ORDER BY id ASC LIMIT 1");
            $bet = $q ? $q->fetch_assoc() : null;
            if ($bet) {
                $choice = le_extract_choice($gameCode, (string)$bet['bet_content']);
                $force = (string)($settings['force_mode'] ?? 'auto');
                if ($force === 'win') {
                    $premium = le_premium_for_choice($gameCode, $choice, true);
                } elseif ($force === 'lose') {
                    $premium = le_premium_for_choice($gameCode, $choice, false);
                } else {
                    $shouldWin = (random_int(1,10000) <= (int)round(((float)$settings['win_rate'])*100));
                    $premium = le_premium_for_choice($gameCode, $choice, $shouldWin);
                }
            }
        }
    }
    $detail = le_result_detail($gameCode, $premium, $issueNumber);
    if ($conn && $save) {
        $premium = (string)$detail['premium'];
        $number = (string)$detail['number'];
        $color = (string)$detail['color'];
        $bigSmall = (string)$detail['bigSmall'];
        $sum = (int)$detail['sum'];
        $stmt = @$conn->prepare('INSERT IGNORE INTO lottery_results(game_code, issue_number, premium, number, color, big_small, sum_value, open_time, created_at) VALUES(?,?,?,?,?,?,?,NOW(),NOW())');
        if (!$stmt) error_log('lottery_results write unavailable: ' . $conn->error);
        if ($stmt) { 
            $stmt->bind_param('ssssssi', $gameCode, $issueNumber, $premium, $number, $color, $bigSmall, $sum); 
            $stmt->execute();
        }
        $stmt2 = @$conn->prepare('SELECT * FROM lottery_results WHERE game_code=? AND issue_number=? ORDER BY id ASC LIMIT 1');
        if ($stmt2) {
            $stmt2->bind_param('ss', $gameCode, $issueNumber);
            $stmt2->execute();
            $row2 = $stmt2->get_result()->fetch_assoc();
            if ($row2) {
                return le_result_detail($gameCode, (string)$row2['premium'], $issueNumber);
            }
        }
    }
    return $detail;
}

function le_bet_content_from_request(array $d): string
{
    @file_put_contents(__DIR__ . '/bet_debug.log', date('Y-m-d H:i:s') . ' PAYLOAD: ' . json_encode($d) . "\n", FILE_APPEND);
    if (isset($d['betContent'])) return (string)$d['betContent'];
    
    // Find type and value dynamically from all possible keys
    $type = '';
    $val = '';
    
    $typeKeys = ['selectType', 'playType', 'betType', 'type', 'gameType'];
    foreach ($typeKeys as $k) {
        if (isset($d[$k]) && is_string($d[$k]) && $d[$k] !== '') {
            $type = strtolower(trim($d[$k]));
            break;
        }
    }
    
    $valKeys = ['playBet', 'bettingContent', 'pick', 'content', 'value', 'select', 'choice', 'option', 'number', 'color', 'bigSmall'];
    foreach ($valKeys as $k) {
        if (isset($d[$k]) && is_string($d[$k]) && $d[$k] !== '') {
            $val = trim($d[$k]);
            break;
        }
    }
    
    if ($type !== '' && $val !== '') {
        if ($type === 'bigsmalleven' || $type === 'bsoe' || $type === 'size') {
            // "1" is Small and "0" is Big based on the user's inverted win reports
            if ($val === '1' || $val === 's' || $val === 'small') return 'small';
            if ($val === '0' || $val === 'b' || $val === 'big') return 'big';
            if ($val === '2') return 'even';
            if ($val === '3') return 'odd';
            return 'bigsmall_' . $val;
        }
        if ($type === 'color' || $type === 'colour') {
            if ($val === '10' || $val === 'g' || $val === 'green' || $val === '1') return 'green';
            if ($val === '20' || $val === 'v' || $val === 'violet' || $val === '2') return 'violet';
            if ($val === '30' || $val === 'r' || $val === 'red' || $val === '3') return 'red';
            return 'color_' . $val;
        }
        if ($type === 'num' || $type === 'number') {
            return (string)$val;
        }
        return $type . '_' . $val;
    }

    // Fallback if we couldn't find type/val clearly
    $keys = ['bettingContent','playType','betType','pick','content','selectType','number','color','bigSmall','betInfo','betDetail','name','title','value','betName','bet_name','select','choice','option'];
    foreach ($keys as $k) {
        if (isset($d[$k]) && $d[$k] !== '' && !is_array($d[$k])) {
            $val = (string)$d[$k];
            $lower = strtolower(trim($val));
            if (!in_array($lower, ['bigsmalleven', 'bsoe', 'num', 'number', 'color', 'sum', 'playbet'], true)) {
                return $val;
            }
        }
    }
    return json_encode($d, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
}

function le_total_amount_from_request(array $d): array
{
    $amount = (float)first_value($d, ['amount','betAmount','bettingAmount','singleAmount','money','baseAmount','selectAmount','contractMoney'], 0);
    $multiple = (int)first_value($d, ['betMultiple','multiple','quantity','bettingQuantity','betCount','count','contractCount'], 1);
    if ($amount <= 0 && isset($d['totalAmount'])) { $amount = (float)$d['totalAmount']; $multiple = 1; }
    if ($multiple <= 0) $multiple = 1;
    return [$amount, $multiple, round($amount * $multiple, 2)];
}

function le_extract_choice(string $gameCode, string $content): array
{
    $c = trim(strtolower($content));
    
    $result = ['kind'=>'number','value'=>'0'];
    
    // Direct matches for common combined strings like 'BigSmall_Small'
    if ($c === 'bigsmall_small' || $c === 'small') {
        $result = ['kind'=>'bigsmall','value'=>'small'];
    } elseif ($c === 'bigsmall_big' || $c === 'big') {
        $result = ['kind'=>'bigsmall','value'=>'big'];
    } elseif (strpos($c, 'color_red') !== false || $c === 'red') {
        $result = ['kind'=>'color','value'=>'red'];
    } elseif (strpos($c, 'color_green') !== false || $c === 'green') {
        $result = ['kind'=>'color','value'=>'green'];
    } elseif (strpos($c, 'color_violet') !== false || strpos($c, 'color_purple') !== false || $c === 'violet' || $c === 'purple') {
        $result = ['kind'=>'color','value'=>'violet'];
    } else {
        // Strip frontend meta-strings from the payload so 'bigsmalleven' doesn't falsely trigger 'small'
        $c = str_replace(['bigsmalleven', 'bsoe', 'playbet', 'selecttype', '"', "'", 'bigsmall_'], ' ', $c);
        
        if ($c === 'b' || $c === 'bada' || $c === '40') $result = ['kind'=>'bigsmall','value'=>'big'];
        elseif ($c === 's' || $c === 'chota' || $c === '50') $result = ['kind'=>'bigsmall','value'=>'small'];
        elseif ($c === 'g' || $c === '10') $result = ['kind'=>'color','value'=>'green'];
        elseif ($c === 'v' || $c === '20') $result = ['kind'=>'color','value'=>'violet'];
        elseif ($c === 'r' || $c === '30') $result = ['kind'=>'color','value'=>'red'];
        elseif (strpos($c, 'violet') !== false || strpos($c, 'purple') !== false) $result = ['kind'=>'color','value'=>'violet'];
        elseif (strpos($c, 'green') !== false) $result = ['kind'=>'color','value'=>'green'];
        elseif (strpos($c, 'red') !== false) $result = ['kind'=>'color','value'=>'red'];
        else {
            $hasSmall = (strpos($c, 'small') !== false || strpos($c, 'chota') !== false);
            $hasBig = (strpos($c, 'big') !== false || strpos($c, 'bada') !== false);
            if ($hasSmall && !$hasBig) $result = ['kind'=>'bigsmall','value'=>'small'];
            elseif ($hasBig && !$hasSmall) $result = ['kind'=>'bigsmall','value'=>'big'];
            else {
                $clean = preg_replace('/(wingo|trxwingo|k3|5d|d5|motorace|motogame|1min|3min|5min|30s|issue|gamecode|amount|multiple|betcontent|playtype|playbet|bigsmall|size)/i', ' ', $content);
                if (le_is_moto($gameCode) && preg_match('/\b(10|[1-9])\b/', $clean, $m)) $result = ['kind'=>'number','value'=>(string)(int)$m[1]];
                elseif (le_is_k3($gameCode) && preg_match('/\b([3-9]|1[0-8])\b/', $clean, $m)) $result = ['kind'=>'sum','value'=>(string)(int)$m[1]];
                elseif (preg_match('/\b([0-9])\b/', $clean, $m)) $result = ['kind'=>'number','value'=>(string)(int)$m[1]];
                elseif (preg_match('/(?:num|number|digit|select)[^0-9]*([0-9])/', $c, $m)) $result = ['kind'=>'number','value'=>(string)(int)$m[1]];
            }
        }
    }
    
    @file_put_contents(__DIR__ . '/bet_debug.log', date('Y-m-d H:i:s') . ' EXTRACT_CHOICE IN: ' . $content . ' OUT: ' . json_encode($result) . "\n", FILE_APPEND);
    return $result;
}

function le_result_matches(array $choice, array $result, string $gameCode): bool
{
    $kind = $choice['kind'] ?? 'number';
    $value = trim(strtolower((string)($choice['value'] ?? '')));
    $bigSmall = trim(strtolower((string)($result['bigSmall'] ?? '')));
    $colorStr = trim(strtolower((string)($result['color'] ?? '')));
    
    if ($kind === 'color') return in_array($value, array_map('trim', explode(',', $colorStr)), true);
    if ($kind === 'bigsmall') return $bigSmall === $value;
    if ($kind === 'sum') return (string)((int)$result['sum']) === (string)((int)$value);
    if (le_is_moto($gameCode)) return (string)((int)($result['firstNumber'] ?? 0)) === (string)((int)$value);
    if (le_is_k3($gameCode)) return strpos((string)$result['number'], (string)((int)$value)) !== false;
    if (le_is_d5($gameCode)) return strpos((string)$result['number'], (string)((int)$value)) !== false;
    
    return (string)((int)$result['number']) === (string)((int)$value);
}

function le_premium_for_choice(string $gameCode, array $choice, bool $shouldWin): string
{
    for ($i=0; $i<60; $i++) {
        if ($shouldWin) {
            if (le_is_wingo($gameCode)) {
                if ($choice['kind'] === 'number') $premium = (string)((int)$choice['value']);
                elseif ($choice['kind'] === 'color') {
                    $map = ['red'=>[2,4,6,8], 'green'=>[1,3,7,9], 'violet'=>[0,5]];
                    $arr = $map[strtolower($choice['value'])] ?? [0];
                    $premium = (string)$arr[array_rand($arr)];
                } else {
                    $premium = strtolower($choice['value']) === 'big' ? (string)random_int(5,9) : (string)random_int(0,4);
                }
            } elseif (le_is_k3($gameCode)) {
                if (($choice['kind'] ?? '') === 'sum') {
                    $target = max(3, min(18, (int)$choice['value']));
                    $a = random_int(1,6); $b = random_int(1,6); $c = max(1, min(6, $target-$a-$b));
                    while ($a+$b+$c !== $target) { $a=random_int(1,6); $b=random_int(1,6); $c=random_int(1,6); }
                    $premium = "$a,$b,$c";
                } else $premium = le_random_premium($gameCode);
            } elseif (le_is_d5($gameCode)) {
                $digit = preg_match('/^[0-9]$/', (string)$choice['value']) ? (string)$choice['value'] : (string)random_int(0,9);
                $arr = [random_int(0,9),random_int(0,9),random_int(0,9),random_int(0,9),random_int(0,9)];
                $arr[random_int(0,4)] = (int)$digit;
                $premium = implode('', $arr);
            } elseif (le_is_moto($gameCode)) {
                $first = max(1, min(10, (int)$choice['value']));
                $nums = range(1,10); shuffle($nums); $nums = array_values(array_diff($nums, [$first])); array_unshift($nums, $first);
                $premium = implode(',', $nums);
            } else $premium = le_random_premium($gameCode);
        } else {
            $premium = le_random_premium($gameCode);
        }
        $detail = le_result_detail($gameCode, $premium);
        if (le_result_matches($choice, $detail, $gameCode) === $shouldWin) return $premium;
    }
    return le_random_premium($gameCode);
}

function le_payout_rate(string $gameCode, array $choice, array $settings): float
{
    if (le_is_k3($gameCode)) return (float)$settings['payout_k3'];
    if (le_is_d5($gameCode)) return (float)$settings['payout_5d'];
    if (le_is_moto($gameCode)) return (float)$settings['payout_moto'];
    // Hardcode rates to prevent 10x payouts from DB misconfigurations
    if (($choice['kind'] ?? '') === 'color') return strtolower((string)$choice['value']) === 'violet' ? 4.5 : 2.0;
    if (($choice['kind'] ?? '') === 'bigsmall') return 2.0;
    return (float)($settings['payout_number'] ?? 9.0);
}

function le_response_row(array $r): array
{
    $premium = trim((string)($r['premium'] ?? ''));
    if ($premium === '') {
        $result = ['number'=>'','color'=>'','bigSmall'=>'','sum'=>0,'premium'=>''];
    } else {
        $result = le_result_detail((string)$r['game_code'], $premium, (string)$r['issue_number']);
    }
    return [
        'orderNo' => (string)$r['order_no'],
        'issueNumber' => (string)$r['issue_number'],
        'gameCode' => (string)$r['game_code'],
        'betContent' => (string)$r['bet_content'],
        'amount' => (float)$r['amount'],
        'betMultiple' => (int)$r['bet_multiple'],
        'realAmount' => (float)$r['real_amount'],
        'fee' => (float)$r['fee'],
        'premium' => $premium,
        'number' => (string)$result['number'],
        'color' => (string)$result['color'],
        'bigSmall' => (string)$result['bigSmall'],
        'sum' => (int)$result['sum'],
        'playType' => explode('_', (string)$r['bet_content'])[0] ?? '',
        'state' => (int)$r['state'],
        'isWin' => (int)$r['state'] === 1,
        'isPending' => (int)$r['state'] === 2,
        'winLoseAmount' => (float)$r['win_lose_amount'],
        'betTime' => strtotime((string)$r['created_at']) * 1000,
        'createTime' => strtotime((string)$r['created_at']) * 1000,
    ];
}

function le_issue_is_closed(string $gameCode, string $issueNumber): bool
{
    $issueNumber = trim($issueNumber);
    if ($issueNumber === '') return false;
    $current = function_exists('lottery_issue') ? lottery_issue($gameCode)['issueNumber'] : le_site_current_issue($gameCode);
    return strcmp($issueNumber, (string)$current) < 0;
}

function le_settle_pending_bets(string $gameCode = '', string $issueNumber = '', int $userId = 0, string $orderNo = ''): int
{
    $conn = db();
    if (!$conn) return 0;
    $where = ['state=2'];
    if ($gameCode !== '') $where[] = "game_code='" . $conn->real_escape_string($gameCode) . "'";
    if ($issueNumber !== '') $where[] = "issue_number='" . $conn->real_escape_string($issueNumber) . "'";
    if ($userId > 0) $where[] = 'user_id=' . (int)$userId;
    if ($orderNo !== '') $where[] = "order_no='" . $conn->real_escape_string($orderNo) . "'";
    $sql = 'SELECT * FROM lottery_bets WHERE ' . implode(' AND ', $where) . ' ORDER BY id ASC LIMIT 500';
    $rs = $conn->query($sql);
    if (!$rs) return 0;
    $settled = 0;
    while ($r = $rs->fetch_assoc()) {
        $g = (string)$r['game_code'];
        $issue = (string)$r['issue_number'];
        if (!le_issue_is_closed($g, $issue)) continue;

        $result = le_result_for_issue($g, $issue, true);
        $choice = le_extract_choice($g, (string)$r['bet_content']);
        $settings = le_get_settings($g);
        $isWin = le_result_matches($choice, $result, $g);
        $rate = le_payout_rate($g, $choice, $settings);
        $stake = (float)$r['real_amount'];
        $fee = (float)$r['fee'];
        $debit = round($stake + $fee, 2);
        // Apply 2% tax to the gross winning payout: ₹100 at 2x credits ₹196.
        $grossPayout = $isWin ? round($stake * $rate, 2) : 0.0;
        $payout = $isWin ? round($grossPayout * 0.98, 2) : 0.0;
        $net = round($payout - $debit, 2);
        $state = $isWin ? 1 : 0;
        $premium = (string)$result['premium'];
        $betId = (int)$r['id'];
        $uid = (int)$r['user_id'];
        $order = (string)$r['order_no'];
        $vendor = 'ARLottery';
        $remark = $g . ' ' . (string)$r['bet_content'] . ' result ' . $premium;

        @$conn->begin_transaction();
        $check = $conn->query('SELECT state FROM lottery_bets WHERE id=' . $betId . ' FOR UPDATE');
        $fresh = $check ? $check->fetch_assoc() : null;
        if (!$fresh || (int)$fresh['state'] !== 2) { @$conn->rollback(); continue; }

        $stmt = $conn->prepare('UPDATE lottery_bets SET premium=?, state=?, win_lose_amount=? WHERE id=?');
        if (!$stmt) { @$conn->rollback(); continue; }
        $stmt->bind_param('sidi', $premium, $state, $net, $betId);
        if (!$stmt->execute()) { @$conn->rollback(); continue; }

        $settlement = wallet_apply_delta($conn, $uid, $payout, 'GameEnd', $order, $remark, $isWin ? 'Win' : 'Loss', $vendor, ['gameCode'=>$g,'issueNumber'=>$issue,'premium'=>$premium,'isWin'=>$isWin,'net'=>$net]);
        if (!$settlement) { @$conn->rollback(); continue; }
        @$conn->commit();
        $settled++;
    }
    return $settled;
}
