{
    "data": {
        "version": "2026-04-20 001",
        "arUpiInputUtrSwitch": false,
        "arbApiUrl": [
            "https://apiweb.apiarbpay.com"
        ],
        "isShowAppDownloadUp": false,
        "isShowAppDownloadDown": true,
        "isShowRewardCenter": true,
        "isShowLotteryDragon": true,
        "isSplitLocalEWallet": true,
        "jackportMaxReswadAmount": 500.00,
        "projectName": "dmfirst",
        "projectLogo": "https://ossimg.dmfirst9acting.com/dmfirst/other/h5setting_20260831205223148v.png",
        "languages": "en|hd",
        "webIco": "https://ossimg.dmfirst9acting.com/dmfirst/other/h5setting_20260831205232ljah.png",
        "headLogo": "https://ossimg.dmfirst9acting.com/dmfirst/other/h5setting_202608312052286nxa.png",
        "dollarSign": "₹",
        "upperOrLower": "0",
        "defaultCurrentLanguage": "en",
        "registerMobile": "1",
        "registerEmail": "0",
        "areaPhoneLenList": [
            {
                "area": "+91",
                "len": "9-12"
            }
        ],
        "registerSms": "0",
        "isOpenLoginChangeLanguage": "1",
        "rewardValidityTime": 3,
        "electronicWinRateExternalLink": "",
        "electronicWinRateImgUrl": "",
        "isShowElectronicWinRateExternalLink": false,
        "isShowAppHandCodeWashingSwitch": true,
        "isShowHotGameWinOdds": true,
        "ossUrl": "https://ossimg.dmfirst9acting.com",
        "bigTurntableLink": "",
        "bigTurntableImgUrl": "",
        "telegramExternalLink": "",
        "telegramImgUrl": "",
        "isOpenActivityAward": true,
        "isOpenTurntable": true,
        "isPartnerReward": true,
        "isSelfCustomerService": true,
        "webSiteUrl": "https://www.dmfirst0.com",
        "isOpenFacebookEvent": true,
        "firstDepositRewardCodeAmount": "1",
        "isOpenRegisterPhoneFirstZeroSwitch": false,
        "eventRegionConfigList": [
            {
                "domainUrl": "https://dmfirst12.com",
                "pixelId": "2495557887592050",
                "sort": 4
            },
            {
                "domainUrl": "https://dmfirst12.com/#/register?invitationCode=46469139817",
                "pixelId": "2495557887592050",
                "sort": 3
            },
            {
                "domainUrl": "https://dmfirst11.com",
                "pixelId": "2338740186944490",
                "sort": 2
            },
            {
                "domainUrl": "https://dmfirst11.com/#/register?invitationCode=64127139661",
                "pixelId": "2338740186944490",
                "sort": 1
            }
        ],
        "isOpenAdjustEvent": false,
        "firebaseConfig": null,
        "isOpenArLottery": true,
        "isSwitchSaasBalance": false,
        "isV3Mode": true,
        "isOpenInvitedWheel": true,
        "invitedWheelTotalPrizeAmount": 500.0,
        "invitedWheelImgUrl": "https://ossimg.dmfirst9acting.com/dmfirst/tab/wheel.png",
        "isOpenDownAppRewardSwitch": true,
        "isShowDownAppBonusAmountSwitch": true,
        "downAppBonusAmount": 28.0,
        "downAppRechargeAmount": 1000.0,
        "needKycValidIsOpen": false,
        "needFastKycValidIsOpen": false,
        "lotteryDragonIcon": "https://ossimg.dmfirst9acting.com/dmfirst/vendorlogo/vendorlogo_202608261544589mbh.png",
        "bonusCenterImgUrl": "https://ossimg.dmfirst9acting.com/dmfirst/vendorlogo/vendorlogo_202609101849372w4p.jpg",
        "isShowBonusCenterExternalLink": true,
        "isOpenBrowserConsoleDebug": false,
        "homeBigTurntableSwitch": true,
        "homeBigTurntableLink": "www.baidu.com }",
        "homeBigTurntableImgUrl": "https://ossimg.dmfirst9acting.com/dmfirst/vendorlogo/vendorlogo_202608261544204l3m.png",
        "jgConfig": {
            "webConfig": null,
            "appConfig": null
        },
        "lastestAppVersionInfo": null
    },
    "code": 0,
    "msg": "Succeed",
    "msgCode": 0,
    "traceId": "",
    "serviceNowTime": "2026-09-20 23:33:46"
}