<?php
/**
 * DMFirst — public draw feed  (shreewin-style, saasLottery build)
 *
 * Frontend (assets/js/main.vue_...-CMJTpNuV.js) in dono URL maangta hai:
 *
 *   https://dmfirst.club9.eu.cc/draw-live-v4/WinGo/WinGo_30S.json
 *   https://dmfirst.club9.eu.cc/draw-live-v4/WinGo/WinGo_30S/GetHistoryIssuePage.json
 *
 * ============================ BAHUT ZAROORI ============================
 * Is bundle ka axios `transformRequestHook` RAW body return karta hai
 * (`isTransformResponse` kabhi set hi nahi hota), isliye:
 *
 *   CURRENT JSON  -> POORA FLAT bhejna padta hai
 *     { gameCode, lotteryCode, intervalMinute, state, previous, current, next }
 *     Kyunki BetRule-BPPqmoWm.js  `const a = await Se(...)` karke seedha
 *     `a.current`, `a.intervalMinute`, `a.state`, `a.next` padhta hai.
 *     Agar isse { data:{...} } me lapet diya to `a.current` undefined hota hai
 *     aur timer pause() ho jata hai  ->  GAME FREEZE.  (v1 me yahi bug tha)
 *
 *   HISTORY JSON  -> upar `result:true` hona hi chahiye
 *     { result:true, data:{ list:[...], pageNo, totalPage, totalCount } }
 *     Kyunki useWinGo3-7wAfyD3a.js  `const {result,data} = await K(...)` karta hai.
 * ======================================================================
 */

declare(strict_types=1);

// ---------------------------------------------------------------- CORS ----
$__origin = (string) ($_SERVER['HTTP_ORIGIN'] ?? '');
$__host   = preg_replace('/:\d+$/', '', (string) ($_SERVER['HTTP_HOST'] ?? ''));
$__oHost  = $__origin !== '' ? (string) (parse_url($__origin, PHP_URL_HOST) ?: '') : '';
if ($__origin !== '' && $__host !== '' && strcasecmp($__oHost, $__host) === 0) {
    header('Access-Control-Allow-Origin: ' . $__origin);
    header('Vary: Origin');
    header('Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept, Authorization');
    header('Access-Control-Allow-Methods: GET, OPTIONS');
}
header('Cache-Control: no-store, no-cache, must-revalidate');

require_once dirname(__DIR__) . '/saas_lottery/bootstrap_live_v4.php';

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}

try {
    sl_install_schema();
} catch (Throwable $e) {
    error_log('[dmfirst draw schema] ' . $e->getMessage());
}

// ------------------------------------------------- request ko samjho ------
$lottery = preg_replace('/[^A-Za-z0-9_]/', '', (string) ($_GET['lottery'] ?? ''));
$game    = preg_replace('/[^A-Za-z0-9_]/', '', (string) ($_GET['gameCode'] ?? ''));
$history = isset($_GET['history']) && (string) $_GET['history'] === '1';

$uri  = (string) ($_SERVER['REQUEST_URI'] ?? '');
$path = (string) (parse_url($uri, PHP_URL_PATH) ?: $uri);

if (stripos($path, 'GetHistoryIssuePage') !== false) {
    $history = true;
}

if ($game === '' || $lottery === '') {
    // /draw-live-v4/WinGo/WinGo_30S.json
    // /draw-live-v4/WinGo/WinGo_30S/GetHistoryIssuePage.json
    $clean = preg_replace('#^.*?/draw-live-v4/#', '', $path);
    $clean = trim((string) $clean, '/');
    // root .htaccess se aa rahe ho to /draw-live-v4/ nahi hota
    if ($clean === '' || $clean === $path) {
        $clean = trim($path, '/');
    }
    $parts = array_values(array_filter(explode('/', $clean), 'strlen'));
    $found = array();
    foreach ($parts as $p) {
        $p = (string) preg_replace('/\.json$/i', '', $p);
        if ($p === '' || stripos($p, 'GetHistoryIssuePage') !== false || stripos($p, 'index') === 0) {
            continue;
        }
        $found[] = $p;
    }
    $n = count($found);
    if ($n >= 2) {
        if ($game === '') {
            $game = (string) $found[$n - 1];
        }
        if ($lottery === '') {
            $lottery = (string) $found[$n - 2];
        }
    } elseif ($n === 1 && $game === '') {
        $game = (string) $found[0];
    }
}

if ($game === '' || !isset($SL_CONFIG['games'][$game])) {
    sl_fail(7, 'Unsupported game code: ' . $game, 7, 200);
}

$lotteryCode = $lottery !== '' ? $lottery : (string) ($SL_CONFIG['games'][$game]['lottery'] ?? '');

// --------------------------------------------------------- HISTORY --------
if ($history) {
    $pageNo   = max(1, (int) ($_GET['pageNo'] ?? $_GET['page'] ?? 1));
    $pageSize = min(100, max(1, (int) ($_GET['pageSize'] ?? $_GET['size'] ?? 10)));

    $list     = array();
    $totalPage  = 50;
    $totalCount = 0;

    $payload = null;
    try {
        $payload = sl_provider_history($game, $pageNo, $pageSize);
    } catch (Throwable $e) {
        error_log('[dmfirst draw history] ' . $e->getMessage());
        $payload = null;
    }

    if (is_array($payload)) {
        $candidate = null;
        if (isset($payload['data']['list']) && is_array($payload['data']['list'])) {
            $candidate = $payload['data']['list'];
        } elseif (isset($payload['list']) && is_array($payload['list'])) {
            $candidate = $payload['list'];
        }
        if ($candidate !== null) {
            $list = $candidate;
            try {
                sl_save_and_settle_results($game, $list);
            } catch (Throwable $e) {
                error_log('[dmfirst draw settle] ' . $e->getMessage());
            }
            $totalPage  = (int) ($payload['data']['totalPage'] ?? $payload['totalPage'] ?? 50);
            $totalCount = (int) ($payload['data']['totalCount'] ?? $payload['totalCount'] ?? 0);
        }
    }

    if (!$list) {
        $local      = sl_local_history($game, $pageNo, $pageSize);
        $list       = $local['data']['list'];
        $totalPage  = (int) $local['data']['totalPage'];
        $totalCount = (int) $local['data']['totalCount'];
    }

    foreach ($list as $i => $item) {
        if (is_array($item) && !array_key_exists('colour', $item)) {
            $list[$i]['colour'] = (string) ($item['color'] ?? '');
        }
    }

    $body = array(
        'list'       => array_values($list),
        'pageNo'     => $pageNo,
        'totalPage'  => max(1, $totalPage),
        'totalCount' => $totalCount > 0 ? $totalCount : (max(1, $totalPage) * $pageSize),
    );
    if (sl_game_family($game) === 'MotoRace') {
        $body['statistics'] = sl_moto_statistics($list);
    }

    // RAW body  ->  { result:true, data:{ list, pageNo, totalPage, totalCount } }
    sl_send(array(
        'result'      => true,
        'data'        => $body,
        'code'        => 0,
        'msg'         => 'Succeed',
        'msgCode'     => 0,
        'serviceTime' => sl_now_ms(),
    ), 200);
}

// --------------------------------------------------------- CURRENT --------
$current = null;
try {
    $current = sl_provider_current($game);
} catch (Throwable $e) {
    error_log('[dmfirst draw current] ' . $e->getMessage());
    $current = null;
}
if (!is_array($current)) {
    $current = array();
}
if (!isset($current['current']) || !is_array($current['current'])) {
    $current = sl_apply_wingo_current_trend($game, sl_local_current($game));
}

// Flat shape guaranteed — BetRule/useWinGo3 seedha inhi key ko padhte hain.
$shape = function ($period) {
    if (!is_array($period)) {
        return null;
    }
    return array(
        'issueNumber' => (string) ($period['issueNumber'] ?? ''),
        'startTime'   => (int) ($period['startTime'] ?? 0),
        'endTime'     => (int) ($period['endTime'] ?? 0),
    );
};

$intervalMinute = (float) ($current['intervalMinute'] ?? 0);
if ($intervalMinute <= 0) {
    $intervalMinute = sl_interval_seconds($game) / 60;
}

$flat = array(
    'gameCode'       => $game,
    'lotteryCode'    => $lotteryCode,
    'intervalMinute' => $intervalMinute,
    'state'          => (int) ($current['state'] ?? (sl_game_enabled($game) ? 1 : 2)),
    'previous'       => $shape($current['previous'] ?? null),
    'current'        => $shape($current['current'] ?? null),
    'next'           => $shape($current['next'] ?? null),
);
if (isset($current['serverTime'])) {
    $flat['serverTime'] = $current['serverTime'];
}
if (isset($current['lotteryCode']) && $lotteryCode === '') {
    $flat['lotteryCode'] = (string) $current['lotteryCode'];
}

// RAW + FLAT (result/code sirf extra — koi nuksan nahi, debugger me kaam aate hain)
sl_send(array(
    'result'      => true,
    'gameCode'    => $flat['gameCode'],
    'lotteryCode' => $flat['lotteryCode'],
    'intervalMinute' => $flat['intervalMinute'],
    'state'       => $flat['state'],
    'previous'    => $flat['previous'],
    'current'     => $flat['current'],
    'next'        => $flat['next'],
    'code'        => 0,
    'msg'         => 'Succeed',
    'msgCode'     => 0,
    'serviceTime' => sl_now_ms(),
), 200);
