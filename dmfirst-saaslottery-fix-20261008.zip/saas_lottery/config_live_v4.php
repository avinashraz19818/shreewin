<?php
// ==========================================================================
//  DMFirst — WinGo FIX SETTINGS  (yahi ek jagah badlo)
// ==========================================================================

// PERIOD SHIFT — kitne period piche chalana hai
//   -1 = 1 period piche  (period AUR result dono 1 piche)   <-- ABHI YAHI HAI
//    0 = upstream jaisa exact
//   -2 = 2 period piche
if (!defined('SL_PERIOD_SHIFT'))      define('SL_PERIOD_SHIFT', -1);
// isko DB setting (app_settings.wingo_trend_mode) se override na hone dein
if (!defined('SL_FORCE_TREND_MODE'))  define('SL_FORCE_TREND_MODE', true);

// RESULT kaise piche jayega — ISI SE RESULT PICHHE JATA HAI
//   'delay'   = POORA game 1 period piche. Site ki history list upstream ki
//               history list se bilkul 1 row piche rahegi:
//                 site ka naya result == upstream ka EK PERIOD PURANA result
//               (yahi matlab hai "result bhi piche karo")      <-- ABHI YAHI HAI
//   'relabel' = maanwin AR_PERIOD_SHIFT jaisa. Sirf period ka LABEL badalta
//               hai, number wahi naya naya aata hai — yani result waqt ke
//               hisaab se piche NAHI jata.
//               (agar aapko yahi chahiye to 'delay' ki jagah 'relabel' likh do)
if (!defined('SL_RESULT_MODE'))       define('SL_RESULT_MODE', 'delay');

// TAX — My History / My Record ki "Tax" row
//   Ye BET AMOUNT ka % hai: 1000 par 2% = 20 rs.
//   Ye row sirf record me DIKHTI hai (wallet se alag nahi kata jata).
//   Jeetne par payout se bhi itna hi % asli me kata jata hai (net payout).
//   2.0 = 2%    (1000 par 20)   <-- shreewin jaisa, ABHI YAHI HAI
//   0   = tax band
if (!defined('SL_TAX_PERCENT'))       define('SL_TAX_PERCENT', 2.0);

// ORDER NUMBER — My History ki "Order No." row ka format
//   'auto' = game ke hisaab se prefix: WG (WinGo), TW (TrxWinGo), K3, 5D, MR
//   Example:  WG2026100504434175103202703489
//             WG | 20261005 (date) | 044341 (time) | 7510320 (user) | 2703489 (bet id)
//   Koi fixed prefix chahiye to yahan likh do, jaise 'AR'.
if (!defined('SL_ORDER_NO_PREFIX'))   define('SL_ORDER_NO_PREFIX', 'auto');

// Upstream (draw.ar-lottery01.com) response kitni der cache rahe (seconds).
// Frontend har second poll karta hai — bina cache ke upstream mar khayega.
if (!defined('SL_DRAW_CACHE_SECONDS')) define('SL_DRAW_CACHE_SECONDS', 3);

// Upstream down ho to local clock + deterministic result se game chalu rakhein
//   true  = game kabhi band nahi hoga (recommended)
//   false = upstream down -> game band (purana behaviour)
if (!defined('SL_DRAW_FALLBACK_LOCAL')) define('SL_DRAW_FALLBACK_LOCAL', true);

// ==========================================================================

return array(
    // Public draw data only. Never place a captured bearer token in this file.
    'draw_base_url' => 'https://draw.ar-lottery01.com',
    // AR014/lottery7 uses this public feed for WinGo, K3, 5D and the other
    // SaaS games. Keep it authoritative so periods and results cannot drift
    // to the local clock/random generator.
    'force_remote_draw' => true,
    'history_page_size' => 10,
    'history_total_pages' => 50,
    'request_timeout_seconds' => 5,
    'bet_lock_seconds' => 5,
    'maximum_stake' => 1000000,
    'games' => array(
        'WinGo_30S' => array('name' => 'WinGo 30sec', 'lottery' => 'WinGo', 'interval' => 0.5, 'sort' => 44),
        'WinGo_1M' => array('name' => 'WinGo 1 Min', 'lottery' => 'WinGo', 'interval' => 1, 'sort' => 43),
        'WinGo_3M' => array('name' => 'WinGo 3 Min', 'lottery' => 'WinGo', 'interval' => 3, 'sort' => 42),
        'WinGo_5M' => array('name' => 'WinGo 5 Min', 'lottery' => 'WinGo', 'interval' => 5, 'sort' => 41),

        'TrxWinGo_1M' => array('name' => 'TrxWinGo 1 Min', 'lottery' => 'TrxWinGo', 'interval' => 1, 'sort' => 14),
        'TrxWinGo_3M' => array('name' => 'TrxWinGo 3 Min', 'lottery' => 'TrxWinGo', 'interval' => 3, 'sort' => 13),
        'TrxWinGo_5M' => array('name' => 'TrxWinGo 5 Min', 'lottery' => 'TrxWinGo', 'interval' => 5, 'sort' => 12),
        'TrxWinGo_10M' => array('name' => 'TrxWinGo 10 Min', 'lottery' => 'TrxWinGo', 'interval' => 10, 'sort' => 11),

        'K3_1M' => array('name' => 'K3 1 Min', 'lottery' => 'K3', 'interval' => 1, 'sort' => 34),
        'K3_3M' => array('name' => 'K3 3 Min', 'lottery' => 'K3', 'interval' => 3, 'sort' => 33),
        'K3_5M' => array('name' => 'K3 5 Min', 'lottery' => 'K3', 'interval' => 5, 'sort' => 32),
        'K3_10M' => array('name' => 'K3 10 Min', 'lottery' => 'K3', 'interval' => 10, 'sort' => 31),

        'D5_1M' => array('name' => '5D 1 Min', 'lottery' => 'D5', 'interval' => 1, 'sort' => 24),
        'D5_3M' => array('name' => '5D 3 Min', 'lottery' => 'D5', 'interval' => 3, 'sort' => 23),
        'D5_5M' => array('name' => '5D 5 Min', 'lottery' => 'D5', 'interval' => 5, 'sort' => 22),
        'D5_10M' => array('name' => '5D 10 Min', 'lottery' => 'D5', 'interval' => 10, 'sort' => 21),

        'MotoRace_1M' => array('name' => 'Moto Racing', 'lottery' => 'MotoRace', 'interval' => 1, 'sort' => 0)
    )
);
