<?php
/**
 * DMFirst — Lottery API entry point.
 *
 * Root .htaccess sends  /Lottery/{Action}  and  /api/Lottery/{Action}
 * here as  index.php?action={Action}.
 *
 * Ye file pehle maujood hi nahi thi — isi wajah se WinGo/K3/5D/MotoRace
 * ke saare API call 404/405 ho rahe the aur game bilkul band tha.
 *
 * Sari game logic saas_lottery/bootstrap_live_v4.php me pehle se hai,
 * yahan sirf HTTP layer hai.
 */

declare(strict_types=1);

// ---------------------------------------------------------------- CORS ----
$__origin = (string) ($_SERVER['HTTP_ORIGIN'] ?? '');
$__host   = preg_replace('/:\d+$/', '', (string) ($_SERVER['HTTP_HOST'] ?? ''));
$__oHost  = $__origin !== '' ? (string) (parse_url($__origin, PHP_URL_HOST) ?: '') : '';
if ($__origin !== '' && $__host !== '' && strcasecmp($__oHost, $__host) === 0) {
    header('Access-Control-Allow-Origin: ' . $__origin);
    header('Vary: Origin');
    header('Access-Control-Allow-Credentials: true');
    header('Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept, Authorization');
    header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
}

// ------------------------------------------------------------- ENGINE -----
require_once dirname(__DIR__, 2) . '/saas_lottery/bootstrap_live_v4.php';

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}

try {
    sl_install_schema();
} catch (Throwable $e) {
    error_log('[dmfirst lottery schema] ' . $e->getMessage());
}

$action = preg_replace('/[^A-Za-z0-9_]/', '', (string) ($_GET['action'] ?? ''));
$input  = sl_input();

// Har action ke liye default game code (agar client gameCode na bheje)
$defaultGames = array(
    'WinGoBet' => 'WinGo_30S', 'VideoWinGoBet' => 'WinGo_30S',
    'TrxWinGoBet' => 'TrxWinGo_1M', 'K3Bet' => 'K3_1M',
    'D5Bet' => 'D5_1M', 'MotoRaceBet' => 'MotoRace_1M',
);
if (isset($defaultGames[$action]) && (!isset($input['gameCode']) || (string) $input['gameCode'] === '')) {
    $input['gameCode'] = $defaultGames[$action];
}

// ------------------------------------------------------- PUBLIC ACTIONS ---
switch ($action) {

    case 'GetGameList':
        sl_ok(sl_game_list());

    case 'GetGameInfo':
        sl_ok(sl_game_info(sl_game_code($input)));

    case 'GetBetLimit':
        sl_ok(sl_bet_limits(sl_game_code($input)));

    case 'GetGameIntroduce':
        sl_ok(sl_game_introduce(sl_game_code($input)));

    case 'GetGameIssue':
    case 'GetIssue':
    case 'GetCurrentIssue':
        $gc = sl_game_code($input);
        $cur = sl_provider_current($gc);
        if (!$cur) {
            $cur = sl_apply_wingo_current_trend($gc, sl_local_current($gc));
        }
        sl_ok($cur);

    case 'GetHistoryIssuePage':
    case 'GetLotteryResultHistory':
    case 'GetmyIssusPage':
        sl_ok(sl_history_page(sl_game_code($input), $input));

    case 'GetTrendStatistics':
        sl_ok(sl_trend(sl_game_code($input)));

    case 'GetDragonList':
        sl_ok(array());

    case 'GetFollowRule':
    case 'GetFollowPlanList':
        sl_ok(array('list' => array(), 'pageNo' => 1, 'totalPage' => 0, 'totalCount' => 0));

    case 'GetFollowRecord':
    case 'GetHistoryFollowRecordPageList':
        sl_ok(array('list' => array(), 'pageNo' => 1, 'totalPage' => 0, 'totalCount' => 0));

    case 'SaasChangLong':
        sl_ok(array('list' => array()));
}

// --------------------------------------------------- AUTHENTICATED --------
$user = sl_require_user();

switch ($action) {

    // ---------------------------------------------------------- balance ---
    case 'GetBalance':
        sl_ok(array('balance' => sl_wallet_balance((int) $user['id'])));

    case 'GetUserInfo':
        $uid = (int) $user['id'];
        global $conn;
        $row = array('userPhoto' => '1', 'createdate' => '', 'shonullgnt' => '');
        $st = $conn->prepare('SELECT COALESCE(user_photo,\'1\') user_photo, COALESCE(createdate,\'\') createdate, COALESCE(shonullgnt,\'\') shonullgnt FROM shonu_subjects WHERE id=? LIMIT 1');
        if ($st) {
            $st->bind_param('i', $uid);
            $st->execute();
            $r = $st->get_result();
            if ($r && ($tmp = $r->fetch_assoc())) {
                $row = $tmp;
            }
            $st->close();
        }
        sl_ok(array(
            'userId'    => $uid,
            'userName'  => (string) $user['mobile'],
            'nickName'  => (string) $user['codechorkamukala'],
            'userPhoto' => (string) $row['userPhoto'],
            'amount'    => sl_wallet_balance($uid),
            'balance'   => sl_wallet_balance($uid),
            'addTime'   => (string) $row['createdate'],
            'userLoginDate' => (string) $row['shonullgnt'],
            'uRate'     => 127.0,
            'trxRate'   => 13.7,
            'fee'       => 0.0,
            'unRead'    => 0,
            'isAllowWithdraw' => 1,
            'regType'   => 1,
            'verifyMethods' => array('mobile' => (string) $user['mobile'], 'email' => '', 'google' => '0'),
        ));

    // ---------------------------------------------------------- record ----
    case 'GetRecordPage':
    case 'GetMyGameRecordPageList':
    case 'GetMyGameRecord':
        sl_ok(sl_record_page((int) $user['id'], $input));

    case 'GetWinLossResult':
        sl_ok(sl_win_loss((int) $user['id'], $input));

    // ------------------------------------------------------------ bets ----
    case 'WinGoBet':
    case 'VideoWinGoBet':
    case 'TrxWinGoBet':
    case 'K3Bet':
    case 'D5Bet':
    case 'MotoRaceBet':
    case 'GameBetting':
        sl_ok(sl_place_bet($user, $input));

    // ---------------------------------------------------------- follow ----
    case 'AddFollowRecord':
    case 'StopFollowRecord':
        sl_ok(array('success' => true));
}

sl_fail(11, 'Url is not exist', 5, 404);
