<?php
/**
 * DMFirst — self check page.
 *
 * Upload ke baad browser me kholo:
 *   https://dmfirst.club9.eu.cc/dmcheck.php
 *
 * Ye har cheez ko GREEN / RED me dikhata hai. Koi bhi RED aaye to
 * uske neeche likha solution padho.
 */

declare(strict_types=1);
header('Content-Type: text/html; charset=utf-8');

$rows  = array();
$ok    = function ($t, $d = '') use (&$rows) { $rows[] = array(true,  $t, $d); };
$bad   = function ($t, $d = '') use (&$rows) { $rows[] = array(false, $t, $d); };
$info  = function ($t, $d = '') use (&$rows) { $rows[] = array(null,  $t, $d); };

// ------------------------------------------------------------------ fetch --
$fetch = function (string $url) {
    $ctx = stream_context_create(array(
        'http' => array('timeout' => 8, 'ignore_errors' => true, 'header' => "Accept: application/json\r\n"),
        'ssl'  => array('verify_peer' => false, 'verify_peer_name' => false),
    ));
    $body = @file_get_contents($url, false, $ctx);
    $code = 0;
    if (isset($http_response_header[0]) && preg_match('/\s(\d{3})\s/', $http_response_header[0], $m)) {
        $code = (int) $m[1];
    }
    return array($code, $body === false ? '' : (string) $body);
};

$scheme = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
$host   = (string) ($_SERVER['HTTP_HOST'] ?? '');
$base   = $scheme . '://' . $host;

$info('Host', htmlspecialchars($base));
$info('PHP', PHP_VERSION);

// --------------------------------------------------------------- 1. files --
$need = array(
    'api-live-v4/Lottery/index.php',
    'draw-live-v4/index.php',
    'draw-live-v4/.htaccess',
    'saas_lottery/bootstrap_live_v4.php',
    'saas_lottery/config_live_v4.php',
    'saas_lottery/admin_override.php',
    'devmaruf/api/webapi/GetHomeSettings.php',
    'devmaruf/api/webapi/GetAllGameList.php',
    'devmaruf/api/webapi/GetLotteryCategoryList.php',
);
foreach ($need as $f) {
    if (is_file(__DIR__ . '/' . $f)) {
        $ok('File: ' . $f);
    } else {
        $bad('File: ' . $f . '  MISSING', 'Zip dobara extract karo — ye file zip me hai.');
    }
}

// ------------------------------------------------------------- 2. home ----
list($c, $b) = $fetch($base . '/devmaruf/api/webapi/GetHomeSettings.php');
$j = json_decode($b, true);
if (is_array($j) && isset($j['data']['isOpenArLottery'])) {
    $v = $j['data']['isOpenArLottery'];
    if ($v === true || $v === 1 || $v === '1' || $v === 'true') {
        $ok('GetHomeSettings: isOpenArLottery = TRUE', 'Lottery ab #/saasLottery/... par khulegi.');
    } else {
        $bad('GetHomeSettings: isOpenArLottery = FALSE', 'Purani file lag rahi hai. Zip dobara upload karo + Purge All.');
    }
} else {
    $bad('GetHomeSettings: read nahi hua (HTTP ' . $c . ')', substr(htmlspecialchars($b), 0, 200));
}

// --------------------------------------------------- 3. all game list -----
list($c, $b) = $fetch($base . '/devmaruf/api/webapi/GetAllGameList.php');
$j = json_decode($b, true);
$lot = (is_array($j) && isset($j['data']['lottery']) && is_array($j['data']['lottery'])) ? $j['data']['lottery'] : null;
if ($lot === null) {
    $bad('GetAllGameList: lottery list nahi mili (HTTP ' . $c . ')', substr(htmlspecialchars($b), 0, 200));
} else {
    $missing = array();
    foreach ($lot as $it) {
        if (empty($it['gameCode'])) {
            $missing[] = (string) ($it['categoryCode'] ?? $it['id']);
        }
    }
    if (!$missing) {
        $ok('GetAllGameList: har lottery item me gameCode hai',
            'Ye hi #/saasLottery/<name>?gameCode=... banata hai.');
    } else {
        $bad('GetAllGameList: gameCode missing in: ' . implode(', ', $missing),
            'Purani file chal rahi hai — dobara upload + Purge All.');
    }
}

// --------------------------------------------------------- 4. draw feed ---
$curUrl = $base . '/draw-live-v4/WinGo/WinGo_30S.json';
list($c, $b) = $fetch($curUrl);
$info('GET ' . $curUrl, 'HTTP ' . $c);
$j = json_decode($b, true);
if (!is_array($j)) {
    $bad('Current JSON: JSON nahi mila', substr(htmlspecialchars($b), 0, 300));
} elseif (!isset($j['current']['issueNumber'])) {
    $bad('Current JSON: "current" flat me nahi mila',
        'draw-live-v4/index.php purani hai. Abhi mila: ' . htmlspecialchars(substr($b, 0, 200)));
} else {
    $ok('Current JSON: FLAT shape sahi hai', 'gameCode=' . htmlspecialchars((string) ($j['gameCode'] ?? ''))
        . ' intervalMinute=' . htmlspecialchars((string) ($j['intervalMinute'] ?? ''))
        . ' issue=' . htmlspecialchars((string) $j['current']['issueNumber']));
    if (!isset($j['current']['endTime'])) {
        $bad('Current JSON: current.endTime missing');
    } else {
        $ok('Current JSON: current.endTime = ' . htmlspecialchars((string) $j['current']['endTime']));
    }
    if (!isset($j['next']['issueNumber'])) {
        $bad('Current JSON: next missing');
    } else {
        $ok('Current JSON: next.issue = ' . htmlspecialchars((string) $j['next']['issueNumber']));
    }
}

$hisUrl = $base . '/draw-live-v4/WinGo/WinGo_30S/GetHistoryIssuePage.json?pageNo=1&pageSize=10';
list($c, $b) = $fetch($hisUrl);
$info('GET ' . $hisUrl, 'HTTP ' . $c);
$j = json_decode($b, true);
if (!is_array($j)) {
    $bad('History JSON: JSON nahi mila', substr(htmlspecialchars($b), 0, 300));
} elseif (!($j['result'] ?? false)) {
    $bad('History JSON: top-level "result":true nahi mila',
        'Isi wajah se game freeze hota tha. Milа: ' . htmlspecialchars(substr($b, 0, 200)));
} elseif (!isset($j['data']['list'])) {
    $bad('History JSON: data.list nahi mila', htmlspecialchars(substr($b, 0, 200)));
} else {
    $ok('History JSON: result:true + data.list OK', count($j['data']['list']) . ' rows, totalPage='
        . htmlspecialchars((string) ($j['data']['totalPage'] ?? '?')));
}

// ---------------------------------------------------------- 5. Lottery API -
$lotUrl = $base . '/Lottery/GetGameList';
list($c, $b) = $fetch($lotUrl);
$info('GET ' . $lotUrl, 'HTTP ' . $c);
$j = json_decode($b, true);
if (!is_array($j) || !($j['result'] ?? false)) {
    $bad('/Lottery/GetGameList: "result":true nahi mila (HTTP ' . $c . ')',
        'Root .htaccess /Lottery/* ko api-live-v4/Lottery/index.php par bhej raha hai ya nahi — check karo. Body: '
        . htmlspecialchars(substr($b, 0, 200)));
} else {
    $ok('/Lottery/GetGameList: result:true OK', count((array) ($j['data'] ?? array())) . ' games');
}

$blUrl = $base . '/Lottery/GetBetLimit?gameCode=WinGo_30S';
list($c, $b) = $fetch($blUrl);
$j = json_decode($b, true);
if (!is_array($j) || !($j['result'] ?? false)) {
    $bad('/Lottery/GetBetLimit: result:true nahi mila (HTTP ' . $c . ')', htmlspecialchars(substr($b, 0, 200)));
} else {
    $ok('/Lottery/GetBetLimit: result:true OK', count((array) ($j['data'] ?? array())) . ' limits');
}

// ------------------------------------------------------------- 6. engine --
try {
    require_once __DIR__ . '/saas_lottery/bootstrap_live_v4.php';
    $ok('Engine load: saas_lottery/bootstrap_live_v4.php');
    global $conn, $SL_CONFIG;
    if ($conn instanceof mysqli && !$conn->connect_errno) {
        $ok('DB connect: OK');
    } else {
        $bad('DB connect: FAIL', 'saas_lottery/config_live_v4.php me DB credentials check karo.');
    }
    $ok('Games in config: ' . count($SL_CONFIG['games']), implode(', ', array_slice(array_keys($SL_CONFIG['games']), 0, 6)) . ' ...');
    $ok('SL_PERIOD_SHIFT', (string) SL_PERIOD_SHIFT . '  (1 period piche)');
} catch (Throwable $e) {
    $bad('Engine load FAIL', htmlspecialchars($e->getMessage()));
}

// ---------------------------------------------------------------- render --
echo '<!doctype html><meta charset="utf-8"><title>DMFirst self check</title>';
echo '<body style="font:14px/1.5 system-ui;background:#0e1116;color:#e6e6e6;margin:0;padding:24px">';
echo '<h2 style="margin:0 0 4px">DMFirst — self check</h2>';
echo '<div style="opacity:.7;margin-bottom:18px">' . htmlspecialchars($base) . '</div>';
$fail = 0;
foreach ($rows as $r) {
    list($st, $t, $d) = $r;
    $color = $st === true ? '#1a7f37' : ($st === false ? '#b62324' : '#3b82f6');
    $label = $st === true ? 'OK  ' : ($st === false ? 'FAIL' : 'INFO');
    if ($st === false) {
        $fail++;
    }
    echo '<div style="border-left:4px solid ' . $color . ';background:#161b22;padding:8px 12px;margin:6px 0;border-radius:4px">';
    echo '<b style="color:' . $color . '">' . $label . '</b> &nbsp;' . htmlspecialchars($t);
    if ($d !== '') {
        echo '<div style="opacity:.75;font-size:12px;margin-top:3px">' . $d . '</div>';
    }
    echo '</div>';
}
echo '<h3 style="margin-top:20px;color:' . ($fail ? '#b62324' : '#1a7f37') . '">'
    . ($fail ? ($fail . ' problem(s) — upar FAIL wali lines padho')
             : 'Sab kuch GREEN hai. Ab app me jaakar WinGo kholo — URL me #/saasLottery/WinGo?gameCode=WinGo_30S aana chahiye.')
    . '</h3>';
echo '<p style="opacity:.7">Note: browser Purge All / Cache Clear + app Clear Data zaroor karo, warna purana JS chalega.</p>';
echo '</body>';
