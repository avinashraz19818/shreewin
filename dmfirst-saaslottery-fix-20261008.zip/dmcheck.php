<?php
/**
 * DMFirst — self check page.
 *
 * Upload ke baad browser me kholo:
 *   https://dmfirst.club9.eu.cc/dmcheck.php
 *
 * Ye har cheez ko GREEN / RED me dikhata hai. Koi bhi RED aaye to
 * uske neeche likha solution padho.
 */

declare(strict_types=1);
header('Content-Type: text/html; charset=utf-8');

$rows  = array();
$ok    = function ($t, $d = '') use (&$rows) { $rows[] = array(true,  $t, $d); };
$bad   = function ($t, $d = '') use (&$rows) { $rows[] = array(false, $t, $d); };
$info  = function ($t, $d = '') use (&$rows) { $rows[] = array(null,  $t, $d); };

// ------------------------------------------------------------------ fetch --
$fetch = function (string $url) {
    $ctx = stream_context_create(array(
        'http' => array('timeout' => 8, 'ignore_errors' => true, 'header' => "Accept: application/json\r\n"),
        'ssl'  => array('verify_peer' => false, 'verify_peer_name' => false),
    ));
    $body = @file_get_contents($url, false, $ctx);
    $code = 0;
    if (isset($http_response_header[0]) && preg_match('/\s(\d{3})\s/', $http_response_header[0], $m)) {
        $code = (int) $m[1];
    }
    return array($code, $body === false ? '' : (string) $body);
};

// Upstream (draw.ar-lottery01.com) bina Referer ke 403 deta hai, isliye alag
// fetch helper — sirf comparison table ke liye.
$fetchUp = function (string $url) {
    $ctx = stream_context_create(array(
        'http' => array(
            'timeout' => 8,
            'ignore_errors' => true,
            'header' => "Accept: application/json, text/plain, */*\r\n"
                . "Referer: https://www.lottery7uuu.com/\r\n"
                . "Origin: https://www.lottery7uuu.com\r\n"
                . "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36\r\n",
        ),
        'ssl' => array('verify_peer' => false, 'verify_peer_name' => false),
    ));
    $body = @file_get_contents($url, false, $ctx);
    $code = 0;
    if (isset($http_response_header[0]) && preg_match('/\s(\d{3})\s/', $http_response_header[0], $m)) {
        $code = (int) $m[1];
    }
    return array($code, $body === false ? '' : (string) $body);
};

$scheme = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
$host   = (string) ($_SERVER['HTTP_HOST'] ?? '');
$base   = $scheme . '://' . $host;

$info('Host', htmlspecialchars($base));
$info('PHP', PHP_VERSION);

// --------------------------------------------------------------- 1. files --
$need = array(
    'api-live-v4/Lottery/index.php',
    'draw-live-v4/index.php',
    'draw-live-v4/.htaccess',
    'saas_lottery/bootstrap_live_v4.php',
    'saas_lottery/config_live_v4.php',
    'saas_lottery/admin_override.php',
    'devmaruf/api/webapi/GetHomeSettings.php',
    'devmaruf/api/webapi/GetAllGameList.php',
    'devmaruf/api/webapi/GetLotteryCategoryList.php',
);
foreach ($need as $f) {
    if (is_file(__DIR__ . '/' . $f)) {
        $ok('File: ' . $f);
    } else {
        $bad('File: ' . $f . '  MISSING', 'Zip dobara extract karo — ye file zip me hai.');
    }
}

// ------------------------------------------------------------- 2. home ----
list($c, $b) = $fetch($base . '/devmaruf/api/webapi/GetHomeSettings.php');
$j = json_decode($b, true);
if (is_array($j) && isset($j['data']['isOpenArLottery'])) {
    $v = $j['data']['isOpenArLottery'];
    if ($v === true || $v === 1 || $v === '1' || $v === 'true') {
        $ok('GetHomeSettings: isOpenArLottery = TRUE', 'Lottery ab #/saasLottery/... par khulegi.');
    } else {
        $bad('GetHomeSettings: isOpenArLottery = FALSE', 'Purani file lag rahi hai. Zip dobara upload karo + Purge All.');
    }
} else {
    $bad('GetHomeSettings: read nahi hua (HTTP ' . $c . ')', substr(htmlspecialchars($b), 0, 200));
}

// --------------------------------------------------- 3. all game list -----
list($c, $b) = $fetch($base . '/devmaruf/api/webapi/GetAllGameList.php');
$j = json_decode($b, true);
$lot = (is_array($j) && isset($j['data']['lottery']) && is_array($j['data']['lottery'])) ? $j['data']['lottery'] : null;
if ($lot === null) {
    $bad('GetAllGameList: lottery list nahi mili (HTTP ' . $c . ')', substr(htmlspecialchars($b), 0, 200));
} else {
    $missing = array();
    foreach ($lot as $it) {
        if (empty($it['gameCode'])) {
            $missing[] = (string) ($it['categoryCode'] ?? $it['id']);
        }
    }
    if (!$missing) {
        $ok('GetAllGameList: har lottery item me gameCode hai',
            'Ye hi #/saasLottery/<name>?gameCode=... banata hai.');
    } else {
        $bad('GetAllGameList: gameCode missing in: ' . implode(', ', $missing),
            'Purani file chal rahi hai — dobara upload + Purge All.');
    }
}

// --------------------------------------------------------- 4. draw feed ---
$curUrl = $base . '/draw-live-v4/WinGo/WinGo_30S.json';
list($c, $b) = $fetch($curUrl);
$info('GET ' . $curUrl, 'HTTP ' . $c);
$j = json_decode($b, true);
if (!is_array($j)) {
    $bad('Current JSON: JSON nahi mila', substr(htmlspecialchars($b), 0, 300));
} elseif (!isset($j['current']['issueNumber'])) {
    $bad('Current JSON: "current" flat me nahi mila',
        'draw-live-v4/index.php purani hai. Abhi mila: ' . htmlspecialchars(substr($b, 0, 200)));
} else {
    $ok('Current JSON: FLAT shape sahi hai', 'gameCode=' . htmlspecialchars((string) ($j['gameCode'] ?? ''))
        . ' intervalMinute=' . htmlspecialchars((string) ($j['intervalMinute'] ?? ''))
        . ' issue=' . htmlspecialchars((string) $j['current']['issueNumber']));
    if (!isset($j['current']['endTime'])) {
        $bad('Current JSON: current.endTime missing');
    } else {
        $ok('Current JSON: current.endTime = ' . htmlspecialchars((string) $j['current']['endTime']));
    }
    if (!isset($j['next']['issueNumber'])) {
        $bad('Current JSON: next missing');
    } else {
        $ok('Current JSON: next.issue = ' . htmlspecialchars((string) $j['next']['issueNumber']));
    }
}

$hisUrl = $base . '/draw-live-v4/WinGo/WinGo_30S/GetHistoryIssuePage.json?pageNo=1&pageSize=10';
list($c, $b) = $fetch($hisUrl);
$info('GET ' . $hisUrl, 'HTTP ' . $c);
$j = json_decode($b, true);
if (!is_array($j)) {
    $bad('History JSON: JSON nahi mila', substr(htmlspecialchars($b), 0, 300));
} elseif (!($j['result'] ?? false)) {
    $bad('History JSON: top-level "result":true nahi mila',
        'Isi wajah se game freeze hota tha. Milа: ' . htmlspecialchars(substr($b, 0, 200)));
} elseif (!isset($j['data']['list'])) {
    $bad('History JSON: data.list nahi mila', htmlspecialchars(substr($b, 0, 200)));
} else {
    $ok('History JSON: result:true + data.list OK', count($j['data']['list']) . ' rows, totalPage='
        . htmlspecialchars((string) ($j['data']['totalPage'] ?? '?')));
}

// ---------------------------------------- 4b. 1-PERIOD PICHE (site table) --
$shiftRows = array();
try {
    list($cA, $bA) = $fetch($base . '/draw-live-v4/WinGo/WinGo_30S.json');
    $jA = json_decode($bA, true);
    list($cB, $bB) = $fetch($base . '/draw-live-v4/WinGo/WinGo_30S/GetHistoryIssuePage.json?pageNo=1&pageSize=5');
    $jB = json_decode($bB, true);
    $curIssue = is_array($jA) ? (string) ($jA['current']['issueNumber'] ?? '') : '';
    $histRows = (is_array($jB) && isset($jB['data']['list'])) ? $jB['data']['list'] : array();
    if ($curIssue !== '' && $histRows) {
        $shiftRows[] = array($curIssue, '(chal raha hai — OPEN)', 1);
        foreach (array_slice($histRows, 0, 4) as $r) {
            $shiftRows[] = array(
                (string) ($r['issueNumber'] ?? '?'),
                'number=' . (string) ($r['number'] ?? $r['premium'] ?? '?'),
                0
            );
        }
        $ok('1-PERIOD PICHE: table neeche hai',
            'Sabse naya result wahi hai jo upstream ne EK PERIOD PEHLE nikala tha '
            . '=> period BHI piche, result BHI piche.');
    } else {
        $bad('1-PERIOD PICHE: current ya history nahi mili', 'draw-live-v4 check karo.');
    }
} catch (Throwable $e) {
    $bad('1-PERIOD PICHE: check fail', htmlspecialchars($e->getMessage()));
}

// ------------------------------- 4c. UPSTREAM vs SITE — ASLI PROOF (v5) -----
$upBase   = 'https://draw.ar-lottery01.com';
$cmp      = array('up' => array(), 'site' => array(), 'upCur' => '', 'siteCur' => '', 'ready' => false);
$cmpNote  = '';
try {
    list($c1, $b1) = $fetchUp($upBase . '/WinGo/WinGo_30S.json');
    list($c2, $b2) = $fetch($base  . '/draw-live-v4/WinGo/WinGo_30S.json');
    list($c3, $b3) = $fetchUp($upBase . '/WinGo/WinGo_30S/GetHistoryIssuePage.json?pageNo=1&pageSize=6');
    list($c4, $b4) = $fetch($base  . '/draw-live-v4/WinGo/WinGo_30S/GetHistoryIssuePage.json?pageNo=1&pageSize=6');
    $ju  = json_decode($b1, true);
    $js  = json_decode($b2, true);
    $jhu = json_decode($b3, true);
    $jhs = json_decode($b4, true);
    $cmp['upCur']   = is_array($ju) ? (string) ($ju['current']['issueNumber'] ?? '') : '';
    $cmp['siteCur'] = is_array($js) ? (string) ($js['current']['issueNumber'] ?? '') : '';
    $ul = array();
    if (is_array($jhu)) {
        $ul = isset($jhu['data']['list']) ? $jhu['data']['list'] : (isset($jhu['list']) ? $jhu['list'] : array());
    }
    $sl = (is_array($jhs) && isset($jhs['data']['list'])) ? $jhs['data']['list'] : array();
    foreach (array_slice($ul, 0, 3) as $r) {
        $cmp['up'][] = array((string) ($r['issueNumber'] ?? '?'), (string) ($r['number'] ?? $r['premium'] ?? '?'));
    }
    foreach (array_slice($sl, 0, 3) as $r) {
        $cmp['site'][] = array((string) ($r['issueNumber'] ?? '?'), (string) ($r['number'] ?? $r['premium'] ?? '?'));
    }
    $info('UPSTREAM raw: /WinGo/WinGo_30S.json', 'HTTP ' . $c1);
    $info('UPSTREAM raw: GetHistoryIssuePage', 'HTTP ' . $c3);
    if ($cmp['upCur'] === '' || !$cmp['up']) {
        $bad('UPSTREAM compare: upstream se data nahi mila (HTTP ' . $c1 . '/' . $c3 . ')',
            'Ye server se block ho sakta hai. Tab neeche wali SITE table + upar wali table se hi confirm karo.');
    } else {
        $cmp['ready'] = true;
        if ($cmp['siteCur'] !== '' && $cmp['siteCur'] === $cmp['upCur']) {
            $bad('PERIOD piche NAHI hai', 'Site current (' . $cmp['siteCur'] . ') upstream current ('
                . $cmp['upCur'] . ') ke barabar hai.');
        } elseif ($cmp['siteCur'] !== '') {
            $ok('PERIOD 1 PICHE hai', 'upstream open = ' . $cmp['upCur'] . '  |  site open = ' . $cmp['siteCur']);
        }
        $s0 = isset($cmp['site'][0]) ? $cmp['site'][0] : null;
        $u1 = isset($cmp['up'][1]) ? $cmp['up'][1] : null;
        if ($s0 && $u1 && $s0[0] === $u1[0] && $s0[1] === $u1[1]) {
            $ok('RESULT BHI 1 PERIOD PICHE HAI', 'Site ka sabse naya result (' . $s0[0] . ' -> ' . $s0[1]
                . ') bilkul wahi hai jo upstream ne EK PERIOD PEHLE nikala tha (' . $u1[0] . ' -> ' . $u1[1] . ').');
            $cmpNote = 'Bilkul sahi: site ki history upstream ki history se poori tarah 1 period piche hai.';
        } elseif ($s0 && $cmp['up'] && $s0[0] === $cmp['up'][0][0] && $s0[1] === $cmp['up'][0][1]) {
            $bad('Result piche NAHI hai (v4 jaisa purana behaviour)',
                'Site ka sabse naya result (' . $s0[0] . ' -> ' . $s0[1] . ') upstream ke SABSE NAYE result ('
                . $cmp['up'][0][0] . ' -> ' . $cmp['up'][0][1] . ') jaisa hai — matlab result waqt ke hisaab se piche nahi gaya.');
            $cmpNote = 'Galat: result abhi bhi upstream ke naye result ke sath hi aa raha hai.';
        } else {
            $bad('Result compare nahi ho paya',
                'site[0]=' . json_encode($s0) . '  upstream[0..1]=' . json_encode(array_slice($cmp['up'], 0, 2)));
            $cmpNote = 'Draw abhi roll ho raha hoga — page dobara refresh karo.';
        }
    }
} catch (Throwable $e) {
    $bad('UPSTREAM compare fail', htmlspecialchars($e->getMessage()));
}

// ---------------------------------------------------------- 5. Lottery API -
$lotUrl = $base . '/Lottery/GetGameList';
list($c, $b) = $fetch($lotUrl);
$info('GET ' . $lotUrl, 'HTTP ' . $c);
$j = json_decode($b, true);
if (!is_array($j) || !($j['result'] ?? false)) {
    $bad('/Lottery/GetGameList: "result":true nahi mila (HTTP ' . $c . ')',
        'Root .htaccess /Lottery/* ko api-live-v4/Lottery/index.php par bhej raha hai ya nahi — check karo. Body: '
        . htmlspecialchars(substr($b, 0, 200)));
} else {
    $ok('/Lottery/GetGameList: result:true OK', count((array) ($j['data'] ?? array())) . ' games');
}

$blUrl = $base . '/Lottery/GetBetLimit?gameCode=WinGo_30S';
list($c, $b) = $fetch($blUrl);
$j = json_decode($b, true);
if (!is_array($j) || !($j['result'] ?? false)) {
    $bad('/Lottery/GetBetLimit: result:true nahi mila (HTTP ' . $c . ')', htmlspecialchars(substr($b, 0, 200)));
} else {
    $ok('/Lottery/GetBetLimit: result:true OK', count((array) ($j['data'] ?? array())) . ' limits');
}

// ------------------------------------------------------- 6. route forcer --
list($c, $b) = $fetch($base . '/web/config?_key=ar103');
$info('GET /web/config?_key=ar103', 'HTTP ' . $c);
if ($c !== 200 || trim($b) === '') {
    $bad('web/config.php: load nahi hua (HTTP ' . $c . ')',
        'Ye file zip me hai — root ke web/ folder me honi chahiye. Isi file se URL AllLotteryGames -> saasLottery badalta hai.');
} elseif (strpos($b, 'AllLotteryGames-') === false) {
    $bad('web/config.php: purani copy chal rahi hai (route forcer nahi mila)',
        'Zip dobara upload karo: web/config.php.');
} else {
    $ok('web/config.php: ROUTE FORCER active',
        'Ab #/AllLotteryGames-* turant #/saasLottery/* me badal jayega — chahe JS cache purana ho.');
    if (strpos($b, '__mintArToken') === false) {
        $bad('web/config.php: AR TOKEN minting missing (purani copy)', 'Dobara upload karo: web/config.php');
    } else {
        $ok('web/config.php: AR token minting active',
            'GetGameUrl se ar_token set hota hai — warna /Lottery/* 401 deta.');
    }
}

// -------------------------------------------- 6b. freshness (debug) -----
list($c, $b) = $fetch($base . '/devmaruf/api/webapi/GetAllGameList.php?cache=1');
$j = json_decode($b, true);
if (is_array($j) && isset($j['data']['lottery'][0])) {
    $ok('RAW lottery[0] (jo browser ko mil raha hai)',
        htmlspecialchars(substr(json_encode($j['data']['lottery'][0]), 0, 300)));
}
list($c2, $b2) = $fetch($base . '/web/config?_key=ar103');
$info('/web/config?_key=ar103 (pehli 160 char)',
    'HTTP ' . $c2 . ' — ' . htmlspecialchars(substr(preg_replace('/\s+/', ' ', (string) $b2), 0, 160)));

// ------------------------------------------------------------- 7. engine --
try {
    require_once __DIR__ . '/saas_lottery/bootstrap_live_v4.php';
    $ok('Engine load: saas_lottery/bootstrap_live_v4.php');
    global $conn, $SL_CONFIG;
    if ($conn instanceof mysqli && !$conn->connect_errno) {
        $ok('DB connect: OK');
    } else {
        $bad('DB connect: FAIL', 'saas_lottery/config_live_v4.php me DB credentials check karo.');
    }
    $ok('Games in config: ' . count($SL_CONFIG['games']), implode(', ', array_slice(array_keys($SL_CONFIG['games']), 0, 6)) . ' ...');
    $ok('SL_PERIOD_SHIFT', (string) SL_PERIOD_SHIFT . '  (1 period piche)');
} catch (Throwable $e) {
    $bad('Engine load FAIL', htmlspecialchars($e->getMessage()));
}

// --------------------------------------------------- 8. TAX (My History) --
try {
    $pct = function_exists('sl_tax_percent') ? sl_tax_percent() : (defined('SL_TAX_PERCENT') ? (float) SL_TAX_PERCENT : 2.0);
    $sample = 1000.0;
    $fee = function_exists('sl_stake_tax_fee') ? sl_stake_tax_fee($sample) : round($sample * $pct / 100.0, 4);
    $ok('TAX row — My History / My Record', 'SL_TAX_PERCENT = ' . $pct . '%   ->   1000 par '
        . $fee . ' rs tax;  "After tax amount" = ' . max(0.0, round($sample - $fee, 4)));
    $exists = false;
    if (isset($conn) && ($conn instanceof mysqli) && !$conn->connect_errno) {
        $res = $conn->query("SHOW COLUMNS FROM saas_lottery_bets LIKE 'tax_fee'");
        $exists = (bool) ($res && $res->num_rows > 0);
        if ($res) {
            $res->close();
        }
    }
    if ($exists) {
        $ok('saas_lottery_bets.tax_fee column hai', 'Naye bets apna tax store karenge; purane ke liye 2% auto-calculate hoga.');
    } else {
        $bad('saas_lottery_bets.tax_fee column NAHI mila',
            'Ek baar koi bhi lottery page (WinGo) kholo — engine khud column add kar lega. Phir ye page refresh karo.');
    }
} catch (Throwable $e) {
    $bad('TAX check fail', htmlspecialchars($e->getMessage()));
}

// ---------------------------------------------------------------- render --
echo '<!doctype html><meta charset="utf-8"><title>DMFirst self check — v6 (2026-10-08)</title>';
echo '<body style="font:14px/1.5 system-ui;background:#0e1116;color:#e6e6e6;margin:0;padding:24px">';
echo '<h2 style="margin:0 0 4px">DMFirst — self check <small style="opacity:.6">v6 · 2026-10-08</small></h2>';
echo '<div style="opacity:.7;margin-bottom:18px">' . htmlspecialchars($base) . '</div>';
if ($shiftRows) {
    echo '<h3 style="margin:22px 0 6px">1-PERIOD PICHE — live table</h3>';
    echo '<table style="border-collapse:collapse;font:13px ui-monospace,monospace;background:#161b22;border-radius:6px;overflow:hidden">';
    echo '<tr style="background:#21262d"><th style="padding:6px 14px;text-align:left">Dikha raha period</th>'
        . '<th style="padding:6px 14px;text-align:left">Result</th></tr>';
    foreach ($shiftRows as $sr) {
        $style = $sr[2] ? 'color:#e3b341' : 'color:#e6e6e6';
        echo '<tr style="border-top:1px solid #30363d">'
            . '<td style="padding:6px 14px;' . $style . '">' . htmlspecialchars($sr[0]) . '</td>'
            . '<td style="padding:6px 14px">' . htmlspecialchars($sr[1]) . '</td></tr>';
    }
    echo '</table>';
    echo '<div style="opacity:.7;font-size:12px;margin-top:6px">'
        . 'Site ka sabse naya result wahi number hai jo upstream ne <b>ek period pehle</b> nikala tha — '
        . 'aur site ka period number bhi usse 1 chhota hai.</div>';
}

if ($cmp['ready']) {
    echo '<h3 style="margin:22px 0 6px">UPSTREAM &nbsp;vs&nbsp; SITE &nbsp;— asli proof</h3>';
    echo '<table style="border-collapse:collapse;font:13px ui-monospace,monospace;background:#161b22;border-radius:6px;overflow:hidden">';
    echo '<tr style="background:#21262d">'
        . '<th style="padding:6px 14px;text-align:left">UPSTREAM (draw.ar-lottery01.com)</th>'
        . '<th style="padding:6px 14px;text-align:left">SITE (dmfirst)</th></tr>';
    $maxRows = max(count($cmp['up']), count($cmp['site']));
    echo '<tr style="border-top:1px solid #30363d">'
        . '<td style="padding:6px 14px;color:#e3b341">OPEN ' . htmlspecialchars($cmp['upCur']) . '</td>'
        . '<td style="padding:6px 14px;color:#e3b341">OPEN ' . htmlspecialchars($cmp['siteCur']) . '</td></tr>';
    for ($i = 0; $i < $maxRows; $i++) {
        $u = isset($cmp['up'][$i]) ? htmlspecialchars($cmp['up'][$i][0] . '  ->  ' . $cmp['up'][$i][1]) : '';
        $t = isset($cmp['site'][$i]) ? htmlspecialchars($cmp['site'][$i][0] . '  ->  ' . $cmp['site'][$i][1]) : '';
        $hl = ($i === 0) ? 'background:#1c2430' : '';
        echo '<tr style="border-top:1px solid #30363d;' . $hl . '">'
            . '<td style="padding:6px 14px">' . $u . '</td>'
            . '<td style="padding:6px 14px">' . $t . '</td></tr>';
    }
    echo '</table>';
    if ($cmpNote !== '') {
        echo '<div style="opacity:.8;font-size:12px;margin-top:6px">' . htmlspecialchars($cmpNote) . '</div>';
    }
    echo '<div style="opacity:.7;font-size:12px;margin-top:4px">'
        . 'Sahi jawab: site ki pehli row == upstream ki <b>doosri</b> row (bilkul same period, same number). '
        . 'Tab hi period BHI piche aur result BHI piche hai.</div>';
}

$fail = 0;
foreach ($rows as $r) {
    list($st, $t, $d) = $r;
    $color = $st === true ? '#1a7f37' : ($st === false ? '#b62324' : '#3b82f6');
    $label = $st === true ? 'OK  ' : ($st === false ? 'FAIL' : 'INFO');
    if ($st === false) {
        $fail++;
    }
    echo '<div style="border-left:4px solid ' . $color . ';background:#161b22;padding:8px 12px;margin:6px 0;border-radius:4px">';
    echo '<b style="color:' . $color . '">' . $label . '</b> &nbsp;' . htmlspecialchars($t);
    if ($d !== '') {
        echo '<div style="opacity:.75;font-size:12px;margin-top:3px">' . $d . '</div>';
    }
    echo '</div>';
}
echo '<h3 style="margin-top:20px;color:' . ($fail ? '#b62324' : '#1a7f37') . '">'
    . ($fail ? ($fail . ' problem(s) — upar FAIL wali lines padho')
             : 'Sab kuch GREEN hai. Ab app me jaakar WinGo kholo — URL me #/saasLottery/WinGo?gameCode=WinGo_30S aana chahiye.')
    . '</h3>';
echo '<p style="opacity:.7">Note: browser Purge All / Cache Clear + app Clear Data zaroor karo, warna purana JS chalega.</p>';
echo '</body>';
