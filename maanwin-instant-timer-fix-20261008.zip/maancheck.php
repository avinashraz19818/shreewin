<?php
/**
 * maancheck.php — maanwin instant-settlement + timer self check
 * ==============================================================
 * Browser me kholo:  https://maanwin.club9.eu.cc/maancheck.php
 *
 * Ye do cheezein verify karta hai:
 *   1) LE_INSTANT_SETTLEMENT ON hai ya nahi
 *   2) LE_TIMER_LEAD_MS kitna hai — asli bacha hua time vs dikhne wala time
 */
declare(strict_types=1);
header('Content-Type: text/html; charset=utf-8');

try {
    require_once __DIR__ . '/api/_core/bootstrap.php';
} catch (Throwable $e) {
    echo '<!doctype html><meta charset="utf-8"><body style="font:15px system-ui;padding:30px">';
    echo '<h2 style="color:#b62324">Bootstrap load fail</h2><pre>' . htmlspecialchars($e->getMessage()) . '</pre></body>';
    exit;
}

$instant = defined('LE_INSTANT_SETTLEMENT') ? (bool) LE_INSTANT_SETTLEMENT : true;
$leadMs  = defined('LE_TIMER_LEAD_MS') ? (int) LE_TIMER_LEAD_MS : 0;

$game = 'WinGo_30S';
$iss  = function_exists('lottery_issue') ? lottery_issue($game) : null;

echo '<!doctype html><meta charset="utf-8"><title>maanwin check</title>';
echo '<body style="font:15px/1.6 system-ui;background:#0e1116;color:#e6e6e6;margin:0;padding:28px">';
echo '<h2 style="margin:0 0 4px">maanwin — self check</h2>';
echo '<div style="opacity:.7;margin-bottom:22px">' . htmlspecialchars((string)($_SERVER['HTTP_HOST'] ?? '')) . '</div>';

function mc(string $label, string $value, string $color): void {
    echo '<div style="display:flex;gap:14px;padding:9px 0;border-bottom:1px solid #21262d;max-width:760px">'
       . '<div style="width:250px;opacity:.75">' . htmlspecialchars($label) . '</div>'
       . '<div style="font-family:ui-monospace,monospace;color:' . $color . '">' . htmlspecialchars($value) . '</div></div>';
}

echo '<h3 style="margin:18px 0 4px">1) Bet lagte hi Win / Loss</h3>';
echo '<div style="background:#161b22;border:1px solid #30363d;border-radius:8px;padding:14px 18px;max-width:760px">';
mc('LE_INSTANT_SETTLEMENT', $instant ? 'true  (ON — bet lagte hi settle)' : 'false (OFF — purana behaviour)', $instant ? '#3fb950' : '#f85149');
echo '</div>';
echo '<div style="opacity:.75;font-size:13px;margin-top:8px">'
   . ($instant
      ? 'Sahi hai. Ab bet lagte hi "My History" me Win / Loss aur amount dikhne lagega.'
      : 'OFF hai. <code>api/_core/config.php</code> me <code>LE_INSTANT_SETTLEMENT</code> ko <code>true</code> karo.')
   . '</div>';

echo '<h3 style="margin:24px 0 4px">2) Timer (1 second kam)</h3>';
echo '<div style="background:#161b22;border:1px solid #30363d;border-radius:8px;padding:14px 18px;max-width:760px">';
mc('LE_TIMER_LEAD_MS', (string) $leadMs, $leadMs > 0 ? '#3fb950' : '#f85149');
if ($iss) {
    $shownEnd  = (int) ($iss['endTime'] ?? 0);
    $trueEnd   = $shownEnd + $leadMs;
    $nowMs     = (int) ($iss['serverTime'] ?? ($iss['currentTime'] ?? 0));
    $shownLeft = max(0, (int) floor(($shownEnd - $nowMs) / 1000));
    $trueLeft  = max(0, (int) floor(($trueEnd - $nowMs) / 1000));
    mc('Game', (string) $game, '#e6e6e6');
    mc('Issue number', (string) ($iss['issueNumber'] ?? ''), '#e6e6e6');
    mc('ASLI bacha hua time', gmdate('i:s', $trueLeft) . '  (' . $trueLeft . ' sec)', '#e3b341');
    mc('DIKHEGA', gmdate('i:s', $shownLeft) . '  (' . $shownLeft . ' sec)', '#3fb950');
    $ok = ($trueLeft - $shownLeft) === (int) floor($leadMs / 1000);
    mc('Farq', ($trueLeft - $shownLeft) . ' second', $ok ? '#3fb950' : '#f85149');
}
echo '</div>';
if ($iss) {
    echo '<div style="opacity:.75;font-size:13px;margin-top:8px">'
       . 'Jaise asli 11:55 bacha hai to screen par <b>11:54</b> dikhega. Issue number / settlement par koi asar nahi.'
       . '</div>';
}

echo '<h3 style="margin:24px 0 4px">3) Kaise test karein</h3>';
echo '<ol style="opacity:.85;max-width:760px">'
   . '<li>Site kholo &rarr; WinGo &rarr; koi bhi bet lagao.</li>'
   . '<li>Turant "My History" kholo &mdash; sabse upar wali row me <b>Win</b> ya <b>Loss</b> likha aana chahiye (pahle "--" / pending rehta tha).</li>'
   . '<li>Game screen ke upar wala countdown dekho &mdash; asli time se 1 second kam dikhega.</li>'
   . '</ol>';
echo '</body>';
