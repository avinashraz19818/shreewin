<?php
/**
 * DMFirst — public draw feed.
 *
 * Frontend baseURL:  https://dmfirst.club9.eu.cc/draw-live-v4
 *   GET /draw-live-v4/{Lottery}/{gameCode}.json
 *   GET /draw-live-v4/{Lottery}/{gameCode}/GetHistoryIssuePage.json
 *
 * Root .htaccess bhi  /{Lottery}/{gameCode}.json  ko yahin bhejta hai.
 *
 * IMPORTANT: frontend ka axios transform  {code:0, data:...}  hi accept
 * karta hai (warna "请求接口错误" throw). Isliye dono shape sath bhejte hain:
 *   { code:0, data:{ .... , data:{ .... } } }
 * upar wala unwrap hone ke baad bhi, niche wala bina unwrap ke bhi chalta hai.
 */

declare(strict_types=1);

$__origin = (string) ($_SERVER['HTTP_ORIGIN'] ?? '');
$__host   = preg_replace('/:\d+$/', '', (string) ($_SERVER['HTTP_HOST'] ?? ''));
$__oHost  = $__origin !== '' ? (string) (parse_url($__origin, PHP_URL_HOST) ?: '') : '';
if ($__origin !== '' && $__host !== '' && strcasecmp($__oHost, $__host) === 0) {
    header('Access-Control-Allow-Origin: ' . $__origin);
    header('Vary: Origin');
    header('Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept, Authorization');
    header('Access-Control-Allow-Methods: GET, OPTIONS');
}

require_once dirname(__DIR__) . '/saas_lottery/bootstrap_live_v4.php';

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}

try {
    sl_install_schema();
} catch (Throwable $e) {
    error_log('[dmfirst draw schema] ' . $e->getMessage());
}

// ------------------------------------------------- request ko samjho ------
$lottery = preg_replace('/[^A-Za-z0-9_]/', '', (string) ($_GET['lottery'] ?? ''));
$game    = preg_replace('/[^A-Za-z0-9_]/', '', (string) ($_GET['gameCode'] ?? ''));
$history = isset($_GET['history']) && (string) $_GET['history'] === '1';

if ($game === '') {
    // /draw-live-v4/WinGo/WinGo_30S.json  ya  .../WinGo_30S/GetHistoryIssuePage.json
    $uri   = (string) ($_SERVER['REQUEST_URI'] ?? '');
    $path  = parse_url($uri, PHP_URL_PATH) ?: $uri;
    $path  = preg_replace('#^.*?/draw-live-v4/#', '', (string) $path);   // draw-live-v4 ke baad
    $path  = trim((string) $path, '/');
    $parts = array_values(array_filter(explode('/', $path), 'strlen'));
    if ($parts) {
        $last = (string) $parts[count($parts) - 1];
        if (stripos($last, 'GetHistoryIssuePage') !== false) {
            $history = true;
            array_pop($parts);
        }
    }
    if ($parts) {
        // aakhri hissa hamesha gameCode hota hai
        $game = (string) preg_replace('/\.json$/i', '', (string) array_pop($parts));
    }
    if ($parts && $lottery === '') {
        $lottery = (string) array_pop($parts);
    }
}

if ($game === '' || !isset($SL_CONFIG['games'][$game])) {
    sl_fail(7, 'Unsupported game code', 7, 200);
}

// --------------------------------------------------------- HISTORY --------
if ($history) {
    $pageNo   = max(1, (int) ($_GET['pageNo'] ?? 1));
    $pageSize = min(100, max(1, (int) ($_GET['pageSize'] ?? 10)));
    $payload  = sl_provider_history($game, $pageNo, $pageSize);

    if ($payload && isset($payload['data']['list'])) {
        try {
            sl_save_and_settle_results($game, $payload['data']['list']);
        } catch (Throwable $e) {
            error_log('[dmfirst draw settle] ' . $e->getMessage());
        }
        $list = $payload['data']['list'];
    } else {
        $local = sl_local_history($game, $pageNo, $pageSize);
        $list  = $local['data']['list'];
        $payload = array('data' => array(
            'list' => $list,
            'pageNo' => $pageNo,
            'totalPage' => $local['data']['totalPage'],
            'totalCount' => $local['data']['totalCount'],
        ));
    }

    $body = array(
        'list'       => $list,
        'pageNo'     => (int) ($payload['data']['pageNo'] ?? $pageNo),
        'totalPage'  => (int) ($payload['data']['totalPage'] ?? 50),
        'totalCount' => (int) ($payload['data']['totalCount'] ?? 0),
    );
    if (sl_game_family($game) === 'MotoRace') {
        $body['statistics'] = sl_moto_statistics($list);
    }

    sl_send(array(
        'data'        => $body + array('data' => $body),
        'code'        => 0,
        'msg'         => 'Succeed',
        'msgCode'     => 0,
        'serviceTime' => sl_now_ms(),
    ), 200);
}

// --------------------------------------------------------- CURRENT --------
$current = sl_provider_current($game);
if (!$current) {
    $current = sl_apply_wingo_current_trend($game, sl_local_current($game));
}
if ($lottery !== '') {
    $current['lotteryCode'] = $lottery;
}
$current['gameCode'] = $game;

sl_send(array(
    'data'        => $current + array('data' => $current),
    'code'        => 0,
    'msg'         => 'Succeed',
    'msgCode'     => 0,
    'serviceTime' => sl_now_ms(),
), 200);
