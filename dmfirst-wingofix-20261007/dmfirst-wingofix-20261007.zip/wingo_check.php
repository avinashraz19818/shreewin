<?php
/**
 * DMFirst — WinGo self-check.
 * Browser me kholo:  https://apnidomain.com/wingo_check.php
 * Ye batayega ki kya kaam kar raha hai aur kya nahi.
 */
declare(strict_types=1);
header('Content-Type: text/html; charset=utf-8');
?>
<!doctype html>
<html><head><meta charset="utf-8"><title>WinGo check</title>
<style>
body{font:14px/1.5 ui-monospace,Menlo,Consolas,monospace;background:#111;color:#ddd;margin:0;padding:18px}
h2{color:#7fd1ff;margin:22px 0 8px;font-size:15px}
table{border-collapse:collapse;width:100%;max-width:1100px}
th,td{border:1px solid #333;padding:5px 8px;text-align:left;vertical-align:top}
th{background:#1c1c1c;color:#9ecbff}
.ok{color:#5fdc7a}.bad{color:#ff6b6b}.warn{color:#ffd166}
pre{background:#000;padding:10px;overflow:auto;border:1px solid #333;max-height:340px}
</style></head><body>
<h1>DMFirst WinGo check — <?= htmlspecialchars((string)($_SERVER['HTTP_HOST'] ?? '')) ?></h1>

<?php
$root = __DIR__;
echo '<h2>1. Files</h2><table><tr><th>Path</th><th>Status</th></tr>';
$files = array(
    'api-live-v4/Lottery/index.php',
    'draw-live-v4/index.php',
    'draw-live-v4/.htaccess',
    'saas_lottery/bootstrap_live_v4.php',
    'saas_lottery/config_live_v4.php',
    'saas_lottery/admin_override.php',
);
foreach ($files as $f) {
    $ok = is_file($root . '/' . $f);
    echo '<tr><td>' . htmlspecialchars($f) . '</td><td class="' . ($ok ? 'ok' : 'bad') . '">' . ($ok ? 'OK' : 'MISSING') . '</td></tr>';
}
echo '</table>';

echo '<h2>2. Database</h2>';
$dbOk = false;
try {
    require_once $root . '/devmaruf/conn.php';
    if (isset($conn) && ($conn instanceof mysqli) && !$conn->connect_errno) {
        $dbOk = true;
        echo '<p class="ok">DB connected: ' . htmlspecialchars(DB_NAME) . '</p>';
        $need = array('saas_lottery_bets','saas_lottery_results','saas_lottery_settings','app_settings','shonu_subjects','shonu_kaichila');
        echo '<table><tr><th>Table</th><th>Status</th></tr>';
        foreach ($need as $t) {
            $r = $conn->query("SHOW TABLES LIKE '" . $conn->real_escape_string($t) . "'");
            $has = $r && $r->num_rows > 0;
            echo '<tr><td>' . htmlspecialchars($t) . '</td><td class="' . ($has ? 'ok' : 'bad') . '">' . ($has ? 'OK' : 'MISSING') . '</td></tr>';
        }
        echo '</table>';
    } else {
        echo '<p class="bad">DB connection FAILED</p>';
    }
} catch (Throwable $e) {
    echo '<p class="bad">DB error: ' . htmlspecialchars($e->getMessage()) . '</p>';
}

if ($dbOk) {
    echo '<h2>3. Upstream (draw.ar-lottery01.com)</h2>';
    try {
        require_once $root . '/saas_lottery/bootstrap_live_v4.php';
    } catch (Throwable $e) {
        echo '<p class="bad">Engine load error: ' . htmlspecialchars($e->getMessage()) . '</p>';
    }
    if (function_exists('sl_external_url')) {
        echo '<table><tr><th>Game</th><th>URL</th><th>HTTP</th><th>Current issue</th><th>Seconds left</th></tr>';
        $ua = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/150.0.0.0 Safari/537.36';
        foreach (array_keys($SL_CONFIG['games']) as $gc) {
            if (substr($gc, 0, 5) !== 'WinGo' && substr($gc, 0, 3) !== 'K3_') continue;
            $url = sl_external_url($gc, false);
            $code = 0; $body = '';
            if (function_exists('curl_init')) {
                $ch = curl_init($url . '?ts=' . time());
                curl_setopt_array($ch, array(
                    CURLOPT_RETURNTRANSFER => true, CURLOPT_FOLLOWLOCATION => true,
                    CURLOPT_CONNECTTIMEOUT => 5, CURLOPT_TIMEOUT => 6,
                    CURLOPT_SSL_VERIFYPEER => true, CURLOPT_SSL_VERIFYHOST => 2,
                    CURLOPT_HTTPHEADER => array(
                        'Accept: application/json, text/plain, */*',
                        'Referer: https://www.lottery7uuu.com/',
                        'Origin: https://www.lottery7uuu.com',
                    ),
                    CURLOPT_USERAGENT => $ua,
                ));
                $body = (string) curl_exec($ch);
                $code = (int) curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
                curl_close($ch);
            }
            $issue = '-'; $left = '-';
            $j = json_decode($body, true);
            if (is_array($j) && isset($j['current']['issueNumber'])) {
                $issue = (string) $j['current']['issueNumber'];
                $left = max(0, (int) round(((int) $j['current']['endTime'] - (int) (microtime(true) * 1000)) / 1000));
            }
            echo '<tr><td>' . htmlspecialchars($gc) . '</td><td style="font-size:11px">' . htmlspecialchars($url) . '</td>'
                . '<td class="' . ($code === 200 ? 'ok' : 'bad') . '">' . $code . '</td>'
                . '<td>' . htmlspecialchars($issue) . '</td><td>' . htmlspecialchars((string) $left) . '</td></tr>';
        }
        echo '</table>';

        echo '<h2>4. Engine (jo site actually use karti hai)</h2>';
        echo '<table><tr><th>Game</th><th>Local current (shifted)</th><th>Upstream current</th><th>Trend mode</th><th>Sec left</th></tr>';
        foreach (array_keys($SL_CONFIG['games']) as $gc) {
            $loc = sl_local_current($gc);
            $locIssue = sl_apply_wingo_current_trend($gc, $loc);
            $prov = sl_provider_current($gc);
            $mode = function_exists('sl_wingo_trend_mode') ? sl_wingo_trend_mode($gc) : 'n/a';
            $left = max(0, (int) round(((int) $loc['current']['endTime'] - (int) (microtime(true) * 1000)) / 1000));
            $upIssue = $prov ? (string) $prov['current']['issueNumber'] : 'UPSTREAM FAIL';
            $ok = $prov && $upIssue === (string) $locIssue['current']['issueNumber'];
            echo '<tr><td>' . htmlspecialchars($gc) . '</td>'
                . '<td>' . htmlspecialchars((string) $locIssue['current']['issueNumber']) . '</td>'
                . '<td class="' . ($prov ? 'ok' : 'bad') . '">' . htmlspecialchars($upIssue) . '</td>'
                . '<td class="' . ($mode === 'back_one' ? 'ok' : 'warn') . '">' . htmlspecialchars((string) $mode) . '</td>'
                . '<td>' . $left . '</td></tr>';
        }
        echo '</table>';

        echo '<h2>5. Settings</h2><pre>';
        echo 'SL_PERIOD_SHIFT      = ' . (defined('SL_PERIOD_SHIFT') ? var_export(SL_PERIOD_SHIFT, true) : 'undefined') . "\n";
        echo 'SL_FORCE_TREND_MODE  = ' . (defined('SL_FORCE_TREND_MODE') ? var_export(SL_FORCE_TREND_MODE, true) : 'undefined') . "\n";
        echo 'SL_DRAW_CACHE_SECONDS= ' . (defined('SL_DRAW_CACHE_SECONDS') ? var_export(SL_DRAW_CACHE_SECONDS, true) : 'undefined') . "\n";
        echo 'SL_DRAW_FALLBACK_LOCAL=' . (defined('SL_DRAW_FALLBACK_LOCAL') ? var_export(SL_DRAW_FALLBACK_LOCAL, true) : 'undefined') . "\n";
        echo 'draw_base_url        = ' . (string) $SL_CONFIG['draw_base_url'] . "\n";
        echo 'force_remote_draw    = ' . var_export(!empty($SL_CONFIG['force_remote_draw']), true) . "\n";
        echo 'server time          = ' . date('Y-m-d H:i:s') . " (Asia/Kolkata)\n";
        echo 'UTC now              = ' . gmdate('Y-m-d H:i:s') . "\n";
        echo 'temp dir writable    = ' . (is_writable(sys_get_temp_dir()) ? 'yes' : 'NO') . ' (' . sys_get_temp_dir() . ")\n";
        echo '</pre>';
    }
}
?>
<h2>6. Expected results</h2>
<ul>
  <li><b>Files</b> — sab OK</li>
  <li><b>Tables</b> — sab OK (pehli request par apne aap ban jayengi)</li>
  <li><b>Upstream HTTP</b> — <span class="ok">200</span> (403 aaye to header profile badalna hoga — mujhe ye output bhejo)</li>
  <li><b>Trend mode</b> — <span class="ok">back_one</span> (matlab 1 period piche)</li>
  <li><b>Local current == Upstream current</b> — dono barabar hone chahiye</li>
</ul>
<p style="color:#888">Agar koi row red hai to ye poora page copy karke bhejo.</p>
</body></html>
