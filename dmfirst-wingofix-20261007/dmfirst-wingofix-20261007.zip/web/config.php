<?php
/**
 * /web/config?_key=ar103  ->  frontend isko <script> ki tarah load karta hai.
 * Ye file pehle nahi thi (web/config.js corrupt hai) isliye browser me
 * 405 aa raha tha. Ab API base URLs dynamic (current host) set kar deta hai.
 */
declare(strict_types=1);
header('Content-Type: application/javascript; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate');

$scheme = 'https';
if (!empty($_SERVER['HTTP_X_FORWARDED_PROTO'])) {
    $scheme = strtolower((string) $_SERVER['HTTP_X_FORWARDED_PROTO']) === 'http' ? 'http' : 'https';
} elseif (empty($_SERVER['HTTPS']) || $_SERVER['HTTPS'] === 'off') {
    $scheme = 'https';
}
$host = preg_replace('/[^A-Za-z0-9._-]/', '', (string) ($_SERVER['HTTP_HOST'] ?? ''));
$base = $host !== '' ? $scheme . '://' . $host : '';

echo "/* dmfirst runtime config */\n";
if ($base !== '') {
    echo "try {\n";
    echo "  var __pack = function (v) { return JSON.stringify({ value: v, expires: -1 }); };\n";
    echo "  if (!localStorage.getItem('ar_')) localStorage.setItem('ar_', __pack(" . json_encode($base) . "));\n";
    echo "  if (!localStorage.getItem('ar__json')) localStorage.setItem('ar__json', __pack(" . json_encode($base . '/draw-live-v4') . "));\n";
    echo "} catch (e) {}\n";
}
