<?php
// ===============================
// Dhani Win Backend Config
// cPanel MySQL details yaha set hain.
// AUTO_INSTALL_TABLES=true hone par pehli API request par tables automatic create/seed ho jayengi.
// ===============================

define('DB_HOST', getenv('DW_DB_HOST') ?: 'localhost');
define('DB_NAME', getenv('DW_DB_NAME') ?: 'club532583_maanwin');
define('DB_USER', getenv('DW_DB_USER') ?: 'club532583_maanwin');
define('DB_PASS', getenv('DW_DB_PASS') ?: 'club532583_maanwin');

define('AUTO_INSTALL_TABLES', true);
define('AUTO_INSTALL_VERSION', '2026_07_22_v34_support_team_wheel');

define('APP_TENANT_ID', 6007);
define('APP_CURRENCY', 'INR');
define('APP_CURRENCY_SIGN', '₹');
define('APP_SECRET', getenv('DW_APP_SECRET') ?: 'b887fd8e108ea8bdd2587747c6cc1eec91806544edb76abe99d9ec703d8a23ad');
define('APP_TIMEZONE', 'Asia/Kolkata');

// true = project/demo virtual wallet only. Real-money payment gateway/live settlement connected nahi hai.
define('DEMO_MODE', true);

// =========================================================================
// LOTTERY ENGINE — 4 FIXES  (2026-10-08)
// -------------------------------------------------------------------------
// 1) Bet lagte hi My History me Win / Loss aa jaye
//      true  = bet lagte hi result settle ho jata hai (My History me turant
//              "Success / Fail" + amount dikhega)
//      false = purana behaviour (period band hone par settle)
//    (Sirf My History / Win-Loss popup jaldi dikhta hai. Game screen, Trend
//     aur Period history me result period band hone ke BAAD hi dikhega.)
if (!defined('LE_INSTANT_SETTLEMENT'))  define('LE_INSTANT_SETTLEMENT', true);
//
// 2) Bet wale timer me 1 second KAM dikhaye
//      Asli bacha hua time 11:55  ->  screen par 11:54
//      1000 = 1 second kam   |   2000 = 2 second kam   |   0 = asli time
//    (Issue number, settlement aur DB par KOI asar nahi — sirf dikhne wala
//     time badalta hai.)
if (!defined('LE_TIMER_LEAD_MS'))       define('LE_TIMER_LEAD_MS', 1000);
//
// 3) Timer khatam hone par WIN / LOSS POPUP aaye
//      Screen wala countdown is value ke barabar ya chhota hone par current
//      period ka result "Game history / Period history" ki pehli row me aa
//      jata hai — popup ko wahi row chahiye hoti hai, isliye popup tabhi
//      dikhta hai.  Betting 5 second pehle hi band ho jati hai, isliye
//      isse koi result jaldi "dekh kar" bet nahi laga sakta.
//      FIX #8 (2026-10-08): ab default -1 (BAND).
//      Kyun: 1 par current period ka result timer khatam hone se 1-2 second
//      PAHLE history ki pehli row me aa jata tha — isse "period/result badal
//      gaya" dikhta tha. -1 par current period kabhi running timer ke sath
//      list me nahi aata; period khatam hote hi wo pehli row me aa jata hai,
//      aur popup bhi theek waqt par (timer khatam hone par) dikhta hai.
//      -1 = default (recommended)   |   1 = purana (jaldi reveal) behaviour
if (!defined('LE_REVEAL_AT_COUNTDOWN')) define('LE_REVEAL_AT_COUNTDOWN', -1);
//
// 4) TAX + ORDER NUMBER (My History detail panel)
//      Tax  = bet amount ka 2%  (1000 par 20 rs) — har bet par.
//             Ye sirf record me DIKHAYA jata hai; wallet se alag se nahi
//             kata jata (payout par ka 2% tax alag se lagta hai).
//      Order no = 30 char:  WG + Ymd + His + 7-digit user + 7-digit bet id
//             jaise  WG202610080443175103202703489
//             Prefix: WinGo=WG  TrxWinGo=TW  K3=K3  5D/D5=5D  MotoRace=MR
if (!defined('LE_TAX_PERCENT'))         define('LE_TAX_PERCENT', 2.0);
if (!defined('LE_ORDER_NO'))            define('LE_ORDER_NO', true);
// =========================================================================

@date_default_timezone_set(APP_TIMEZONE);
