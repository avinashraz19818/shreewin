<?php
/**
 * maancheck.php — maanwin 4-FIX self check  (2026-10-08)
 * ======================================================
 * Browser me kholo:  https://maanwin.club9.eu.cc/maancheck.php
 *
 * Ye 4 cheezein verify karta hai:
 *   1) Bet lagte hi My History me Win / Loss   (LE_INSTANT_SETTLEMENT)
 *   2) Bet wala timer 1 second KAM             (LE_TIMER_LEAD_MS)
 *   3) Timer khatam hone par Win/Loss POPUP    (LE_REVEAL_AT_COUNTDOWN)
 *   4) TAX 2% + 30 char ORDER NUMBER           (LE_TAX_PERCENT / LE_ORDER_NO)
 *
 * NOTE: ye sirf CHECK karta hai, kuch bhi change nahi karta.
 *       Kaam ho jane ke baad is file ko delete kar dena.
 */
header('Content-Type: text/html; charset=utf-8');

try {
    require_once __DIR__ . '/api/_core/bootstrap.php';
} catch (Throwable $e) {
    echo '<!doctype html><meta charset="utf-8"><body style="font:15px system-ui;padding:30px">';
    echo '<h2 style="color:#b62324">Bootstrap load fail</h2><pre>' . htmlspecialchars($e->getMessage()) . '</pre></body>';
    exit;
}

$instant   = defined('LE_INSTANT_SETTLEMENT')  ? (bool)LE_INSTANT_SETTLEMENT   : false;
$leadMs    = defined('LE_TIMER_LEAD_MS')       ? (int)LE_TIMER_LEAD_MS         : 0;
$revealAt  = defined('LE_REVEAL_AT_COUNTDOWN') ? (int)LE_REVEAL_AT_COUNTDOWN   : 99;
$taxPct    = defined('LE_TAX_PERCENT')         ? (float)LE_TAX_PERCENT         : 0.0;
$orderOn   = defined('LE_ORDER_NO')            ? (bool)LE_ORDER_NO             : false;

$game = 'WinGo_30S';
$iss  = function_exists('lottery_issue') ? lottery_issue($game) : null;

$nowTs    = time();
$interval = function_exists('le_game_interval') ? le_game_interval($game) : 30;
$asliEnd  = (int)intdiv($nowTs, $interval) * $interval + $interval;   // asli band hone ka time
$asliLeft = max(0, $asliEnd - $nowTs);
$dikhLeft = $iss ? (int)($iss['countdown'] ?? 0) : 0;

$revealNow = function_exists('le_should_reveal_current') ? le_should_reveal_current($game) : false;
$startOff  = function_exists('le_history_start_offset')  ? le_history_start_offset($game)  : 1;

$sample = 1000.0;
$tax    = function_exists('le_stake_tax') ? le_stake_tax($sample) : 0.0;
$ord    = function_exists('le_order_number') ? le_order_number($game, 1032027, 3489, $nowTs) : '';
$ordLen = strlen((string)$ord);

echo '<!doctype html><meta charset="utf-8"><title>maanwin 4-fix check</title>';
echo '<body style="font:15px/1.6 system-ui;background:#0e1116;color:#e6e6e6;margin:0;padding:26px">';
echo '<h2 style="margin:0 0 2px">maanwin — 4 FIX self check</h2>';
echo '<div style="opacity:.65;margin-bottom:20px">' . htmlspecialchars((string)($_SERVER['HTTP_HOST'] ?? '')) . ' &nbsp;·&nbsp; ' . date('Y-m-d H:i:s') . '</div>';

function mc(string $label, string $value, string $color = '#e6e6e6'): void {
    echo '<div style="display:flex;gap:14px;padding:8px 0;border-bottom:1px solid #21262d;max-width:820px">'
       . '<div style="width:290px;opacity:.75">' . htmlspecialchars($label) . '</div>'
       . '<div style="font-family:ui-monospace,monospace;color:' . $color . ';word-break:break-all">' . htmlspecialchars($value) . '</div></div>';
}
function ok(string $t): string  { return '<span style="color:#3fb950">OK</span> ' . $t; }
function no(string $t): string  { return '<span style="color:#f85149">NAHI</span> ' . $t; }

// ---------------------------------------------------------------- 1
echo '<h3 style="margin:20px 0 4px;color:#79c0ff">1) Bet lagte hi My History me Win / Loss</h3>';
echo '<div style="background:#161b22;border:1px solid #30363d;border-radius:8px;padding:12px 18px;max-width:820px">';
mc('LE_INSTANT_SETTLEMENT', $instant ? 'true  (ON — bet lagte hi settle)' : 'false  (OFF — purana behaviour)', $instant ? '#3fb950' : '#f85149');
mc('Matlab', $instant ? 'Bet lagte hi My History me "Success / Fail" + amount' : 'Period band hone ke baad hi result', $instant ? '#3fb950' : '#f85149');
echo '</div>';

// ---------------------------------------------------------------- 2
echo '<h3 style="margin:20px 0 4px;color:#79c0ff">2) Bet wala timer 1 second kam</h3>';
echo '<div style="background:#161b22;border:1px solid #30363d;border-radius:8px;padding:12px 18px;max-width:820px">';
mc('LE_TIMER_LEAD_MS', $leadMs . ' ms', $leadMs > 0 ? '#3fb950' : '#f85149');
mc('ASLI bacha hua time', gmdate('i:s', $asliLeft) . '  (' . $asliLeft . ' s)');
mc('SCREEN par DIKHEGA  ', gmdate('i:s', $dikhLeft) . '  (' . $dikhLeft . ' s)', '#d29922');
mc('Farq', ($asliLeft - $dikhLeft) . ' second' . (($asliLeft - $dikhLeft) === 1 ? '  ✔' : ''), ($asliLeft - $dikhLeft) === 1 ? '#3fb950' : '#f85149');
mc('Issue number (badla nahi)', (string)($iss['issueNumber'] ?? '-'));
echo '</div>';

// ---------------------------------------------------------------- 3
echo '<h3 style="margin:20px 0 4px;color:#79c0ff">3) Timer khatam hone par Win / Loss POPUP</h3>';
echo '<div style="background:#161b22;border:1px solid #30363d;border-radius:8px;padding:12px 18px;max-width:820px">';
mc('LE_REVEAL_AT_COUNTDOWN', (string)$revealAt, $revealAt <= 5 ? '#3fb950' : '#f85149');
mc('History ka pehla offset abhi', (string)$startOff . ($startOff === 0 ? '  (current period bhi list me hai)' : '  (sirf purane period)'), $startOff === 0 ? '#3fb950' : '#e6e6e6');
mc('Reveal abhi chal raha hai', $revealNow ? 'HAAN (countdown <= ' . $revealAt . ')' : 'nahi (countdown abhi bada hai)', $revealNow ? '#3fb950' : '#8b949e');
echo '<div style="opacity:.7;margin-top:10px;font-size:13px">Popup tabhi dikhta hai jab bet wala period Game-history ki pehli row me aa jaye. '
   . 'Ye fix countdown &lt;= ' . $revealAt . ' par current period ko pehli row me la deta hai. Betting us waqt tak band ho chuki hoti hai (countdown &lt;= 5), '
   . 'isliye result dekh kar koi bet nahi lag sakta.</div>';
echo '</div>';

// ---------------------------------------------------------------- 4
echo '<h3 style="margin:20px 0 4px;color:#79c0ff">4) TAX + ORDER NUMBER</h3>';
echo '<div style="background:#161b22;border:1px solid #30363d;border-radius:8px;padding:12px 18px;max-width:820px">';
mc('LE_TAX_PERCENT', rtrim(rtrim(number_format($taxPct, 2, '.', ''), '0'), '.') . ' %', $taxPct > 0 ? '#3fb950' : '#f85149');
mc('1000 rs ke bet par TAX', number_format($tax, 2, '.', '') . ' rs', $tax > 0 ? '#3fb950' : '#f85149');
mc('"After tax amount"', number_format(1000 - $tax, 2, '.', '') . ' rs');
mc('LE_ORDER_NO', $orderOn ? 'true' : 'false', $orderOn ? '#3fb950' : '#f85149');
mc('Sample order number', (string)$ord . '   (' . $ordLen . ' char)', $ordLen === 30 ? '#3fb950' : '#f85149');
echo '</div>';

// ---------------------------------------------------------------- 5
echo '<h3 style="margin:20px 0 4px;color:#79c0ff">5) PERIOD aur RESULT ka MILAN</h3>';
echo '<div style="background:#161b22;border:1px solid #30363d;border-radius:8px;padding:12px 18px;max-width:820px">';
$rawSeq = [];
for ($k = 0; $k <= 10; $k++) {
    try { $rawSeq[$k] = (string)le_issue_by_offset($game, $k); } catch (Throwable $e) { $rawSeq[$k] = ''; }
}
$seqMono = true;
for ($k = 1; $k <= 10; $k++) {
    $prevTail = (int)substr($rawSeq[$k - 1], -5);
    $thisTail = (int)substr($rawSeq[$k], -5);
    if ($prevTail - 1 !== $thisTail) { $seqMono = false; }
}
mc('le_issue_by_offset (raw)', $seqMono
    ? ok('sabhi offset 0..10 lagataar hain')
    : no('offset 0..10 me break hai — pehle yahi "dusra-dusra" ki wajah thi'));
if (function_exists('le_issue_sequence')) {
    $fixed = le_issue_sequence($game, 1, 10);
    $fixedOk = true;
    for ($k = 1; $k < count($fixed); $k++) {
        if (((int)substr($fixed[$k - 1], -5)) - 1 !== ((int)substr($fixed[$k], -5))) { $fixedOk = false; }
    }
    mc('le_issue_sequence (fixed)', $fixedOk ? ok('10/10 row lagataar') : no('abhi bhi break hai'));
    mc('Pehli row', (string)($fixed[0] ?? '-'));
    mc('Aakhri row', (string)($fixed[count($fixed) - 1] ?? '-'));
} else {
    mc('le_issue_sequence', 'MISSING — fix #5 apply nahi hua');
}
echo '</div>';

// ---------------------------------------------------------------- DB
echo '<h3 style="margin:20px 0 4px;color:#79c0ff">DB — aakhri bets</h3>';
echo '<div style="background:#161b22;border:1px solid #30363d;border-radius:8px;padding:12px 18px;max-width:820px;font-family:ui-monospace,monospace;font-size:13px">';
try {
    $conn = db();
    if (!$conn) {
        echo '<div style="color:#f85149">DB connect nahi ho paya</div>';
    } else {
        $rs = @$conn->query('SELECT id,order_no,game_code,issue_number,amount,real_amount,fee,state,win_lose_amount,created_at FROM lottery_bets ORDER BY id DESC LIMIT 5');
        if (!$rs) {
            echo '<div style="color:#f85149">Query fail: ' . htmlspecialchars($conn->error) . '</div>';
        } else {
            echo '<table style="border-collapse:collapse;width:100%"><tr style="opacity:.6;text-align:left">'
               . '<th style="padding:4px 8px">id</th><th style="padding:4px 8px">order no</th><th style="padding:4px 8px">len</th>'
               . '<th style="padding:4px 8px">amount</th><th style="padding:4px 8px">tax</th>'
               . '<th style="padding:4px 8px">state</th><th style="padding:4px 8px">win/lose</th></tr>';
            while ($r = $rs->fetch_assoc()) {
                $st = (int)$r['state'];
                $stTxt = $st === 2 ? 'pending' : ($st === 1 ? 'WIN' : 'LOSS');
                $col = $st === 2 ? '#d29922' : ($st === 1 ? '#3fb950' : '#f85149');
                echo '<tr>'
                   . '<td style="padding:4px 8px;border-top:1px solid #21262d">' . (int)$r['id'] . '</td>'
                   . '<td style="padding:4px 8px;border-top:1px solid #21262d">' . htmlspecialchars((string)$r['order_no']) . '</td>'
                   . '<td style="padding:4px 8px;border-top:1px solid #21262d;color:' . (strlen((string)$r['order_no']) === 30 ? '#3fb950' : '#8b949e') . '">' . strlen((string)$r['order_no']) . '</td>'
                   . '<td style="padding:4px 8px;border-top:1px solid #21262d">' . htmlspecialchars((string)$r['real_amount']) . '</td>'
                   . '<td style="padding:4px 8px;border-top:1px solid #21262d">' . htmlspecialchars((string)$r['fee']) . '</td>'
                   . '<td style="padding:4px 8px;border-top:1px solid #21262d;color:' . $col . '">' . $stTxt . '</td>'
                   . '<td style="padding:4px 8px;border-top:1px solid #21262d">' . htmlspecialchars((string)$r['win_lose_amount']) . '</td>'
                   . '</tr>';
            }
            echo '</table>';
            echo '<div style="opacity:.65;margin-top:8px">state: 2 = pending, 1 = WIN, 0 = LOSS &nbsp;·&nbsp; naye bets me order no 30 char aur fee 2% hona chahiye</div>';
        }
    }
} catch (Throwable $e) {
    echo '<div style="color:#f85149">' . htmlspecialchars($e->getMessage()) . '</div>';
}
echo '</div>';

echo '<div style="opacity:.55;margin-top:22px;font-size:13px">Kaam ho jane ke baad is file ko server se delete kar dena.</div>';
echo '</body>';
