<?php
/**
 * maanwhere.php — "kaunse folder me patch laga hai?" (sirf padhta hai)
 * Browser: https://<site>/maanwhere.php
 * Ye kuch bhi badalta nahi. Output developer ko bhej do.
 */
header('Content-Type: text/plain; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');

echo str_repeat('=', 74) . "\n";
echo "MAANWHERE   " . date('Y-m-d H:i:s T') . "   host=" . ($_SERVER['HTTP_HOST'] ?? '') . "\n";
echo str_repeat('=', 74) . "\n\n";

echo "DOCUMENT_ROOT : " . ($_SERVER['DOCUMENT_ROOT'] ?? '-') . "\n";
echo "IS FILE DIR   : " . __DIR__ . "\n";
echo "SCRIPT        : " . (__FILE__ ?? '-') . "\n\n";

$marks15 = array('le_issue_sequence', 'le_history_page', 'le_upstream_result_for', 'le_bet_time_lead');
$roots   = array(dirname(__DIR__), dirname(dirname(__DIR__)), dirname(dirname(dirname(__DIR__))), '/home', '/home1', '/var/www');
$found   = array();
foreach ($roots as $d) {
    if (!is_dir($d)) continue;
    for ($i = 1; $i <= 3; $i++) {
        $g = @glob(rtrim($d, '/') . str_repeat('/*', $i) . '/api/_core/lottery_engine.php');
        if (!$g) continue;
        foreach ($g as $hit) {
            $root = dirname(dirname(dirname($hit)));
            if (is_dir($root)) $found[$root] = 1;
        }
    }
}
ksort($found);
echo "MILE HUE FOLDER (" . count($found) . "):\n\n";
foreach (array_keys($found) as $dir) {
    $f = rtrim($dir, '/') . '/api/_core/lottery_engine.php';
    $s = @file_get_contents($f);
    $n = 0;
    if (is_string($s)) foreach ($marks15 as $m) if (strpos($s, $m) !== false) $n++;
    echo "  " . $dir . "\n";
    echo "     patch  : " . $n . "/4  " . ($n >= 4 ? "FIX #15 TAK SAB LAGA HUA" : ($n > 0 ? "ADHURA ($n/4)" : "PURANA / PATCH NAHI LAGA")) . "\n";
    echo "     likhne yogya (writable): " . (is_writable($f) ? 'haan' : 'NAHI (installer likh nahi payega)') . "\n";
    echo "     config me LE_BET_TIME_LEAD_SEC : ";
    $c = @file_get_contents(rtrim($dir, '/') . '/api/_core/config.php');
    if (is_string($c) && preg_match("/LE_BET_TIME_LEAD_SEC'\s*,\s*(\d+)/", $c, $mm)) echo $mm[1] . "\n";
    else echo "(nahi mila)\n";
    echo "\n";
}
echo "NOTE: is list me MAANWIN aur MAAN1WIN DONO ke folder dikhne chahiye.\n";
echo "      Agar sirf ek dikh raha hai to doosra folder is server par nahi hai\n";
echo "      (ya alag hosting account par hai).\n";
