<?php
/**
 * maanupdiag.php — UPSTREAM DIAGNOSTIC (plain text)
 * ==================================================
 * Browser me kholo:  https://<site>/maanupdiag.php
 *
 * Ye page kuch BHI change nahi karta. Sirf ye batata hai:
 *   1) Server se https://draw.ar-lottery01.com reachable hai ya nahi
 *   2) Upstream kya HTTP status / kya JSON de raha hai
 *   3) Upstream ka period number / result  vs  local game ka period / result
 *
 * FIX #9 isi data par kaam karta hai. Is page ka output developer ko bhej do.
 */
header('Content-Type: text/plain; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');

try {
    require_once __DIR__ . '/api/_core/bootstrap.php';
} catch (Throwable $e) {
    echo "BOOTSTRAP LOAD FAIL: " . $e->getMessage() . "\n";
    exit;
}

$line   = str_repeat('=', 78);
$games  = ['WinGo_30S', 'WinGo_1M', 'WinGo_3M'];
$base   = defined('LE_UPSTREAM_BASE') ? rtrim((string)LE_UPSTREAM_BASE, '/') : '';
$on     = defined('LE_UPSTREAM_RESULTS') ? (bool)LE_UPSTREAM_RESULTS : false;

echo $line . "\n";
echo "MAANWIN UPSTREAM DIAG   " . date('Y-m-d H:i:s T') . "   host=" . ($_SERVER['HTTP_HOST'] ?? '') . "\n";
echo $line . "\n\n";

echo "[A] SETTING\n";
echo '    LE_UPSTREAM_RESULTS : ' . ($on ? 'true' : 'false') . "\n";
echo '    LE_UPSTREAM_BASE    : ' . ($base !== '' ? $base : '<< NOT SET >>') . "\n";
echo '    curl_init()         : ' . (function_exists('curl_init') ? 'yes' : 'NO') . "\n";
echo '    allow_url_fopen     : ' . var_export((bool)ini_get('allow_url_fopen'), true) . "\n";
echo '    temp dir            : ' . (function_exists('sys_get_temp_dir') ? sys_get_temp_dir() : 'n/a') . "\n";
echo '    LE_ISSUE_DATE_TZ  : ' . (defined('LE_ISSUE_DATE_TZ') ? LE_ISSUE_DATE_TZ : '<< NOT DEFINED >>') . "   (utc = API jaisa)\n";
echo '    LE_PERIOD_SHIFT  : ' . (function_exists('le_period_shift') ? (string)le_period_shift() : '<< NOT DEFINED >>') . "\n";
echo '    LE_UPSTREAM_PAGES: ' . (defined('LE_UPSTREAM_PAGES') ? (string)LE_UPSTREAM_PAGES : '<< NOT DEFINED >>') . "\n";
echo '    server timezone  : ' . date('T') . '   abhi ' . date('Y-m-d H:i:s') . '  |  UTC ' . gmdate('Y-m-d H:i:s') . "\n";
if (function_exists('le_issue_offset')) {
    foreach (['WinGo_30S', 'WinGo_1M', 'WinGo_3M', 'WinGo_5M'] as $g) {
        echo '    offset ' . str_pad($g, 10) . ' : mid=' . le_issue_mid($g)
             . '  C=' . le_issue_offset($g) . '  drift=' . le_issue_drift($g) . "\n";
    }
}
echo "\n";

/** bina cache ke seedha HTTP call (diagnostic ke liye) */
function up_raw(string $url, int $timeout = 6): array
{
    $out = ['how' => '-', 'code' => 0, 'body' => '', 'err' => ''];
    if (function_exists('curl_init')) {
        $ch = @curl_init($url);
        if ($ch) {
            @curl_setopt_array($ch, [
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_FOLLOWLOCATION => true,
                CURLOPT_CONNECTTIMEOUT => $timeout,
                CURLOPT_TIMEOUT        => $timeout + 2,
                CURLOPT_SSL_VERIFYPEER => false,
                CURLOPT_SSL_VERIFYHOST => false,
                CURLOPT_HTTPHEADER     => [
                    'Accept: application/json, text/plain, */*',
                    'Origin: ' . (defined('LE_UPSTREAM_BASE') ? rtrim((string)LE_UPSTREAM_BASE, '/') : ''),
                    'Referer: ' . (defined('LE_UPSTREAM_BASE') ? rtrim((string)LE_UPSTREAM_BASE, '/') . '/' : ''),
                    'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36',
                ],
            ]);
            $b = @curl_exec($ch);
            $out['how']  = 'curl';
            $out['code'] = (int)@curl_getinfo($ch, CURLINFO_HTTP_CODE);
            $out['err']  = (string)@curl_error($ch);
            if (is_string($b)) $out['body'] = $b;
            @curl_close($ch);
            return $out;
        }
    }
    if ((bool)ini_get('allow_url_fopen')) {
        $ctx = @stream_context_create([
            'http' => ['method' => 'GET', 'timeout' => $timeout, 'ignore_errors' => true],
            'ssl'  => ['verify_peer' => false, 'verify_peer_name' => false],
        ]);
        $b = @file_get_contents($url, false, $ctx);
        $out['how'] = 'file_get_contents';
        if (is_string($b)) $out['body'] = $b;
        $out['code'] = 200;
        return $out;
    }
    $out['err'] = 'curl AND allow_url_fopen dono band hain';
    return $out;
}

if ($base === '') {
    echo "LE_UPSTREAM_BASE set nahi hai — aage kuch check nahi ho sakta.\n";
    exit;
}

// ------------------------------------------------------------------ B
echo "[B] CURRENT ISSUE — upstream vs local (bina cache ke)\n";
foreach ($games as $g) {
    $url = $base . '/webapi/kv/issue/' . rawurlencode($g);
    $r   = up_raw($url);
    echo "  --- $g ---\n";
    echo '      URL    : ' . $url . "\n";
    echo '      via    : ' . $r['how'] . '   http=' . $r['code'] . ($r['err'] !== '' ? '   err=' . $r['err'] : '') . "\n";
    echo '      body   : ' . (trim($r['body']) === '' ? '(khali)' : substr(preg_replace('/\s+/', ' ', $r['body']), 0, 400)) . "\n";
    $j = json_decode($r['body'], true);
    $ui = '';
    if (is_array($j)) {
        $d = $j['data'] ?? null;
        if (is_array($d)) {
            $ui = trim((string)($d['issueNumber'] ?? $d['issueNo'] ?? $d['issue'] ?? $d['period'] ?? ''));
            echo '      upstream -> issueNumber=' . $ui
                 . '  start=' . ($d['startTime'] ?? '-')
                 . '  end=' . ($d['endTime'] ?? '-')
                 . '  countdown=' . ($d['countdown'] ?? '-') . "\n";
        }
    }
    // /webapi/kv/issue is bucket par 404 hai — tab upstream ki SABSE NAYI
    // history row (= current period) use karo.
    if ($ui === '' && function_exists('le_upstream_newest')) {
        $nr = le_upstream_newest($g);
        if (is_array($nr)) {
            $ui = trim((string)($nr['issueNumber'] ?? $nr['issueNo'] ?? $nr['period'] ?? ''));
            if ($ui !== '') echo '      upstream -> NEWEST HISTORY ROW issueNumber=' . $ui . "\n";
        }
    }
    $loc = function_exists('lottery_issue') ? lottery_issue($g) : null;
    $li  = is_array($loc) ? (string)$loc['issueNumber'] : '-';
    echo '      local    -> issueNumber=' . $li . "\n";
    $shift = function_exists('le_period_shift') ? le_period_shift() : 0;
    $exp   = ($ui !== '' && function_exists('le_issue_add')) ? (string)le_issue_add($ui, $shift) : '';
    echo '      expected  -> (API ' . ($shift <= 0 ? (string)$shift : '+' . $shift) . ' period) issueNumber=' . ($exp !== '' ? $exp : '-') . "\n";
    echo '      MATCH?   : ' . (($exp !== '' && $exp === $li) ? 'YES  (site = API ' . $shift . ' period)' : ($ui === '' ? 'UPSTREAM SE JAWAB NAHI MILA' : 'NO   (abhi bhi alag)')) . "\n\n";
}

// ------------------------------------------------------------------ C
echo "[C] HISTORY (GetHistoryIssuePage.json) — upstream vs local\n";
foreach ($games as $g) {
    $fam = function_exists('le_upstream_family') ? le_upstream_family($g) : 'WinGo';
    $url = $base . '/' . $fam . '/' . rawurlencode($g) . '/GetHistoryIssuePage.json?pageNo=1&pageSize=10';
    $r   = up_raw($url);
    echo "  --- $g ---\n";
    echo '      URL    : ' . $url . "\n";
    echo '      via    : ' . $r['how'] . '   http=' . $r['code'] . ($r['err'] !== '' ? '   err=' . $r['err'] : '') . "\n";
    $j = json_decode($r['body'], true);
    $rows = (is_array($j) && isset($j['data']['list']) && is_array($j['data']['list'])) ? $j['data']['list'] : [];
    if (!$rows) {
        echo '      body   : ' . (trim($r['body']) === '' ? '(khali)' : substr(preg_replace('/\s+/', ' ', $r['body']), 0, 300)) . "\n";
    }
    foreach (array_slice($rows, 0, 4) as $i => $row) {
        $num = trim((string)($row['issueNumber'] ?? $row['issueNo'] ?? $row['period'] ?? ''));
        $res = (string)($row['premium'] ?? $row['number'] ?? '');
        echo '      up row' . $i . ' : ' . $num . '   result=' . $res . "\n";
    }
    if (function_exists('le_history_page')) {
        $p = le_history_page($g, 1, 10);
        foreach (array_slice($p['list'], 0, 4) as $i => $row) {
            echo '      local row' . $i . ' : ' . $row['issueNumber'] . '   result=' . $row['number'] . "\n";
        }
    }
    echo "\n";
}

// ------------------------------------------------------------------ D
echo "[D] DATE / TIMEZONE — API ki date kis hisaab se banti hai?\n";
echo '    PHP timezone      : ' . date('T') . "\n";
echo '    abhi site ka samay: ' . date('Y-m-d H:i:s') . ' ' . date('T') . "\n";
echo '    abhi UTC samay    : ' . gmdate('Y-m-d H:i:s') . ' UTC' . "\n";
echo '    LE_ISSUE_DATE_TZ  : ' . (defined('LE_ISSUE_DATE_TZ') ? LE_ISSUE_DATE_TZ : '<< NOT DEFINED >>') . "\n";
foreach ($games as $g) {
    $fam = function_exists('le_upstream_family') ? le_upstream_family($g) : 'WinGo';
    $url = $base . '/' . $fam . '/' . rawurlencode($g) . '/GetHistoryIssuePage.json?pageNo=1&pageSize=10';
    $r   = up_raw($url);
    $j   = json_decode($r['body'], true);
    $rows = (is_array($j) && isset($j['data']['list']) && is_array($j['data']['list'])) ? $j['data']['list'] : [];
    echo "  --- $g ---\n";
    if (!isset($rows[0])) { echo "      API se row nahi mili (http=" . $r['code'] . ")\n"; continue; }
    $row = $rows[0];
    $num = trim((string)($row['issueNumber'] ?? $row['issueNo'] ?? $row['period'] ?? ''));
    echo '      API row0 issueNumber : ' . $num . "\n";
    // API ki list me openTime nahi milta (0 aata hai). Isliye date ko
    // "aaj ki UTC date" aur "aaj ki site-TZ date" se compare karte hain —
    // API ki row0 hamesha ABHI chal raha period hoti hai.
    $uToday = gmdate('Ymd');
    $sToday = date('Ymd');
    echo '      API row0 ki date     : ' . substr($num, 0, 8) . "\n";
    echo '      aaj UTC ki date      : ' . $uToday . "\n";
    echo '      aaj site TZ ki date  : ' . $sToday . "\n";
    if ($uToday === $sToday) {
        echo '      SAMAN? : abhi UTC aur site TZ EK HI din hain — subah 00:00-05:30\n';
        echo '               IST ke beech dobara chala kar confirm kar lena.\n';
    } else {
        echo '      SAMAN? : ' . (substr($num, 0, 8) === $uToday
                ? 'UTC   (LE_ISSUE_DATE_TZ = utc SAHI hai)'
                : (substr($num, 0, 8) === $sToday
                    ? 'SITE TZ  (LE_ISSUE_DATE_TZ = local chahiye)' : 'DONO SE ALAG <<<')) . "\n";
    }
}
echo "\n";

echo $line . "\n";
echo "END. Is page ka output developer ko bhej do. Kaam ho jane par delete kar dena.\n";
