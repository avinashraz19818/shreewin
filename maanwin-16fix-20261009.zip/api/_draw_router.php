<?php
require_once __DIR__ . '/_core/bootstrap.php';

$gameCode = $_GET['gameCode'] ?? '';
$path = $_GET['path'] ?? '';

if (!$gameCode && $path) {
    $parts = explode('/', trim($path, '/'));
    // /WinGo/WinGo_30S.json OR /WinGo/WinGo_30S/GetHistoryIssuePage.json
    $gameCode = $parts[1] ?? ($parts[0] ?? 'WinGo_30S');
}
$gameCode = preg_replace('/\.json$/i', '', $gameCode ?: 'WinGo_30S');
$gameCode = preg_replace('/[^A-Za-z0-9_]/', '', $gameCode ?: 'WinGo_30S');

if (str_contains($path, 'GetHistoryIssuePage')) {
    le_settle_pending_bets($gameCode);
    $pageNo = max(1, (int)($_GET['pageNo'] ?? $_GET['page'] ?? 1));
    $set = site_settings();
    $pageSize = max(1, min(10, (int)($set['game_history_page_size'] ?? 10)));
    // FIX #8: bilkul WAHII list jo /api/Lottery/GetHistoryIssuePage deta hai.
    // Drawer aur game JSON ab EK hi function (le_history_page) se bante hain.
    $page = le_history_page($gameCode, $pageNo, $pageSize);
    api_success(['list'=>$page['list'],'pageNo'=>$page['pageNo'],'pageSize'=>$page['pageSize'],'totalPage'=>999,'totalCount'=>9990], 'Succeed', ['serviceTime'=>now_ms()]);
}

// /webapi/kv/issue/WinGo_30S and /WinGo/WinGo_30S.json dono same response denge.
api_success(lottery_issue($gameCode));
