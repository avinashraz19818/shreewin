const o=`<svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 22 22" fill="none">
  <circle cx="11" cy="11" r="10.5" fill="var(--main_color)" stroke="var(--secondary_color4)"/>
</svg>`;export{o as default};
