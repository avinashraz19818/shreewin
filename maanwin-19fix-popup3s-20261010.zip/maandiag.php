<?php
/**
 * maandiag.php — maanwin DIAGNOSTIC (plain text)
 * ==============================================
 * Browser me kholo:  https://maanwin.club9.eu.cc/maandiag.php
 *
 * Ye page kuch BHI change nahi karta — sirf live server ki asli information
 * print karta hai (period numbers, result, functions ka source).
 * Diagnostic complete hone ke baad is file ko DELETE kar dena.
 */
header('Content-Type: text/plain; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');

try {
    require_once __DIR__ . '/api/_core/bootstrap.php';
} catch (Throwable $e) {
    echo "BOOTSTRAP LOAD FAIL: " . $e->getMessage() . "\n";
    exit;
}

$game = 'WinGo_30S';
$line = str_repeat('=', 78);

echo $line . "\n";
echo "MAANWIN DIAGNOSTIC   " . date('Y-m-d H:i:s T') . "   host=" . ($_SERVER['HTTP_HOST'] ?? '') . "\n";
echo $line . "\n\n";

// ------------------------------------------------------------------ 1
echo "[1] PATCH APPLIED?  (4-fix + fix#5)\n";
foreach (['LE_INSTANT_SETTLEMENT', 'LE_TIMER_LEAD_MS', 'LE_REVEAL_AT_COUNTDOWN',
          'LE_TAX_PERCENT', 'LE_ORDER_NO', 'AR_PERIOD_SHIFT'] as $c) {
    echo '    ' . str_pad($c, 26) . ' : ' . (defined($c) ? var_export(constant($c), true) : '<< NOT DEFINED >>') . "\n";
}
echo '    ' . str_pad('le_issue_prev()', 26) . ' : ' . (function_exists('le_issue_prev') ? 'present' : 'MISSING') . "\n";
echo '    ' . str_pad('le_issue_sequence()', 26) . ' : ' . (function_exists('le_issue_sequence') ? 'present' : 'MISSING') . "\n";
echo '    ' . str_pad('le_history_start_offset()', 26) . ' : ' . (function_exists('le_history_start_offset') ? 'present' : 'MISSING') . "\n";
echo '    ' . str_pad('le_bet_period_is_closed()', 26) . ' : ' . (function_exists('le_bet_period_is_closed') ? 'present' : 'MISSING') . "\n";
echo '    ' . str_pad('le_issue_for_time()', 26) . ' : ' . (function_exists('le_issue_for_time') ? 'present' : 'MISSING') . "\n";
echo '    ' . str_pad('le_history_page()', 26) . ' : ' . (function_exists('le_history_page') ? 'present' : 'MISSING') . "\n";
echo "\n";

// ------------------------------------------------------------------ 2
echo "[2] CURRENT ISSUE (lottery_issue)  — WinGo_30S AUR WinGo_1M dono\n";
echo "    (do alag host ek hi DB share karte hain; in dono game ke period\n";
echo "     number compare kar ke pata chalta hai ki kaunsa build chal raha hai)\n";
foreach (['WinGo_30S', 'WinGo_1M'] as $g) {
    echo "  --- $g ---\n";
    $iss = function_exists('lottery_issue') ? lottery_issue($g) : null;
    if (!$iss) { echo "      (lottery_issue nahi mila)\n"; continue; }
    foreach (['startTime', 'endTime', 'issueNumber', 'intervalMinute', 'intervalSecond', 'countdown', 'currentTime'] as $k) {
        echo '      ' . str_pad($k, 16) . ' : ' . (isset($iss[$k]) ? $iss[$k] : '-') . "\n";
    }
    $interval = function_exists('le_game_interval') ? le_game_interval($g) : 0;
    $span = (int)round((((int)$iss['endTime']) - ((int)$iss['startTime'])) / 1000);
    $okTimer = ($interval > 0 && $span === $interval - 1);
    echo '      ' . str_pad('end-start(sec)', 16) . ' : ' . $span . ' / interval ' . $interval
         . ($okTimer ? '   (=> TIMER FIX ACTIVE, 1 sec kam)' : '   (=> TIMER FIX NOT ACTIVE)') . "\n";
}
echo '    ' . str_pad('reveal now?', 22) . ' : ' . (function_exists('le_should_reveal_current') ? (le_should_reveal_current($game) ? 'YES' : 'no') : 'n/a') . '   (game=' . $game . ")\n";
echo '    ' . str_pad('start offset', 22) . ' : ' . (function_exists('le_history_start_offset') ? le_history_start_offset($game) : 'n/a') . "\n";
echo "\n";

// ------------------------------------------------------------------ 3
echo "[3] le_issue_by_offset()  RAW  (offset 0..12)\n";
$raw = [];
for ($k = 0; $k <= 12; $k++) {
    $raw[$k] = (string)le_issue_by_offset($game, $k);
    echo '    offset ' . str_pad((string)$k, 3) . ' : ' . $raw[$k] . "\n";
}
$mono = true;
for ($k = 1; $k <= 12; $k++) {
    if (substr($raw[$k], -5) !== str_pad((string)(((int)substr($raw[$k - 1], -5)) - 1), 5, '0', STR_PAD_LEFT)) {
        $mono = false;
        echo "    ^^ BREAK at offset $k (expected " . (((int)substr($raw[$k - 1], -5)) - 1) . ", got " . substr($raw[$k], -5) . ")\n";
    }
}
echo '    CONSECUTIVE? : ' . ($mono ? 'YES' : 'NO  <<< YAHI "period/result dusra-dusra" KI WAJAH HAI') . "\n";
echo "\n";

// ------------------------------------------------------------------ 4
echo "[4] FIXED SEQUENCE (le_issue_sequence)\n";
if (function_exists('le_issue_sequence')) {
    foreach ([1, 0] as $so) {
        echo "    startOffset=$so :\n";
        $seq = le_issue_sequence($game, $so, 10);
        foreach ($seq as $i => $s) {
            echo '        row ' . str_pad((string)$i, 2) . ' : ' . $s
                 . '   result=' . (function_exists('le_result_for_issue') ? (string)(le_result_for_issue($game, (string)$s, true)['number'] ?? '-') : '-') . "\n";
        }
    }
} else {
    echo "    le_issue_sequence() MISSING\n";
}
echo "\n";

// ------------------------------------------------------------------ 5
echo "[5] LIVE SOURCE — le_issue_by_offset / lottery_issue\n";
foreach (['le_issue_by_offset', 'lottery_issue', 'le_issue_prev', 'le_issue_sequence'] as $fn) {
    echo "  --- function $fn() ---\n";
    if (!function_exists($fn)) { echo "      (not defined)\n"; continue; }
    try {
        $rf = new ReflectionFunction($fn);
        $file = $rf->getFileName();
        $s = $rf->getStartLine();
        $e = $rf->getEndLine();
        echo '      file: ' . $file . '  lines ' . $s . '-' . $e . "\n";
        if ($file && is_readable($file)) {
            $lines = file($file);
            for ($i = $s - 1; $i < $e && $i < count($lines); $i++) {
                echo '      ' . str_pad((string)($i + 1), 4) . ' | ' . rtrim($lines[$i], "\r\n") . "\n";
            }
        }
    } catch (Throwable $ex) {
        echo '      reflection fail: ' . $ex->getMessage() . "\n";
    }
}
echo "\n";

// ------------------------------------------------------------------ 6
echo "[6] LAST 10 BETS\n";
try {
    $conn = db();
    if (!$conn) {
        echo "    DB connect fail\n";
    } else {
        $rs = @$conn->query('SELECT id,user_id,order_no,game_code,issue_number,amount,bet_multiple,real_amount,fee,premium,state,win_lose_amount,created_at FROM lottery_bets ORDER BY id DESC LIMIT 10');
        if (!$rs) {
            echo '    query fail: ' . $conn->error . "\n";
        } else {
            while ($r = $rs->fetch_assoc()) {
                printf("    id=%-6s uid=%-8s order=%s(len %d)  %s  issue=%s  amt=%s real=%s fee=%s  state=%s  wl=%s  prem=%s  %s\n",
                    $r['id'], $r['user_id'], $r['order_no'], strlen((string)$r['order_no']),
                    $r['game_code'], $r['issue_number'], $r['amount'], $r['real_amount'],
                    $r['fee'], $r['state'], $r['win_lose_amount'], $r['premium'], $r['created_at']);
            }
        }
        $rs2 = @$conn->query("SHOW COLUMNS FROM lottery_bets LIKE 'fee'");
        echo '    fee column: ' . ($rs2 && $rs2->num_rows ? 'yes' : 'NO') . "\n";
    }
} catch (Throwable $e) {
    echo '    ' . $e->getMessage() . "\n";
}
echo "\n";

// ------------------------------------------------------------------ 7
echo "[7] lottery_results — last 8 rows\n";
try {
    $conn = db();
    if ($conn) {
        $rs = @$conn->query('SELECT game_code,issue_number,premium,number,created_at FROM lottery_results ORDER BY id DESC LIMIT 8');
        if ($rs) {
            while ($r = $rs->fetch_assoc()) {
                printf("    %s  %s  premium=%s  number=%s  %s\n", $r['game_code'], $r['issue_number'], $r['premium'], $r['number'], $r['created_at']);
            }
        } else {
            echo '    ' . $conn->error . "\n";
        }
    }
} catch (Throwable $e) {
    echo '    ' . $e->getMessage() . "\n";
}

// ------------------------------------------------------------------ 8
echo "[8] TAX MODEL / SETTLEMENT CHECK  (FIX #6)\n";
try {
    $conn = db();
    if ($conn) {
        $rs = @$conn->query('SELECT id,order_no,game_code,issue_number,amount,bet_multiple,real_amount,fee,state,win_lose_amount FROM lottery_bets ORDER BY id DESC LIMIT 12');
        if ($rs) {
            while ($r = $rs->fetch_assoc()) {
                $o = (string)$r['order_no'];
                $s = (float)$r['real_amount'];
                $f = (float)$r['fee'];
                $disp = function_exists('le_is_display_only_tax') ? le_is_display_only_tax($o, $s, $f) : true;
                $db   = function_exists('le_settle_debit') ? le_settle_debit($o, $s, $f) : round($s + $f, 2);
                $real = $disp ? round(max(0, $s - $f), 2) : round($s, 2);
                printf("    id=%-6s %-32s model=%-14s stake=%-10s fee=%-8s debit=%-10s showAfterTax=%-10s state=%s wl=%s\n",
                    $r['id'], $o . ' (len ' . strlen($o) . ')',
                    $disp ? 'NEW(display)' : 'OLD(real fee)',
                    number_format($s, 2, '.', ''), number_format($f, 2, '.', ''),
                    number_format($db, 2, '.', ''), number_format($real, 2, '.', ''),
                    $r['state'], $r['win_lose_amount']);
            }
        } else {
            echo '    ' . $conn->error . "\n";
        }
    }
} catch (Throwable $e) {
    echo '    ' . $e->getMessage() . "\n";
}

// ------------------------------------------------------------------ 9
echo "[9] FIX #8 — GAME SCREEN vs DRAWER  (ek hi period number?)\n";
echo "    Yahi wo jagah hai jahan 'drawer ka result' aur 'game ka result'\n";
echo "    alag-alag dikhte the. Ab dono ko BARABAR hona chahiye.\n";
foreach (['WinGo_30S', 'WinGo_1M', 'WinGo_3M', 'WinGo_5M'] as $g) {
    $a  = function_exists('lottery_issue') ? lottery_issue($g) : null;
    $ai = is_array($a) ? (string)$a['issueNumber'] : '-';
    $bi = function_exists('le_issue_by_offset') ? (string)le_issue_by_offset($g, 0) : '-';
    echo "  --- $g ---\n";
    echo '      game screen (lottery_issue)   : ' . $ai . "\n";
    echo '      drawer/trend (le_issue_by_off): ' . $bi . "\n";
    echo '      MATCH? : ' . ($ai === $bi ? 'YES   (fix #8 OK)' : 'NO  <<< YAHI "dono alag" KI WAJAH HAI') . "\n";
}
echo "\n";
echo "    NAYA CHECK — dono endpoint ki PEHLI row bhi same honi chahiye:\n";
if (function_exists('le_history_page')) {
    $p1 = le_history_page('WinGo_30S', 1, 3);
    foreach ($p1['list'] as $i => $row) {
        echo '      row' . $i . ' : ' . $row['issueNumber'] . '  number=' . $row['number'] . "\n";
    }
} else {
    echo "      le_history_page() MISSING\n";
}
echo "\n";

// ------------------------------------------------------------------ 10
echo "[10] FIX #9 — UPSTREAM (draw.ar-lottery01.com) MIRROR\n";
echo '    LE_UPSTREAM_RESULTS : ' . (defined('LE_UPSTREAM_RESULTS') ? var_export(LE_UPSTREAM_RESULTS, true) : 'NOT DEFINED') . "\n";
echo '    LE_UPSTREAM_BASE    : ' . (defined('LE_UPSTREAM_BASE') ? LE_UPSTREAM_BASE : 'NOT DEFINED') . "\n";
echo '    curl available      : ' . (function_exists('curl_init') ? 'yes' : 'NO') . "\n";
echo '    allow_url_fopen     : ' . var_export((bool)ini_get('allow_url_fopen'), true) . "\n";
if (function_exists('le_upstream_get')) {
    foreach (['WinGo_30S', 'WinGo_1M'] as $g) {
        $up = function_exists('le_upstream_issue') ? le_upstream_issue($g) : null;
        $loc = lottery_issue($g);
        $ui = is_array($up) ? trim((string)($up['issueNumber'] ?? '')) : '';
        $li = (string)$loc['issueNumber'];
        echo "  --- $g ---\n";
        echo '      upstream issue : ' . ($ui !== '' ? $ui : '<< UPSTREAM SE JAWAB NAHI MILA >>') . "\n";
        echo '      game  issue    : ' . $li . "\n";
        echo '      MATCH? : ' . (($ui !== '' && $ui === $li) ? 'YES  (drawer = game)' : 'NO   (abhi bhi alag)') . "\n";
    }
} else {
    echo "    le_upstream_get() MISSING — fix #9 laga nahi hai\n";
}
echo "    (poori detail ke liye /maanupdiag.php kholo)\n";
echo "\n";

// ------------------------------------------------------------------ 11
echo "[11] FIX #12 — SITE API SE KITNE PERIOD PICHE  (PERIOD + RESULT DONO)\n";
echo '    LE_PERIOD_SHIFT : ' . (defined('LE_PERIOD_SHIFT') ? (string)LE_PERIOD_SHIFT : '<< NOT DEFINED >>') . "\n";
echo '    LE_RESULT_SHIFT : ' . (defined('LE_RESULT_SHIFT') ? (string)LE_RESULT_SHIFT : '<< NOT DEFINED >>') . "\n";
echo "    0  = site ka current period == API ka asli current period (DEFAULT)\n";
echo "    -1 = site API se 1 period piche\n";
echo "    RESULT hamesha USI period ka hota hai jiske sath dikhta hai.\n";
foreach (['WinGo_30S', 'WinGo_1M'] as $g) {
    $iss = function_exists('lottery_issue') ? lottery_issue($g) : null;
    if (!is_array($iss)) continue;
    $cur = (string)$iss['issueNumber'];
    $r   = le_result_for_issue($g, $cur, false);
    $upNew = function_exists('le_upstream_newest') ? le_upstream_newest($g) : null;
    $upN   = is_array($upNew) ? trim((string)($upNew['issueNumber'] ?? '')) : '';
    $upRes = function_exists('le_upstream_result_for') ? le_upstream_result_for($g, $cur) : '';
    if ($upRes === '') $upRes = '-';
    echo "  --- $g ---\n";
    echo '      API ka naya period     : ' . ($upN !== '' ? $upN : '-') . "\n";
    echo '      site ka period         : ' . $cur . "\n";
    echo '      site par dikhne wala   : ' . (string)$r['number'] . "\n";
    echo '      API me usi period ka   : ' . $upRes . "\n";
    echo '      JODI SAHI? : ' . ($upRes !== '-' && (string)$r['number'] === $upRes
            ? 'YES  (period + result DONO API wale)' : 'NO  (API me nahi mila)') . "\n";
}
echo "\n";

// ------------------------------------------------------------------ 12
echo "[12] FIX #13 — GAME vs API (json wala URL) — PERIOD AUR RESULT DONO\n";
echo '    LE_ISSUE_DATE_TZ : ' . (defined('LE_ISSUE_DATE_TZ') ? LE_ISSUE_DATE_TZ : '<< NOT DEFINED >>') . "\n";
echo '    LE_UPSTREAM_PAGES: ' . (defined('LE_UPSTREAM_PAGES') ? (string)LE_UPSTREAM_PAGES : '<< NOT DEFINED >>') . "\n";
echo '    server timezone  : ' . date('T') . '   abhi ' . date('Y-m-d H:i:s') . '  |  UTC ' . gmdate('Y-m-d H:i:s') . "\n";
foreach (['WinGo_30S', 'WinGo_1M'] as $g) {
    $iss = function_exists('lottery_issue') ? lottery_issue($g) : null;
    if (!is_array($iss)) continue;
    $cur = (string)$iss['issueNumber'];
    echo "  --- $g ---\n";
    $upNew = function_exists('le_upstream_newest') ? le_upstream_newest($g) : null;
    $upN   = is_array($upNew) ? trim((string)($upNew['issueNumber'] ?? '')) : '';
    echo '      API ka naya period (row0) : ' . ($upN !== '' ? $upN : '-') . "\n";
    echo '      site ka period            : ' . $cur . "\n";
    $same = 0; $tot = 0;
    if (function_exists('le_history_page')) {
        $hp = le_history_page($g, 1, 5);
        foreach ($hp['list'] as $i => $row) {
            $num = (string)$row['issueNumber'];
            $up  = function_exists('le_upstream_result_for') ? le_upstream_result_for($g, $num) : '';
            $tot++;
            $hit = ($up !== '' && $up === (string)$row['number']);
            if ($hit) $same++;
            echo '      row' . $i . ' : site ' . $num . ' = ' . (string)$row['number']
                 . '   |   API ' . ($up !== '' ? $up : '<< nahi mila >>')
                 . '   ' . ($hit ? 'SAME' : 'ALAG <<<') . "\n";
        }
    }
    echo '      NATIJA : ' . $same . '/' . $tot . ' row API se mile'
         . ($same === $tot && $tot > 0 ? '  => SAB API WALE (theek)' : '  => GADBAD HAI') . "\n";
}
echo "\n";

// ------------------------------------------------------------------ 13
echo "[13] PERIOD KITNA PICHE?  — EK HI JAGAH POORA HISAAB\n";
echo '    LE_PERIOD_SHIFT       : ' . (defined('LE_PERIOD_SHIFT') ? (string)LE_PERIOD_SHIFT : '<< NOT DEFINED >>') . "\n";
echo '    LE_REVEAL_AT_COUNTDOWN: ' . (defined('LE_REVEAL_AT_COUNTDOWN') ? (string)LE_REVEAL_AT_COUNTDOWN : '<< NOT DEFINED >>') . "\n";
echo '    LE_RESULT_SHIFT       : ' . (defined('LE_RESULT_SHIFT') ? (string)LE_RESULT_SHIFT : '<< NOT DEFINED >>') . "\n";
echo '    server time           : ' . date('Y-m-d H:i:s') . ' ' . date('T') . '   (UTC ' . gmdate('Y-m-d H:i:s') . ")\n";
foreach (['WinGo_30S', 'WinGo_1M', 'WinGo_3M', 'WinGo_5M'] as $g) {
    $iss = function_exists('lottery_issue') ? lottery_issue($g) : null;
    if (!is_array($iss)) continue;
    $cur = (string)$iss['issueNumber'];
    $upNew = function_exists('le_upstream_newest') ? le_upstream_newest($g) : null;
    $upN   = is_array($upNew) ? trim((string)($upNew['issueNumber'] ?? '')) : '';
    $upR0  = is_array($upNew) ? (string)($upNew['premium'] ?? $upNew['number'] ?? '-') : '-';
    echo "  --- $g ---\n";
    echo '      API row0 (abhi chal raha)  : ' . ($upN !== '' ? $upN : '-') . '   result=' . $upR0 . "\n";
    echo '      site ka CURRENT period     : ' . $cur . "\n";
    $lag = '-';
    if ($upN !== '') {
        $a = (int)substr($upN, -5);
        $b = (int)substr($cur, -5);
        $d = $a - $b;                       // + => site API se itne piche
        if ($d > 50000)  $d -= 100000;
        if ($d < -50000) $d += 100000;
        $lag = $d;
    }
    echo '      => site CURRENT period API se ' . ($lag === '-' ? '-' : (string)$lag . ' PERIOD PICHE')
         . ($lag === 0 ? '   (BARABAR)' : '') . "\n";
    if (function_exists('le_history_page')) {
        $hp = le_history_page($g, 1, 3);
        if (isset($hp['list'][0])) {
            $r0 = $hp['list'][0];
            $num = (string)$r0['issueNumber'];
            $up  = function_exists('le_upstream_result_for') ? le_upstream_result_for($g, $num) : '';
            echo '      site ki LIST ki pehli row  : ' . $num . '   result=' . (string)$r0['number'] . "\n";
            echo '      API me USI period ka       : ' . ($up !== '' ? $up : '<< nahi mila >>')
                 . '   ' . ($up !== '' && $up === (string)$r0['number'] ? 'SAME  (jodi sahi)' : 'ALAG <<<') . "\n";
        }
    }
    if ($upN !== '' && function_exists('le_issue_add')) {
        echo '      --- agar aapko aur piche chahiye to ---' . "\n";
        foreach ([-1, -2] as $s) {
            echo '          LE_PERIOD_SHIFT = ' . $s . '  ->  site ka period ' . (string)le_issue_add($upN, $s) . "\n";
        }
    }
    echo "\n";
}

// ------------------------------------------------------------------ 14
echo "[14] FIX #15 — BET KA TIME 1 SECOND PICHE  +  POPUP TIMER 0 PAR\n";
$btl = function_exists('le_bet_time_lead') ? le_bet_time_lead() : 0;
echo '    LE_BET_TIME_LEAD_SEC  : ' . (string)$btl . ' second' . ($btl >= 60 ? '   (= ' . ($btl / 60) . ' MINUTE)' : '') . "\n";
echo '    LE_UPSTREAM_CACHE_SEC : ' . (defined('LE_UPSTREAM_CACHE_SEC') ? (string)LE_UPSTREAM_CACHE_SEC . ' second' : '<< NOT DEFINED >>')
     . "   (3 tha -> popup 5 sec late; ab 15)\n";
echo '    LE_REVEAL_AT_COUNTDOWN: ' . (defined('LE_REVEAL_AT_COUNTDOWN') ? (string)LE_REVEAL_AT_COUNTDOWN : '<< NOT DEFINED >>')
     . "   (row is countdown par aa jati hai -> 0 par popup turant)\n";
if (function_exists('db')) {
    $conn = db();
    if ($conn) {
        $rs = @$conn->query('SELECT id, order_no, game_code, created_at FROM lottery_bets ORDER BY id DESC LIMIT 3');
        if ($rs) {
            echo "    PICHLE 3 BET — DB ka asli time  vs  app me dikhne wala time\n";
            while ($r = $rs->fetch_assoc()) {
                $real = strtotime((string)$r['created_at']);
                if ($real === false || $real <= 0) continue;
                $shown = $real - (function_exists('le_bet_time_lead') ? le_bet_time_lead() : 0);
                echo '      id=' . str_pad((string)$r['id'], 6) . ' ' . str_pad((string)$r['game_code'], 10)
                     . ' DB: ' . date('Y-m-d H:i:s', $real)
                     . '   ->  app me: ' . date('Y-m-d H:i:s', $shown) . "\n";
            }
        }
    }
}
echo "    (farq sirf DIKHANE me hai — DB me asli time hi rehta hai)\n";
echo "\n";

// ------------------------------------------------------------------ 15
echo "[15] STABILITY — period / result apne aap to nahi badalte?\n";
echo '    LE_UPSTREAM_CACHE_SEC : ' . (defined('LE_UPSTREAM_CACHE_SEC') ? (string)LE_UPSTREAM_CACHE_SEC . ' second' : '<< NOT DEFINED >>') . "\n";
echo "    (drift ab hamesha FRESH data se banta hai, result miss hone par\n";
echo "     page 1 force-fetch hota hai — isliye random result nahi banta)\n";
foreach (['WinGo_30S', 'WinGo_1M', 'WinGo_3M', 'WinGo_5M'] as $g) {
    $iss = function_exists('lottery_issue') ? lottery_issue($g) : null;
    if (!is_array($iss)) continue;
    $cur = (string)$iss['issueNumber'];
    $a = le_result_for_issue($g, $cur, false);
    $b = le_result_for_issue($g, $cur, false);
    $c = le_result_for_issue($g, $cur, false);
    $same = ((string)$a['number'] === (string)$b['number'] && (string)$b['number'] === (string)$c['number']);
    $dbnum = '-';
    if (function_exists('db')) {
        $cn = db();
        if ($cn) {
            $st = @$cn->prepare('SELECT premium FROM lottery_results WHERE game_code=? AND issue_number=? LIMIT 1');
            if ($st) { $st->bind_param('ss', $g, $cur); if ($st->execute()) { $rr = $st->get_result()->fetch_assoc(); if ($rr) $dbnum = (string)$rr['premium']; } }
        }
    }
    $age = -1;
    if (function_exists('le_upstream_cache_file') && function_exists('le_upstream_family') && function_exists('le_upstream_base')) {
        $u = le_upstream_base() . '/' . le_upstream_family($g) . '/' . rawurlencode($g) . '/GetHistoryIssuePage.json?pageNo=1&pageSize=10';
        $f = le_upstream_cache_file(md5($u));
        if (is_file($f)) $age = time() - (int)@filemtime($f);
    }
    $drift = function_exists('le_issue_drift') ? (int)le_issue_drift($g) : 0;
    echo "  --- $g ---\n";
    echo '      site ka period       : ' . $cur . "\n";
    echo '      API cache ki umar   : ' . ($age < 0 ? '-' : $age . ' second') . "\n";
    echo '      result 3 baar manga : ' . (string)$a['number'] . ' / ' . (string)$b['number'] . ' / ' . (string)$c['number'] . "\n";
    echo '      DB me pada hua      : ' . $dbnum . "\n";
    echo '      drift               : ' . (string)$drift . "\n";
    echo '      STABLE? : ' . ($same && $dbnum === (string)$a['number'] && $drift === 0
        ? 'YES  (period + result DONO pakke)' : 'NO  <<< yahi "apne aap badal jata hai"') . "\n";
}
echo "\n";

echo "[16] WIN / LOSS POPUP — timer 0 se kitne second PEHLE call hota hai\n";
echo "    (FIX #19: chain 3 second pehle shuru; chain ki apni delay 3000 ms\n";
echo "     hai, isliye popup screen ke timer 0 par dikhta hai)\n";
$jsDir  = __DIR__ . '/assets/js';
$jsList = @glob($jsDir . '/useWinGo3*.js');
if (!$jsList) {
    echo "    KOI assets/js/useWinGo3*.js NAHI MILA — popup wali JS is docroot me nahi hai.\n";
} else {
    foreach ($jsList as $jf) {
        $src  = @file_get_contents($jf);
        $name = basename($jf);
        if ($src === false || $src === '') { echo "  --- $name --- (padha nahi ja saka)\n"; continue; }
        $lead = null;
        if (preg_match('/const\s+PLD\s*=\s*(\d+)\s*;/', $src, $m1)) $lead = (int)$m1[1];
        $usesLead = (strpos($src, 'e==PLD){await') !== false);
        $oldTrig  = (strpos($src, 'e==1){await') !== false);
        $refresh  = (strpos($src, 'try{await N()}catch{}await Te()') !== false);
        $retry    = (strpos($src, 'qN<3;qN++') !== false);
        echo "  --- $name ---\n";
        echo '      PLD (popup lead)       : ' . ($lead === null ? '<< NAHI MILA (purani file) >>' : $lead . ' second') . "\n";
        echo '      trigger                : ' . ($usesLead ? 'countdown == PLD  (NAYA)' : ($oldTrig ? 'countdown == 1  (PURANA)' : 'pehchaan nahi')) . "\n";
        echo '      popup se pehle refresh : ' . ($refresh ? 'YES (result row pakki)' : 'NO') . "\n";
        echo '      result late to retry   : ' . ($retry ? 'YES (3 tries, 1.2 sec gap)' : 'NO') . "\n";
        echo '      POPUP KAB              : ' . ($lead !== null ? ('chain screen timer ' . $lead . ' par shuru -> popup ~timer 0 par') : 'pata nahi') . "\n";
        echo '      THEEK HAI?             : ' . (($lead === 3 && $usesLead && $refresh && $retry)
                ? "YES  (FIX #19 LAGA HUA HAI)" : "NO  <<< 19fix extract nahi hua ya purani file") . "\n";
    }
}
echo "\n";

echo "\n" . $line . "\n";
echo "END. Is file ko ab delete kar dena.\n";
