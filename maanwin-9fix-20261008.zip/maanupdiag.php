<?php
/**
 * maanupdiag.php — UPSTREAM DIAGNOSTIC (plain text)
 * ==================================================
 * Browser me kholo:  https://<site>/maanupdiag.php
 *
 * Ye page kuch BHI change nahi karta. Sirf ye batata hai:
 *   1) Server se https://draw.ar-lottery01.com reachable hai ya nahi
 *   2) Upstream kya HTTP status / kya JSON de raha hai
 *   3) Upstream ka period number / result  vs  local game ka period / result
 *
 * FIX #9 isi data par kaam karta hai. Is page ka output developer ko bhej do.
 */
header('Content-Type: text/plain; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');

try {
    require_once __DIR__ . '/api/_core/bootstrap.php';
} catch (Throwable $e) {
    echo "BOOTSTRAP LOAD FAIL: " . $e->getMessage() . "\n";
    exit;
}

$line   = str_repeat('=', 78);
$games  = ['WinGo_30S', 'WinGo_1M', 'WinGo_3M'];
$base   = defined('LE_UPSTREAM_BASE') ? rtrim((string)LE_UPSTREAM_BASE, '/') : '';
$on     = defined('LE_UPSTREAM_RESULTS') ? (bool)LE_UPSTREAM_RESULTS : false;

echo $line . "\n";
echo "MAANWIN UPSTREAM DIAG   " . date('Y-m-d H:i:s T') . "   host=" . ($_SERVER['HTTP_HOST'] ?? '') . "\n";
echo $line . "\n\n";

echo "[A] SETTING\n";
echo '    LE_UPSTREAM_RESULTS : ' . ($on ? 'true' : 'false') . "\n";
echo '    LE_UPSTREAM_BASE    : ' . ($base !== '' ? $base : '<< NOT SET >>') . "\n";
echo '    curl_init()         : ' . (function_exists('curl_init') ? 'yes' : 'NO') . "\n";
echo '    allow_url_fopen     : ' . var_export((bool)ini_get('allow_url_fopen'), true) . "\n";
echo '    temp dir            : ' . (function_exists('sys_get_temp_dir') ? sys_get_temp_dir() : 'n/a') . "\n\n";

/** bina cache ke seedha HTTP call (diagnostic ke liye) */
function up_raw(string $url, int $timeout = 6): array
{
    $out = ['how' => '-', 'code' => 0, 'body' => '', 'err' => ''];
    if (function_exists('curl_init')) {
        $ch = @curl_init($url);
        if ($ch) {
            @curl_setopt_array($ch, [
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_FOLLOWLOCATION => true,
                CURLOPT_CONNECTTIMEOUT => $timeout,
                CURLOPT_TIMEOUT        => $timeout + 2,
                CURLOPT_SSL_VERIFYPEER => false,
                CURLOPT_SSL_VERIFYHOST => false,
                CURLOPT_HTTPHEADER     => [
                    'Accept: application/json, text/plain, */*',
                    'Origin: ' . (defined('LE_UPSTREAM_BASE') ? rtrim((string)LE_UPSTREAM_BASE, '/') : ''),
                    'Referer: ' . (defined('LE_UPSTREAM_BASE') ? rtrim((string)LE_UPSTREAM_BASE, '/') . '/' : ''),
                    'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36',
                ],
            ]);
            $b = @curl_exec($ch);
            $out['how']  = 'curl';
            $out['code'] = (int)@curl_getinfo($ch, CURLINFO_HTTP_CODE);
            $out['err']  = (string)@curl_error($ch);
            if (is_string($b)) $out['body'] = $b;
            @curl_close($ch);
            return $out;
        }
    }
    if ((bool)ini_get('allow_url_fopen')) {
        $ctx = @stream_context_create([
            'http' => ['method' => 'GET', 'timeout' => $timeout, 'ignore_errors' => true],
            'ssl'  => ['verify_peer' => false, 'verify_peer_name' => false],
        ]);
        $b = @file_get_contents($url, false, $ctx);
        $out['how'] = 'file_get_contents';
        if (is_string($b)) $out['body'] = $b;
        $out['code'] = 200;
        return $out;
    }
    $out['err'] = 'curl AND allow_url_fopen dono band hain';
    return $out;
}

if ($base === '') {
    echo "LE_UPSTREAM_BASE set nahi hai — aage kuch check nahi ho sakta.\n";
    exit;
}

// ------------------------------------------------------------------ B
echo "[B] CURRENT ISSUE — upstream vs local (bina cache ke)\n";
foreach ($games as $g) {
    $url = $base . '/webapi/kv/issue/' . rawurlencode($g);
    $r   = up_raw($url);
    echo "  --- $g ---\n";
    echo '      URL    : ' . $url . "\n";
    echo '      via    : ' . $r['how'] . '   http=' . $r['code'] . ($r['err'] !== '' ? '   err=' . $r['err'] : '') . "\n";
    echo '      body   : ' . (trim($r['body']) === '' ? '(khali)' : substr(preg_replace('/\s+/', ' ', $r['body']), 0, 400)) . "\n";
    $j = json_decode($r['body'], true);
    $ui = '';
    if (is_array($j)) {
        $d = $j['data'] ?? null;
        if (is_array($d)) {
            $ui = trim((string)($d['issueNumber'] ?? $d['issueNo'] ?? $d['issue'] ?? $d['period'] ?? ''));
            echo '      upstream -> issueNumber=' . $ui
                 . '  start=' . ($d['startTime'] ?? '-')
                 . '  end=' . ($d['endTime'] ?? '-')
                 . '  countdown=' . ($d['countdown'] ?? '-') . "\n";
        }
    }
    $loc = function_exists('lottery_issue') ? lottery_issue($g) : null;
    $li  = is_array($loc) ? (string)$loc['issueNumber'] : '-';
    echo '      local    -> issueNumber=' . $li . "\n";
    echo '      MATCH?   : ' . (($ui !== '' && $ui === $li) ? 'YES  (drawer = game)' : ($ui === '' ? 'UPSTREAM SE JAWAB NAHI MILA' : 'NO   (abhi bhi alag)')) . "\n\n";
}

// ------------------------------------------------------------------ C
echo "[C] HISTORY (GetHistoryIssuePage.json) — upstream vs local\n";
foreach ($games as $g) {
    $fam = function_exists('le_upstream_family') ? le_upstream_family($g) : 'WinGo';
    $url = $base . '/' . $fam . '/' . rawurlencode($g) . '/GetHistoryIssuePage.json?pageNo=1&pageSize=10';
    $r   = up_raw($url);
    echo "  --- $g ---\n";
    echo '      URL    : ' . $url . "\n";
    echo '      via    : ' . $r['how'] . '   http=' . $r['code'] . ($r['err'] !== '' ? '   err=' . $r['err'] : '') . "\n";
    $j = json_decode($r['body'], true);
    $rows = (is_array($j) && isset($j['data']['list']) && is_array($j['data']['list'])) ? $j['data']['list'] : [];
    if (!$rows) {
        echo '      body   : ' . (trim($r['body']) === '' ? '(khali)' : substr(preg_replace('/\s+/', ' ', $r['body']), 0, 300)) . "\n";
    }
    foreach (array_slice($rows, 0, 4) as $i => $row) {
        $num = trim((string)($row['issueNumber'] ?? $row['issueNo'] ?? $row['period'] ?? ''));
        $res = (string)($row['premium'] ?? $row['number'] ?? '');
        echo '      up row' . $i . ' : ' . $num . '   result=' . $res . "\n";
    }
    if (function_exists('le_history_page')) {
        $p = le_history_page($g, 1, 10);
        foreach (array_slice($p['list'], 0, 4) as $i => $row) {
            echo '      local row' . $i . ' : ' . $row['issueNumber'] . '   result=' . $row['number'] . "\n";
        }
    }
    echo "\n";
}

echo $line . "\n";
echo "END. Is page ka output developer ko bhej do. Kaam ho jane par delete kar dena.\n";
